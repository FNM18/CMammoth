// A Bison parser, made by GNU Bison 3.5.1.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2020 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// Undocumented macros, especially those whose name start with YY_,
// are private implementation details.  Do not rely on them.





#include "parser.tab.hh"


// Unqualified %code blocks.
#line 22 "parser.yy"

#include "driver.h"
#include "flags.h"
#include "semantic.cpp"
#include <iostream>
#include <vector>

Scope scope = Scope();
vector<ExpressionSolver> quads;
ExpressionSolver es;

#line 57 "parser.tab.cc"


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

// Whether we are compiled with exception support.
#ifndef YY_EXCEPTIONS
# if defined __GNUC__ && !defined __EXCEPTIONS
#  define YY_EXCEPTIONS 0
# else
#  define YY_EXCEPTIONS 1
# endif
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K].location)
/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

# ifndef YYLLOC_DEFAULT
#  define YYLLOC_DEFAULT(Current, Rhs, N)                               \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).begin  = YYRHSLOC (Rhs, 1).begin;                   \
          (Current).end    = YYRHSLOC (Rhs, N).end;                     \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).begin = (Current).end = YYRHSLOC (Rhs, 0).end;      \
        }                                                               \
    while (false)
# endif


// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << '\n';                       \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yystack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YYUSE (Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void> (0)
# define YY_STACK_PRINT()                static_cast<void> (0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)

#line 6 "parser.yy"
namespace yy {
#line 149 "parser.tab.cc"


  /* Return YYSTR after stripping away unnecessary quotes and
     backslashes, so that it's suitable for yyerror.  The heuristic is
     that double-quoting is unnecessary unless the string contains an
     apostrophe, a comma, or backslash (other than backslash-backslash).
     YYSTR is taken from yytname.  */
  std::string
  parser::yytnamerr_ (const char *yystr)
  {
    if (*yystr == '"')
      {
        std::string yyr;
        char const *yyp = yystr;

        for (;;)
          switch (*++yyp)
            {
            case '\'':
            case ',':
              goto do_not_strip_quotes;

            case '\\':
              if (*++yyp != '\\')
                goto do_not_strip_quotes;
              else
                goto append;

            append:
            default:
              yyr += *yyp;
              break;

            case '"':
              return yyr;
            }
      do_not_strip_quotes: ;
      }

    return yystr;
  }


  /// Build a parser object.
  parser::parser (parser_driver& driver_yyarg)
#if YYDEBUG
    : yydebug_ (false),
      yycdebug_ (&std::cerr),
#else
    :
#endif
      driver (driver_yyarg)
  {}

  parser::~parser ()
  {}

  parser::syntax_error::~syntax_error () YY_NOEXCEPT YY_NOTHROW
  {}

  /*---------------.
  | Symbol types.  |
  `---------------*/



  // by_state.
  parser::by_state::by_state () YY_NOEXCEPT
    : state (empty_state)
  {}

  parser::by_state::by_state (const by_state& that) YY_NOEXCEPT
    : state (that.state)
  {}

  void
  parser::by_state::clear () YY_NOEXCEPT
  {
    state = empty_state;
  }

  void
  parser::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  parser::by_state::by_state (state_type s) YY_NOEXCEPT
    : state (s)
  {}

  parser::symbol_number_type
  parser::by_state::type_get () const YY_NOEXCEPT
  {
    if (state == empty_state)
      return empty_symbol;
    else
      return yystos_[+state];
  }

  parser::stack_symbol_type::stack_symbol_type ()
  {}

  parser::stack_symbol_type::stack_symbol_type (YY_RVREF (stack_symbol_type) that)
    : super_type (YY_MOVE (that.state), YY_MOVE (that.location))
  {
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.YY_MOVE_OR_COPY< char > (YY_MOVE (that.value));
        break;

      case 55: // INT
      case 56: // FLOAT
        value.YY_MOVE_OR_COPY< float > (YY_MOVE (that.value));
        break;

      case 52: // ID
      case 53: // STRING
        value.YY_MOVE_OR_COPY< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

#if 201103L <= YY_CPLUSPLUS
    // that is emptied.
    that.state = empty_state;
#endif
  }

  parser::stack_symbol_type::stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) that)
    : super_type (s, YY_MOVE (that.location))
  {
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.move< char > (YY_MOVE (that.value));
        break;

      case 55: // INT
      case 56: // FLOAT
        value.move< float > (YY_MOVE (that.value));
        break;

      case 52: // ID
      case 53: // STRING
        value.move< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

    // that is emptied.
    that.type = empty_symbol;
  }

#if YY_CPLUSPLUS < 201103L
  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.copy< char > (that.value);
        break;

      case 55: // INT
      case 56: // FLOAT
        value.copy< float > (that.value);
        break;

      case 52: // ID
      case 53: // STRING
        value.copy< std::string > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    return *this;
  }

  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (stack_symbol_type& that)
  {
    state = that.state;
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.move< char > (that.value);
        break;

      case 55: // INT
      case 56: // FLOAT
        value.move< float > (that.value);
        break;

      case 52: // ID
      case 53: // STRING
        value.move< std::string > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    // that is emptied.
    that.state = empty_state;
    return *this;
  }
#endif

  template <typename Base>
  void
  parser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);
  }

#if YYDEBUG
  template <typename Base>
  void
  parser::yy_print_ (std::ostream& yyo,
                                     const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YYUSE (yyoutput);
    symbol_number_type yytype = yysym.type_get ();
#if defined __GNUC__ && ! defined __clang__ && ! defined __ICC && __GNUC__ * 100 + __GNUC_MINOR__ <= 408
    // Avoid a (spurious) G++ 4.8 warning about "array subscript is
    // below array bounds".
    if (yysym.empty ())
      std::abort ();
#endif
    yyo << (yytype < yyntokens_ ? "token" : "nterm")
        << ' ' << yytname_[yytype] << " ("
        << yysym.location << ": ";
    switch (yytype)
    {
      case 52: // ID
#line 129 "parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 401 "parser.tab.cc"
        break;

      case 53: // STRING
#line 129 "parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 407 "parser.tab.cc"
        break;

      case 54: // CHAR
#line 129 "parser.yy"
                 { yyoutput << yysym.value.template as < char > (); }
#line 413 "parser.tab.cc"
        break;

      case 55: // INT
#line 129 "parser.yy"
                 { yyoutput << yysym.value.template as < float > (); }
#line 419 "parser.tab.cc"
        break;

      case 56: // FLOAT
#line 129 "parser.yy"
                 { yyoutput << yysym.value.template as < float > (); }
#line 425 "parser.tab.cc"
        break;

      default:
        break;
    }
    yyo << ')';
  }
#endif

  void
  parser::yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym)
  {
    if (m)
      YY_SYMBOL_PRINT (m, sym);
    yystack_.push (YY_MOVE (sym));
  }

  void
  parser::yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym)
  {
#if 201103L <= YY_CPLUSPLUS
    yypush_ (m, stack_symbol_type (s, std::move (sym)));
#else
    stack_symbol_type ss (s, sym);
    yypush_ (m, ss);
#endif
  }

  void
  parser::yypop_ (int n)
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  parser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  parser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  parser::debug_level_type
  parser::debug_level () const
  {
    return yydebug_;
  }

  void
  parser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  parser::state_type
  parser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - yyntokens_] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - yyntokens_];
  }

  bool
  parser::yy_pact_value_is_default_ (int yyvalue)
  {
    return yyvalue == yypact_ninf_;
  }

  bool
  parser::yy_table_value_is_error_ (int yyvalue)
  {
    return yyvalue == yytable_ninf_;
  }

  int
  parser::operator() ()
  {
    return parse ();
  }

  int
  parser::parse ()
  {
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The locations where the error started and ended.
    stack_symbol_type yyerror_range[3];

    /// The return value of parse ().
    int yyresult;

#if YY_EXCEPTIONS
    try
#endif // YY_EXCEPTIONS
      {
    YYCDEBUG << "Starting parse\n";


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, YY_MOVE (yyla));

  /*-----------------------------------------------.
  | yynewstate -- push a new symbol on the stack.  |
  `-----------------------------------------------*/
  yynewstate:
    YYCDEBUG << "Entering state " << int (yystack_[0].state) << '\n';

    // Accept?
    if (yystack_[0].state == yyfinal_)
      YYACCEPT;

    goto yybackup;


  /*-----------.
  | yybackup.  |
  `-----------*/
  yybackup:
    // Try to take a decision without lookahead.
    yyn = yypact_[+yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token: ";
#if YY_EXCEPTIONS
        try
#endif // YY_EXCEPTIONS
          {
            symbol_type yylookahead (yylex (driver));
            yyla.move (yylookahead);
          }
#if YY_EXCEPTIONS
        catch (const syntax_error& yyexc)
          {
            YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
            error (yyexc);
            goto yyerrlab1;
          }
#endif // YY_EXCEPTIONS
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.type_get ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.type_get ())
      {
        goto yydefault;
      }

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", state_type (yyn), YY_MOVE (yyla));
    goto yynewstate;


  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[+yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;


  /*-----------------------------.
  | yyreduce -- do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_ (yystack_[yylen].state, yyr1_[yyn]);
      /* Variants are always initialized to an empty instance of the
         correct type. The default '$$ = $1' action is NOT applied
         when using variants.  */
      switch (yyr1_[yyn])
    {
      case 54: // CHAR
        yylhs.value.emplace< char > ();
        break;

      case 55: // INT
      case 56: // FLOAT
        yylhs.value.emplace< float > ();
        break;

      case 52: // ID
      case 53: // STRING
        yylhs.value.emplace< std::string > ();
        break;

      default:
        break;
    }


      // Default location.
      {
        stack_type::slice range (yystack_, yylen);
        YYLLOC_DEFAULT (yylhs.location, range, yylen);
        yyerror_range[1].location = yylhs.location;
      }

      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
#if YY_EXCEPTIONS
      try
#endif // YY_EXCEPTIONS
        {
          switch (yyn)
            {
  case 4:
#line 140 "parser.yy"
                                  {globalFlag = 1;}
#line 680 "parser.tab.cc"
    break;

  case 6:
#line 144 "parser.yy"
                 {setID(yystack_[0].value.as < std::string > ());}
#line 686 "parser.tab.cc"
    break;

  case 8:
#line 145 "parser.yy"
                          {setID(yystack_[0].value.as < std::string > ());}
#line 692 "parser.tab.cc"
    break;

  case 15:
#line 151 "parser.yy"
                          {setID(yystack_[0].value.as < std::string > ());}
#line 698 "parser.tab.cc"
    break;

  case 17:
#line 152 "parser.yy"
                          {setID(yystack_[0].value.as < std::string > ());}
#line 704 "parser.tab.cc"
    break;

  case 22:
#line 166 "parser.yy"
                     {if(expressionFlag){es.installPar();}}
#line 710 "parser.tab.cc"
    break;

  case 23:
#line 166 "parser.yy"
                                                                            {if(expressionFlag){es.closePar();}}
#line 716 "parser.tab.cc"
    break;

  case 27:
#line 176 "parser.yy"
                   {cout << "Clase id : " << yystack_[0].value.as < std::string > () << endl;}
#line 722 "parser.tab.cc"
    break;

  case 30:
#line 181 "parser.yy"
{
        setCurrentFunction(yystack_[0].value.as < std::string > ());
        scope.globalInsertFunction(yystack_[0].value.as < std::string > (),currentType,"function");
        scope.setFunctionScope(yystack_[0].value.as < std::string > ());
        scope.installFunctionVars(yystack_[0].value.as < std::string > ());
        resetCurrentType();
        globalFlag = 0;
}
#line 735 "parser.tab.cc"
    break;

  case 31:
#line 189 "parser.yy"
                                                       {resetCurrentFunction();}
#line 741 "parser.tab.cc"
    break;

  case 37:
#line 201 "parser.yy"
                        {cout << "Herencia id : " << yystack_[0].value.as < std::string > () << endl;}
#line 747 "parser.tab.cc"
    break;

  case 41:
#line 211 "parser.yy"
{       
        if(globalFlag){
                for(auto var : currentIds){
                        scope.insertGlobalVariable(var,currentType,"");
                }
        }else{
                for(auto var : currentIds){
                        scope.insertVarOnScope(var,currentType,"");
                } 
        }
        resetID();
        resetCurrentType();
}
#line 765 "parser.tab.cc"
    break;

  case 50:
#line 243 "parser.yy"
                       {setCurrentType(0);}
#line 771 "parser.tab.cc"
    break;

  case 51:
#line 244 "parser.yy"
                          {setCurrentType(1);}
#line 777 "parser.tab.cc"
    break;

  case 52:
#line 245 "parser.yy"
                         {setCurrentType(2);}
#line 783 "parser.tab.cc"
    break;

  case 54:
#line 248 "parser.yy"
                               {setCurrentType(10);}
#line 789 "parser.tab.cc"
    break;

  case 56:
#line 251 "parser.yy"
                                    {setCurrentType(20);}
#line 795 "parser.tab.cc"
    break;

  case 57:
#line 254 "parser.yy"
              {if(expressionFlag){es.insertOprnd(yystack_[0].value.as < std::string > ());}}
#line 801 "parser.tab.cc"
    break;

  case 64:
#line 263 "parser.yy"
                {setID(yystack_[0].value.as < std::string > ());}
#line 807 "parser.tab.cc"
    break;

  case 65:
#line 264 "parser.yy"
{
        scope.insertVarOnScope(yystack_[4].value.as < std::string > (),currentType,"");
        resetCurrentType();
        resetID();
}
#line 817 "parser.tab.cc"
    break;

  case 79:
#line 287 "parser.yy"
{
        es = ExpressionSolver();
        expressionFlag = 1;
}
#line 826 "parser.tab.cc"
    break;

  case 80:
#line 291 "parser.yy"
                     {quads.push_back(es); expressionFlag = 0;}
#line 832 "parser.tab.cc"
    break;

  case 86:
#line 307 "parser.yy"
                              {cout << "Constante string : " << yystack_[0].value.as < std::string > () << endl;}
#line 838 "parser.tab.cc"
    break;

  case 89:
#line 310 "parser.yy"
                         {cout << "Constante string : " << yystack_[0].value.as < std::string > () << endl;}
#line 844 "parser.tab.cc"
    break;

  case 103:
#line 330 "parser.yy"
           {if(expressionFlag){es.insertOptr(6);}}
#line 850 "parser.tab.cc"
    break;

  case 104:
#line 331 "parser.yy"
           {if(expressionFlag){es.insertOptr(7);}}
#line 856 "parser.tab.cc"
    break;

  case 105:
#line 332 "parser.yy"
           {if(expressionFlag){es.insertOptr(10);}}
#line 862 "parser.tab.cc"
    break;

  case 106:
#line 333 "parser.yy"
           {if(expressionFlag){es.insertOptr(11);}}
#line 868 "parser.tab.cc"
    break;

  case 107:
#line 334 "parser.yy"
           {if(expressionFlag){es.insertOptr(8);}}
#line 874 "parser.tab.cc"
    break;

  case 108:
#line 335 "parser.yy"
           {if(expressionFlag){es.insertOptr(9);}}
#line 880 "parser.tab.cc"
    break;

  case 109:
#line 336 "parser.yy"
                   {if(expressionFlag){es.insertOptr(12);}}
#line 886 "parser.tab.cc"
    break;

  case 111:
#line 337 "parser.yy"
                  {if(expressionFlag){es.insertOptr(13);}}
#line 892 "parser.tab.cc"
    break;

  case 115:
#line 342 "parser.yy"
               {if(expressionFlag){es.insertOptr(0);}}
#line 898 "parser.tab.cc"
    break;

  case 117:
#line 343 "parser.yy"
               {if(expressionFlag){es.insertOptr(1);}}
#line 904 "parser.tab.cc"
    break;

  case 121:
#line 348 "parser.yy"
                {if(expressionFlag){es.insertOptr(2);}}
#line 910 "parser.tab.cc"
    break;

  case 123:
#line 349 "parser.yy"
                {if(expressionFlag){es.insertOptr(3);}}
#line 916 "parser.tab.cc"
    break;

  case 125:
#line 350 "parser.yy"
                {if(expressionFlag){es.insertOptr(4);}}
#line 922 "parser.tab.cc"
    break;

  case 136:
#line 364 "parser.yy"
              {if(expressionFlag){es.insertOprnd(yystack_[0].value.as < float > ());}}
#line 928 "parser.tab.cc"
    break;

  case 137:
#line 365 "parser.yy"
                {if(expressionFlag){es.insertOprnd(yystack_[0].value.as < float > ());}}
#line 934 "parser.tab.cc"
    break;

  case 138:
#line 366 "parser.yy"
               {if(expressionFlag){es.insertOprnd(yystack_[0].value.as < char > ());}}
#line 940 "parser.tab.cc"
    break;


#line 944 "parser.tab.cc"

            default:
              break;
            }
        }
#if YY_EXCEPTIONS
      catch (const syntax_error& yyexc)
        {
          YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
          error (yyexc);
          YYERROR;
        }
#endif // YY_EXCEPTIONS
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;
      YY_STACK_PRINT ();

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, YY_MOVE (yylhs));
    }
    goto yynewstate;


  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        error (yyla.location, yysyntax_error_ (yystack_[0].state, yyla));
      }


    yyerror_range[1].location = yyla.location;
    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.type_get () == yyeof_)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:
    /* Pacify compilers when the user code never invokes YYERROR and
       the label yyerrorlab therefore never appears in user code.  */
    if (false)
      YYERROR;

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    goto yyerrlab1;


  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    {
      stack_symbol_type error_token;
      for (;;)
        {
          yyn = yypact_[+yystack_[0].state];
          if (!yy_pact_value_is_default_ (yyn))
            {
              yyn += yy_error_token_;
              if (0 <= yyn && yyn <= yylast_ && yycheck_[yyn] == yy_error_token_)
                {
                  yyn = yytable_[yyn];
                  if (0 < yyn)
                    break;
                }
            }

          // Pop the current state because it cannot handle the error token.
          if (yystack_.size () == 1)
            YYABORT;

          yyerror_range[1].location = yystack_[0].location;
          yy_destroy_ ("Error: popping", yystack_[0]);
          yypop_ ();
          YY_STACK_PRINT ();
        }

      yyerror_range[2].location = yyla.location;
      YYLLOC_DEFAULT (error_token.location, yyerror_range, 2);

      // Shift the error token.
      error_token.state = state_type (yyn);
      yypush_ ("Shifting", YY_MOVE (error_token));
    }
    goto yynewstate;


  /*-------------------------------------.
  | yyacceptlab -- YYACCEPT comes here.  |
  `-------------------------------------*/
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;


  /*-----------------------------------.
  | yyabortlab -- YYABORT comes here.  |
  `-----------------------------------*/
  yyabortlab:
    yyresult = 1;
    goto yyreturn;


  /*-----------------------------------------------------.
  | yyreturn -- parsing is finished, return the result.  |
  `-----------------------------------------------------*/
  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
#if YY_EXCEPTIONS
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack\n";
        // Do not try to display the values of the reclaimed symbols,
        // as their printers might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
#endif // YY_EXCEPTIONS
  }

  void
  parser::error (const syntax_error& yyexc)
  {
    error (yyexc.location, yyexc.what ());
  }

  // Generate an error message.
  std::string
  parser::yysyntax_error_ (state_type yystate, const symbol_type& yyla) const
  {
    // Number of reported tokens (one for the "unexpected", one per
    // "expected").
    std::ptrdiff_t yycount = 0;
    // Its maximum.
    enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
    // Arguments of yyformat.
    char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];

    /* There are many possibilities here to consider:
       - If this state is a consistent state with a default action, then
         the only way this function was invoked is if the default action
         is an error action.  In that case, don't check for expected
         tokens because there are none.
       - The only way there can be no lookahead present (in yyla) is
         if this state is a consistent state with a default action.
         Thus, detecting the absence of a lookahead is sufficient to
         determine that there is no unexpected or expected token to
         report.  In that case, just report a simple "syntax error".
       - Don't assume there isn't a lookahead just because this state is
         a consistent state with a default action.  There might have
         been a previous inconsistent state, consistent state with a
         non-default action, or user semantic action that manipulated
         yyla.  (However, yyla is currently not documented for users.)
       - Of course, the expected token list depends on states to have
         correct lookahead information, and it depends on the parser not
         to perform extra reductions after fetching a lookahead from the
         scanner and before detecting a syntax error.  Thus, state merging
         (from LALR or IELR) and default reductions corrupt the expected
         token list.  However, the list is correct for canonical LR with
         one exception: it will still contain any token that will not be
         accepted due to an error action in a later state.
    */
    if (!yyla.empty ())
      {
        symbol_number_type yytoken = yyla.type_get ();
        yyarg[yycount++] = yytname_[yytoken];

        int yyn = yypact_[+yystate];
        if (!yy_pact_value_is_default_ (yyn))
          {
            /* Start YYX at -YYN if negative to avoid negative indexes in
               YYCHECK.  In other words, skip the first -YYN actions for
               this state because they are default actions.  */
            int yyxbegin = yyn < 0 ? -yyn : 0;
            // Stay within bounds of both yycheck and yytname.
            int yychecklim = yylast_ - yyn + 1;
            int yyxend = yychecklim < yyntokens_ ? yychecklim : yyntokens_;
            for (int yyx = yyxbegin; yyx < yyxend; ++yyx)
              if (yycheck_[yyx + yyn] == yyx && yyx != yy_error_token_
                  && !yy_table_value_is_error_ (yytable_[yyx + yyn]))
                {
                  if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                    {
                      yycount = 1;
                      break;
                    }
                  else
                    yyarg[yycount++] = yytname_[yyx];
                }
          }
      }

    char const* yyformat = YY_NULLPTR;
    switch (yycount)
      {
#define YYCASE_(N, S)                         \
        case N:                               \
          yyformat = S;                       \
        break
      default: // Avoid compiler warnings.
        YYCASE_ (0, YY_("syntax error"));
        YYCASE_ (1, YY_("syntax error, unexpected %s"));
        YYCASE_ (2, YY_("syntax error, unexpected %s, expecting %s"));
        YYCASE_ (3, YY_("syntax error, unexpected %s, expecting %s or %s"));
        YYCASE_ (4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
        YYCASE_ (5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
      }

    std::string yyres;
    // Argument number.
    std::ptrdiff_t yyi = 0;
    for (char const* yyp = yyformat; *yyp; ++yyp)
      if (yyp[0] == '%' && yyp[1] == 's' && yyi < yycount)
        {
          yyres += yytnamerr_ (yyarg[yyi++]);
          ++yyp;
        }
      else
        yyres += *yyp;
    return yyres;
  }


  const short parser::yypact_ninf_ = -200;

  const signed char parser::yytable_ninf_ = -90;

  const short
  parser::yypact_[] =
  {
       7,   -18,    40,  -200,    54,  -200,    11,    27,  -200,  -200,
    -200,    67,    65,    49,  -200,    31,    53,  -200,    96,  -200,
     101,  -200,  -200,  -200,  -200,  -200,  -200,    76,  -200,    73,
    -200,    75,    57,  -200,    98,  -200,    61,    49,  -200,    80,
      66,    12,    21,  -200,  -200,  -200,    90,    49,   106,  -200,
     115,  -200,    31,  -200,   112,  -200,  -200,  -200,  -200,  -200,
    -200,  -200,  -200,  -200,   121,    -3,    25,    26,    77,    48,
    -200,  -200,  -200,  -200,   118,   125,    49,  -200,   133,    57,
      21,    21,  -200,   128,  -200,  -200,  -200,  -200,  -200,  -200,
    -200,  -200,  -200,    34,  -200,  -200,  -200,  -200,  -200,  -200,
    -200,   130,  -200,   -16,    91,  -200,  -200,  -200,    11,  -200,
     129,    68,  -200,  -200,    21,    21,    21,    21,    21,    93,
      21,   142,    56,  -200,    90,   136,   135,   137,   138,   139,
     140,   103,   144,  -200,   134,   148,   -16,   -16,   -16,   -16,
     -16,   -16,   -16,  -200,  -200,  -200,   147,  -200,  -200,  -200,
    -200,  -200,  -200,  -200,  -200,    21,  -200,  -200,  -200,  -200,
    -200,    34,  -200,   158,    93,  -200,  -200,   103,  -200,   160,
    -200,  -200,  -200,   159,   103,     4,    21,    21,  -200,   145,
     161,  -200,  -200,  -200,  -200,  -200,  -200,  -200,  -200,  -200,
     136,    67,    38,    21,  -200,   154,  -200,  -200,   103,  -200,
    -200,  -200,   156,   166,   162,   167,   163,   164,    21,  -200,
      21,  -200,  -200,   168,   165,  -200,  -200,  -200,  -200,   158,
    -200,  -200,   173,   175,   176,     4,   123,   132,   141,   180,
    -200,    12,   -16,    21,    21,  -200,  -200,     4,  -200,  -200,
     178,   179,    21,  -200,  -200,   182,  -200,  -200,  -200,   -16,
     -16,   146,   185,   187,   184,   186,   188,    91,  -200,  -200,
    -200,   153,  -200,   -16,  -200,    31,   190,  -200,  -200,   191,
    -200,   -16,  -200,   192,  -200
  };

  const unsigned char
  parser::yydefact_[] =
  {
       0,     0,     0,     2,     0,     1,     3,     0,    29,     4,
      27,     3,     3,     0,    40,     3,     0,    38,     0,     6,
       0,    39,    56,    50,    51,    52,    33,     0,    55,     0,
      37,     3,     0,    41,     0,     5,     0,     0,    46,     3,
       0,     0,     3,     7,    10,    11,     0,     3,     0,    30,
       0,    45,     3,    36,     0,     8,    54,    53,    12,    22,
     130,   131,   132,   128,     3,     3,     3,     0,     0,     0,
      13,    44,    43,    42,     0,     0,     3,    35,     0,     0,
       3,     3,    21,     0,   115,   117,   119,   114,   121,   123,
     125,   127,   120,    57,   138,   136,   137,   135,   134,   129,
     133,    15,    14,     3,     0,    49,    48,    47,     3,     9,
       0,   102,    20,    19,     3,     3,     3,     3,     3,     0,
       3,     3,     3,    96,     0,     0,     0,     0,     0,     0,
       0,     0,    57,    78,     0,     0,     3,     3,     3,     3,
       3,     3,     3,    94,    95,    64,     0,    28,    23,   103,
     105,   106,   107,   108,   104,     3,   116,   118,   122,   124,
     126,     0,    97,     3,     0,   100,    98,     0,    61,     3,
      58,    16,    18,     0,     0,     3,     3,     3,    57,     0,
       0,    79,    34,    71,    72,    73,    74,    75,    76,    77,
       3,     3,     3,     3,    26,     0,    99,    59,     0,    63,
      60,    83,     0,    86,     0,    87,     0,     0,     3,    82,
       3,    70,    69,     0,     0,   109,   111,   113,   101,     3,
      24,    62,     0,     0,     0,     3,     0,     0,     0,     0,
      81,     0,     3,     3,     3,    25,    84,     3,    85,    88,
       0,     0,     3,    80,    65,     0,   110,   112,    90,     3,
       3,     0,     3,     0,     0,     0,     0,     0,    68,    66,
      31,     3,   139,     3,    67,     3,     0,    93,    91,     0,
      32,     3,   140,     0,    92
  };

  const short
  parser::yypgoto_[] =
  {
    -200,  -200,    -6,  -200,  -200,   -27,  -200,   122,  -200,  -200,
      81,    83,  -200,  -200,  -119,  -200,    79,  -200,    78,   -11,
     104,  -200,   -51,  -200,  -200,  -200,  -200,  -200,    18,   169,
    -200,  -200,  -200,   143,  -200,   -39,   -20,  -200,   -48,  -200,
    -200,  -200,   -42,  -200,  -200,  -200,  -200,  -125,  -200,  -200,
    -200,  -200,  -200,  -200,  -200,  -199,  -200,  -200,  -200,  -200,
    -111,  -200,  -200,   -73,  -200,  -200,  -200,  -200,   -38,  -200,
    -200,  -200,   -23,  -200,  -200,  -200,  -200,  -200,  -200,  -200,
    -200,  -200,  -200
  };

  const short
  parser::yydefgoto_[] =
  {
      -1,     2,    62,     3,    11,    20,    32,    43,    79,    44,
      45,    70,   124,   125,    46,    83,    63,    80,   121,   195,
       9,    12,    27,    75,   265,    35,    54,    18,    15,    21,
      47,    73,    39,    51,   107,    28,    58,    29,   134,   122,
     170,   200,   146,   190,   252,   259,   213,   135,   136,   210,
     229,   137,   138,   139,   140,   204,   223,   141,   268,   142,
      98,   123,   166,   205,   155,   218,   233,   234,   111,    87,
     114,   115,    65,    92,   116,   117,   118,    66,    67,    99,
     100,   143,   144
  };

  const short
  parser::yytable_[] =
  {
       8,    77,    57,   169,    64,    14,    17,   110,   162,    26,
      50,   183,   184,   185,   186,   187,   188,   189,    59,    97,
      84,    85,   126,   127,   128,    38,   239,    60,    61,   129,
     102,   130,   131,    53,     4,    59,   132,     1,   248,   119,
       5,    71,     7,   112,    60,    61,    26,   163,   120,    50,
      88,    89,    90,   196,    23,    24,    25,   203,    82,    86,
      91,   167,     6,    40,    56,    41,   215,   216,    42,    42,
     105,   212,    22,    23,    24,    25,   156,   157,    93,    10,
      94,    95,    96,   179,   149,   150,   151,   152,   153,   154,
      23,    24,    25,   158,   159,   160,    68,   133,    69,    13,
      16,    19,     8,   206,   207,    30,    31,   245,    33,    34,
      36,    37,    48,    49,    52,   165,   168,   192,    55,   197,
     219,    74,    76,    78,   254,   255,   202,    81,   103,   101,
     133,   133,   133,   133,   133,   133,   133,   230,   269,   104,
     108,   113,   -17,   145,   148,   161,   273,   164,    42,    59,
     221,   174,   175,   176,   177,   178,   181,   194,   120,   182,
     246,   247,   191,   199,   193,   198,   201,   208,   209,   220,
     228,   222,   -89,   225,   240,   232,   231,   224,   226,   227,
     236,   237,   241,   238,   211,    14,   217,   243,   249,   250,
     242,   257,    57,   253,   260,   261,   256,   262,   263,   266,
     271,   109,   272,   274,   251,   173,   172,   171,   235,   214,
     180,   244,   147,   194,   270,   264,    72,     0,     0,   106,
       0,     0,     0,     0,     0,     0,   133,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   133,   133,     0,   258,     0,     0,     0,
       0,     0,     0,     0,     0,   267,     0,   133,     0,    26,
       0,     0,     0,     0,     0,   133
  };

  const short
  parser::yycheck_[] =
  {
       6,    52,    41,   122,    42,    11,    12,    80,   119,    15,
      37,   136,   137,   138,   139,   140,   141,   142,    14,    67,
      23,    24,    38,    39,    40,    31,   225,    23,    24,    45,
      69,    47,    48,    39,    52,    14,    52,    30,   237,     5,
       0,    47,    31,    81,    23,    24,    52,   120,    14,    76,
      25,    26,    27,   164,    42,    43,    44,    53,    64,    65,
      66,     5,     8,     6,    52,     8,    28,    29,    12,    12,
      76,   190,    41,    42,    43,    44,   114,   115,    52,    52,
      54,    55,    56,   131,    16,    17,    18,    19,    20,    21,
      42,    43,    44,   116,   117,   118,     6,   103,     8,    32,
      35,    52,   108,   176,   177,    52,    10,   232,     7,    33,
      37,    36,    14,    52,    34,   121,   122,   155,    52,   167,
     193,    15,     7,    11,   249,   250,   174,     6,    10,    52,
     136,   137,   138,   139,   140,   141,   142,   210,   263,    14,
       7,    13,    12,    52,    15,    52,   271,     5,    12,    14,
     198,    14,    14,    14,    14,    52,    22,   163,    14,    11,
     233,   234,    15,   169,     6,     5,     7,    22,     7,    15,
     208,    15,     6,     6,    51,    10,     8,    15,    15,    15,
       7,     6,    50,     7,   190,   191,   192,     7,    10,    10,
      49,     6,   231,    11,     7,    11,    50,    11,    10,    46,
      10,    79,    11,    11,   242,   126,   125,   124,   219,   191,
     132,   231,   108,   219,   265,   257,    47,    -1,    -1,    76,
      -1,    -1,    -1,    -1,    -1,    -1,   232,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   249,   250,    -1,   252,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   261,    -1,   263,    -1,   265,
      -1,    -1,    -1,    -1,    -1,   271
  };

  const unsigned char
  parser::yystos_[] =
  {
       0,    30,    58,    60,    52,     0,     8,    31,    59,    77,
      52,    61,    78,    32,    59,    85,    35,    59,    84,    52,
      62,    86,    41,    42,    43,    44,    59,    79,    92,    94,
      52,    10,    63,     7,    33,    82,    37,    36,    59,    89,
       6,     8,    12,    64,    66,    67,    71,    87,    14,    52,
      62,    90,    34,    59,    83,    52,    52,    92,    93,    14,
      23,    24,    59,    73,   125,   129,   134,   135,     6,     8,
      68,    59,    86,    88,    15,    80,     7,    79,    11,    65,
      74,     6,    59,    72,    23,    24,    59,   126,    25,    26,
      27,    59,   130,    52,    54,    55,    56,    95,   117,   136,
     137,    52,    92,    10,    14,    59,    90,    91,     7,    64,
     120,   125,   125,    13,   127,   128,   131,   132,   133,     5,
      14,    75,    96,   118,    69,    70,    38,    39,    40,    45,
      47,    48,    52,    59,    95,   104,   105,   108,   109,   110,
     111,   114,   116,   138,   139,    52,    99,    77,    15,    16,
      17,    18,    19,    20,    21,   121,   125,   125,   129,   129,
     129,    52,   117,   120,     5,    59,   119,     5,    59,    71,
      97,    68,    67,    73,    14,    14,    14,    14,    52,    95,
      75,    22,    11,   104,   104,   104,   104,   104,   104,   104,
     100,    15,   125,     6,    59,    76,   117,    95,     5,    59,
      98,     7,    95,    53,   112,   120,   120,   120,    22,     7,
     106,    59,    71,   103,    85,    28,    29,    59,   122,   120,
      15,    95,    15,   113,    15,     6,    15,    15,   125,   107,
     120,     8,    10,   123,   124,    76,     7,     6,     7,   112,
      51,    50,    49,     7,    93,   104,   120,   120,   112,    10,
      10,   125,   101,    11,   104,   104,    50,     6,    59,   102,
       7,    11,    11,    10,    99,    81,    46,    59,   115,   104,
      79,    10,    11,   104,    11
  };

  const unsigned char
  parser::yyr1_[] =
  {
       0,    57,    58,    59,    61,    60,    63,    62,    65,    64,
      64,    66,    66,    67,    68,    69,    68,    70,    68,    71,
      72,    72,    74,    73,    75,    76,    76,    78,    77,    77,
      80,    81,    79,    79,    82,    83,    83,    84,    84,    85,
      85,    87,    86,    88,    88,    89,    89,    90,    91,    91,
      92,    92,    92,    93,    93,    94,    94,    96,    95,    97,
      97,    97,    98,    98,   100,   101,    99,   102,   102,   103,
     103,   104,   104,   104,   104,   104,   104,   104,   104,   106,
     105,   107,   108,   109,   110,   111,   112,   112,   112,   113,
     112,   114,   115,   115,   116,   116,   117,   118,   118,   119,
     119,   120,   120,   121,   121,   121,   121,   121,   121,   123,
     122,   124,   122,   122,   125,   127,   126,   128,   126,   126,
     129,   131,   130,   132,   130,   133,   130,   130,   134,   134,
     135,   135,   135,   136,   136,   136,   137,   137,   137,   138,
     139
  };

  const signed char
  parser::yyr2_[] =
  {
       0,     2,     1,     0,     0,     8,     0,     3,     0,     4,
       1,     1,     2,     2,     2,     0,     4,     0,     4,     4,
       2,     1,     0,     4,     4,     3,     1,     0,    10,     1,
       0,     0,    14,     1,     6,     2,     1,     2,     1,     2,
       1,     0,     4,     1,     1,     2,     1,     3,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     0,     3,     2,
       2,     1,     2,     1,     0,     0,     7,     2,     1,     1,
       1,     2,     2,     2,     2,     2,     2,     2,     1,     0,
       5,     1,     3,     3,     5,     5,     1,     1,     3,     0,
       4,     9,     4,     1,     1,     1,     2,     2,     2,     2,
       1,     4,     1,     1,     1,     1,     1,     1,     1,     0,
       3,     0,     3,     1,     2,     0,     3,     0,     3,     1,
       2,     0,     3,     0,     3,     0,     3,     1,     1,     2,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     8,
      10
  };



  // YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
  // First, the terminals, then, starting at \a yyntokens_, nonterminals.
  const char*
  const parser::yytname_[] =
  {
  "\"eof\"", "error", "$undefined", "COMENTARIO", "SIMBOLO", "PUNTO",
  "COMA", "SCOL", "COL", "GBAJO", "LCUR", "RCUR", "LBRA", "RBRA", "LPAR",
  "RPAR", "EQ", "GE", "LE", "GT", "LT", "NE", "ASSIGN", "SUM", "RES",
  "MUL", "DIV", "MOD", "AND", "OR", "PROGRAMA", "CLASE", "VARIABLES",
  "MAIN", "METODOS", "HEREDA", "ATRIBUTOS", "FUNCION", "RETORNAR", "LEER",
  "ESCRIBIR", "VOID", "INT_T", "FLOAT_T", "CHAR_T", "SI", "SINO",
  "MIENTRAS", "PARA", "EN", "HACER", "ENTONCES", "ID", "STRING", "CHAR",
  "INT", "FLOAT", "$accept", "script", "empty", "program", "$@1",
  "declare_var", "$@2", "declare_bridge1", "$@3", "declare_bridge2",
  "declare_bridge3", "declare_bridge4", "$@4", "$@5", "dimensions",
  "matrix", "single_express", "$@6", "mult_express", "expression_loop",
  "classes", "$@7", "functions", "$@8", "$@9", "main", "methods",
  "inheritance", "variables", "var_bridge1", "$@10", "var_bridge2",
  "attributes", "attr_bridge1", "attr_bridge2", "primitive_type",
  "var_type", "return_type", "call_var", "$@11", "call_options",
  "call_cont", "parameters", "$@12", "$@13", "par_cont", "par_array",
  "statutes", "assignment", "$@14", "assignment_opt", "call_void",
  "function_return", "read", "write", "write_expression_opt", "$@15",
  "decision_statement", "dec_else", "repetition_statement",
  "call_function", "func_options", "func_cont", "expression", "relop",
  "express_loop", "$@16", "$@17", "exp", "exp_loop", "$@18", "$@19",
  "term", "term_loop", "$@20", "$@21", "$@22", "factor", "sign", "call",
  "var_cte", "conditional", "nonconditional", YY_NULLPTR
  };

#if YYDEBUG
  const short
  parser::yyrline_[] =
  {
       0,   134,   134,   137,   140,   140,   144,   144,   145,   145,
     146,   147,   148,   149,   150,   151,   151,   152,   152,   157,
     158,   159,   166,   166,   169,   170,   171,   176,   176,   177,
     181,   189,   180,   190,   193,   197,   198,   201,   202,   207,
     208,   211,   210,   226,   227,   234,   235,   236,   237,   238,
     243,   244,   245,   248,   248,   251,   251,   254,   254,   255,
     256,   257,   258,   259,   263,   264,   263,   269,   270,   271,
     272,   276,   277,   278,   279,   280,   281,   282,   283,   287,
     286,   294,   297,   300,   303,   306,   307,   308,   309,   310,
     310,   313,   314,   315,   318,   318,   321,   322,   323,   324,
     325,   328,   329,   330,   331,   332,   333,   334,   335,   336,
     336,   337,   337,   338,   341,   342,   342,   343,   343,   344,
     347,   348,   348,   349,   349,   350,   350,   351,   354,   355,
     356,   357,   358,   359,   360,   361,   364,   365,   366,   369,
     372
  };

  // Print the state stack on the debug stream.
  void
  parser::yystack_print_ ()
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << int (i->state);
    *yycdebug_ << '\n';
  }

  // Report on the debug stream that the rule \a yyrule is going to be reduced.
  void
  parser::yy_reduce_print_ (int yyrule)
  {
    int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):\n";
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG


#line 6 "parser.yy"
} // yy
#line 1535 "parser.tab.cc"

#line 375 "parser.yy"

void yy::parser::error(const location_type& lugar, const std::string& lexema)
{
  std::cout << "SYNTAX ERROR !!! " << lexema << std::endl;
}
