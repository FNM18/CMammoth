// A Bison parser, made by GNU Bison 3.5.1.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2020 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// Undocumented macros, especially those whose name start with YY_,
// are private implementation details.  Do not rely on them.





#include "parser.tab.hh"


// Unqualified %code blocks.
#line 22 "parser.yy"

#include "driver.h"
#include <iostream>

#line 50 "parser.tab.cc"


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

// Whether we are compiled with exception support.
#ifndef YY_EXCEPTIONS
# if defined __GNUC__ && !defined __EXCEPTIONS
#  define YY_EXCEPTIONS 0
# else
#  define YY_EXCEPTIONS 1
# endif
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K].location)
/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

# ifndef YYLLOC_DEFAULT
#  define YYLLOC_DEFAULT(Current, Rhs, N)                               \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).begin  = YYRHSLOC (Rhs, 1).begin;                   \
          (Current).end    = YYRHSLOC (Rhs, N).end;                     \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).begin = (Current).end = YYRHSLOC (Rhs, 0).end;      \
        }                                                               \
    while (false)
# endif


// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << '\n';                       \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yystack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YYUSE (Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void> (0)
# define YY_STACK_PRINT()                static_cast<void> (0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)

#line 6 "parser.yy"
namespace yy {
#line 142 "parser.tab.cc"


  /* Return YYSTR after stripping away unnecessary quotes and
     backslashes, so that it's suitable for yyerror.  The heuristic is
     that double-quoting is unnecessary unless the string contains an
     apostrophe, a comma, or backslash (other than backslash-backslash).
     YYSTR is taken from yytname.  */
  std::string
  parser::yytnamerr_ (const char *yystr)
  {
    if (*yystr == '"')
      {
        std::string yyr;
        char const *yyp = yystr;

        for (;;)
          switch (*++yyp)
            {
            case '\'':
            case ',':
              goto do_not_strip_quotes;

            case '\\':
              if (*++yyp != '\\')
                goto do_not_strip_quotes;
              else
                goto append;

            append:
            default:
              yyr += *yyp;
              break;

            case '"':
              return yyr;
            }
      do_not_strip_quotes: ;
      }

    return yystr;
  }


  /// Build a parser object.
  parser::parser (parser_driver& driver_yyarg)
#if YYDEBUG
    : yydebug_ (false),
      yycdebug_ (&std::cerr),
#else
    :
#endif
      driver (driver_yyarg)
  {}

  parser::~parser ()
  {}

  parser::syntax_error::~syntax_error () YY_NOEXCEPT YY_NOTHROW
  {}

  /*---------------.
  | Symbol types.  |
  `---------------*/



  // by_state.
  parser::by_state::by_state () YY_NOEXCEPT
    : state (empty_state)
  {}

  parser::by_state::by_state (const by_state& that) YY_NOEXCEPT
    : state (that.state)
  {}

  void
  parser::by_state::clear () YY_NOEXCEPT
  {
    state = empty_state;
  }

  void
  parser::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  parser::by_state::by_state (state_type s) YY_NOEXCEPT
    : state (s)
  {}

  parser::symbol_number_type
  parser::by_state::type_get () const YY_NOEXCEPT
  {
    if (state == empty_state)
      return empty_symbol;
    else
      return yystos_[+state];
  }

  parser::stack_symbol_type::stack_symbol_type ()
  {}

  parser::stack_symbol_type::stack_symbol_type (YY_RVREF (stack_symbol_type) that)
    : super_type (YY_MOVE (that.state), YY_MOVE (that.location))
  {
    switch (that.type_get ())
    {
      case 55: // INT
      case 56: // FLOAT
        value.YY_MOVE_OR_COPY< float > (YY_MOVE (that.value));
        break;

      case 52: // ID
      case 53: // STRING
      case 54: // CHAR
        value.YY_MOVE_OR_COPY< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

#if 201103L <= YY_CPLUSPLUS
    // that is emptied.
    that.state = empty_state;
#endif
  }

  parser::stack_symbol_type::stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) that)
    : super_type (s, YY_MOVE (that.location))
  {
    switch (that.type_get ())
    {
      case 55: // INT
      case 56: // FLOAT
        value.move< float > (YY_MOVE (that.value));
        break;

      case 52: // ID
      case 53: // STRING
      case 54: // CHAR
        value.move< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

    // that is emptied.
    that.type = empty_symbol;
  }

#if YY_CPLUSPLUS < 201103L
  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
    switch (that.type_get ())
    {
      case 55: // INT
      case 56: // FLOAT
        value.copy< float > (that.value);
        break;

      case 52: // ID
      case 53: // STRING
      case 54: // CHAR
        value.copy< std::string > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    return *this;
  }

  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (stack_symbol_type& that)
  {
    state = that.state;
    switch (that.type_get ())
    {
      case 55: // INT
      case 56: // FLOAT
        value.move< float > (that.value);
        break;

      case 52: // ID
      case 53: // STRING
      case 54: // CHAR
        value.move< std::string > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    // that is emptied.
    that.state = empty_state;
    return *this;
  }
#endif

  template <typename Base>
  void
  parser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);
  }

#if YYDEBUG
  template <typename Base>
  void
  parser::yy_print_ (std::ostream& yyo,
                                     const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YYUSE (yyoutput);
    symbol_number_type yytype = yysym.type_get ();
#if defined __GNUC__ && ! defined __clang__ && ! defined __ICC && __GNUC__ * 100 + __GNUC_MINOR__ <= 408
    // Avoid a (spurious) G++ 4.8 warning about "array subscript is
    // below array bounds".
    if (yysym.empty ())
      std::abort ();
#endif
    yyo << (yytype < yyntokens_ ? "token" : "nterm")
        << ' ' << yytname_[yytype] << " ("
        << yysym.location << ": ";
    switch (yytype)
    {
      case 52: // ID
#line 122 "parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 382 "parser.tab.cc"
        break;

      case 53: // STRING
#line 122 "parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 388 "parser.tab.cc"
        break;

      case 54: // CHAR
#line 122 "parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 394 "parser.tab.cc"
        break;

      case 55: // INT
#line 122 "parser.yy"
                 { yyoutput << yysym.value.template as < float > (); }
#line 400 "parser.tab.cc"
        break;

      case 56: // FLOAT
#line 122 "parser.yy"
                 { yyoutput << yysym.value.template as < float > (); }
#line 406 "parser.tab.cc"
        break;

      default:
        break;
    }
    yyo << ')';
  }
#endif

  void
  parser::yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym)
  {
    if (m)
      YY_SYMBOL_PRINT (m, sym);
    yystack_.push (YY_MOVE (sym));
  }

  void
  parser::yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym)
  {
#if 201103L <= YY_CPLUSPLUS
    yypush_ (m, stack_symbol_type (s, std::move (sym)));
#else
    stack_symbol_type ss (s, sym);
    yypush_ (m, ss);
#endif
  }

  void
  parser::yypop_ (int n)
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  parser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  parser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  parser::debug_level_type
  parser::debug_level () const
  {
    return yydebug_;
  }

  void
  parser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  parser::state_type
  parser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - yyntokens_] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - yyntokens_];
  }

  bool
  parser::yy_pact_value_is_default_ (int yyvalue)
  {
    return yyvalue == yypact_ninf_;
  }

  bool
  parser::yy_table_value_is_error_ (int yyvalue)
  {
    return yyvalue == yytable_ninf_;
  }

  int
  parser::operator() ()
  {
    return parse ();
  }

  int
  parser::parse ()
  {
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The locations where the error started and ended.
    stack_symbol_type yyerror_range[3];

    /// The return value of parse ().
    int yyresult;

#if YY_EXCEPTIONS
    try
#endif // YY_EXCEPTIONS
      {
    YYCDEBUG << "Starting parse\n";


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, YY_MOVE (yyla));

  /*-----------------------------------------------.
  | yynewstate -- push a new symbol on the stack.  |
  `-----------------------------------------------*/
  yynewstate:
    YYCDEBUG << "Entering state " << int (yystack_[0].state) << '\n';

    // Accept?
    if (yystack_[0].state == yyfinal_)
      YYACCEPT;

    goto yybackup;


  /*-----------.
  | yybackup.  |
  `-----------*/
  yybackup:
    // Try to take a decision without lookahead.
    yyn = yypact_[+yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token: ";
#if YY_EXCEPTIONS
        try
#endif // YY_EXCEPTIONS
          {
            symbol_type yylookahead (yylex (driver));
            yyla.move (yylookahead);
          }
#if YY_EXCEPTIONS
        catch (const syntax_error& yyexc)
          {
            YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
            error (yyexc);
            goto yyerrlab1;
          }
#endif // YY_EXCEPTIONS
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.type_get ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.type_get ())
      {
        goto yydefault;
      }

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", state_type (yyn), YY_MOVE (yyla));
    goto yynewstate;


  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[+yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;


  /*-----------------------------.
  | yyreduce -- do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_ (yystack_[yylen].state, yyr1_[yyn]);
      /* Variants are always initialized to an empty instance of the
         correct type. The default '$$ = $1' action is NOT applied
         when using variants.  */
      switch (yyr1_[yyn])
    {
      case 55: // INT
      case 56: // FLOAT
        yylhs.value.emplace< float > ();
        break;

      case 52: // ID
      case 53: // STRING
      case 54: // CHAR
        yylhs.value.emplace< std::string > ();
        break;

      default:
        break;
    }


      // Default location.
      {
        stack_type::slice range (yystack_, yylen);
        YYLLOC_DEFAULT (yylhs.location, range, yylen);
        yyerror_range[1].location = yylhs.location;
      }

      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
#if YY_EXCEPTIONS
      try
#endif // YY_EXCEPTIONS
        {
          switch (yyn)
            {
  case 4:
#line 133 "parser.yy"
                      {cout << "Program id : " << yystack_[0].value.as < std::string > () << endl;}
#line 658 "parser.tab.cc"
    break;

  case 6:
#line 137 "parser.yy"
                 {cout << "Nombre de variable : " << yystack_[0].value.as < std::string > () << endl;}
#line 664 "parser.tab.cc"
    break;

  case 8:
#line 138 "parser.yy"
                          {cout << "Nombre de variable : " << yystack_[0].value.as < std::string > () << endl;}
#line 670 "parser.tab.cc"
    break;

  case 15:
#line 144 "parser.yy"
                          {cout << "Nombre de variable : " << yystack_[0].value.as < std::string > () << endl;}
#line 676 "parser.tab.cc"
    break;

  case 17:
#line 145 "parser.yy"
                          {cout << "Nombre de variable : " << yystack_[0].value.as < std::string > () << endl;}
#line 682 "parser.tab.cc"
    break;

  case 26:
#line 169 "parser.yy"
                   {cout << "Clase id : " << yystack_[0].value.as < std::string > () << endl;}
#line 688 "parser.tab.cc"
    break;

  case 29:
#line 173 "parser.yy"
                                   {cout << "Funcion id : " << yystack_[0].value.as < std::string > () << endl;}
#line 694 "parser.tab.cc"
    break;

  case 35:
#line 185 "parser.yy"
                        {cout << "Herencia id : " << yystack_[0].value.as < std::string > () << endl;}
#line 700 "parser.tab.cc"
    break;

  case 60:
#line 229 "parser.yy"
                {cout << "Nombre de parametro : " << yystack_[0].value.as < std::string > () << endl;}
#line 706 "parser.tab.cc"
    break;

  case 80:
#line 261 "parser.yy"
                              {cout << "Constante string : " << yystack_[0].value.as < std::string > () << endl;}
#line 712 "parser.tab.cc"
    break;

  case 83:
#line 264 "parser.yy"
                         {cout << "Constante string : " << yystack_[0].value.as < std::string > () << endl;}
#line 718 "parser.tab.cc"
    break;

  case 123:
#line 319 "parser.yy"
              {cout << "Constante int : " << yystack_[0].value.as < float > () << endl;}
#line 724 "parser.tab.cc"
    break;

  case 124:
#line 320 "parser.yy"
                {cout << "Constante float : " << yystack_[0].value.as < float > () << endl;}
#line 730 "parser.tab.cc"
    break;

  case 125:
#line 321 "parser.yy"
               {cout << "Constante char : " << yystack_[0].value.as < std::string > () << endl;}
#line 736 "parser.tab.cc"
    break;


#line 740 "parser.tab.cc"

            default:
              break;
            }
        }
#if YY_EXCEPTIONS
      catch (const syntax_error& yyexc)
        {
          YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
          error (yyexc);
          YYERROR;
        }
#endif // YY_EXCEPTIONS
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;
      YY_STACK_PRINT ();

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, YY_MOVE (yylhs));
    }
    goto yynewstate;


  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        error (yyla.location, yysyntax_error_ (yystack_[0].state, yyla));
      }


    yyerror_range[1].location = yyla.location;
    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.type_get () == yyeof_)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:
    /* Pacify compilers when the user code never invokes YYERROR and
       the label yyerrorlab therefore never appears in user code.  */
    if (false)
      YYERROR;

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    goto yyerrlab1;


  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    {
      stack_symbol_type error_token;
      for (;;)
        {
          yyn = yypact_[+yystack_[0].state];
          if (!yy_pact_value_is_default_ (yyn))
            {
              yyn += yy_error_token_;
              if (0 <= yyn && yyn <= yylast_ && yycheck_[yyn] == yy_error_token_)
                {
                  yyn = yytable_[yyn];
                  if (0 < yyn)
                    break;
                }
            }

          // Pop the current state because it cannot handle the error token.
          if (yystack_.size () == 1)
            YYABORT;

          yyerror_range[1].location = yystack_[0].location;
          yy_destroy_ ("Error: popping", yystack_[0]);
          yypop_ ();
          YY_STACK_PRINT ();
        }

      yyerror_range[2].location = yyla.location;
      YYLLOC_DEFAULT (error_token.location, yyerror_range, 2);

      // Shift the error token.
      error_token.state = state_type (yyn);
      yypush_ ("Shifting", YY_MOVE (error_token));
    }
    goto yynewstate;


  /*-------------------------------------.
  | yyacceptlab -- YYACCEPT comes here.  |
  `-------------------------------------*/
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;


  /*-----------------------------------.
  | yyabortlab -- YYABORT comes here.  |
  `-----------------------------------*/
  yyabortlab:
    yyresult = 1;
    goto yyreturn;


  /*-----------------------------------------------------.
  | yyreturn -- parsing is finished, return the result.  |
  `-----------------------------------------------------*/
  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
#if YY_EXCEPTIONS
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack\n";
        // Do not try to display the values of the reclaimed symbols,
        // as their printers might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
#endif // YY_EXCEPTIONS
  }

  void
  parser::error (const syntax_error& yyexc)
  {
    error (yyexc.location, yyexc.what ());
  }

  // Generate an error message.
  std::string
  parser::yysyntax_error_ (state_type yystate, const symbol_type& yyla) const
  {
    // Number of reported tokens (one for the "unexpected", one per
    // "expected").
    std::ptrdiff_t yycount = 0;
    // Its maximum.
    enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
    // Arguments of yyformat.
    char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];

    /* There are many possibilities here to consider:
       - If this state is a consistent state with a default action, then
         the only way this function was invoked is if the default action
         is an error action.  In that case, don't check for expected
         tokens because there are none.
       - The only way there can be no lookahead present (in yyla) is
         if this state is a consistent state with a default action.
         Thus, detecting the absence of a lookahead is sufficient to
         determine that there is no unexpected or expected token to
         report.  In that case, just report a simple "syntax error".
       - Don't assume there isn't a lookahead just because this state is
         a consistent state with a default action.  There might have
         been a previous inconsistent state, consistent state with a
         non-default action, or user semantic action that manipulated
         yyla.  (However, yyla is currently not documented for users.)
       - Of course, the expected token list depends on states to have
         correct lookahead information, and it depends on the parser not
         to perform extra reductions after fetching a lookahead from the
         scanner and before detecting a syntax error.  Thus, state merging
         (from LALR or IELR) and default reductions corrupt the expected
         token list.  However, the list is correct for canonical LR with
         one exception: it will still contain any token that will not be
         accepted due to an error action in a later state.
    */
    if (!yyla.empty ())
      {
        symbol_number_type yytoken = yyla.type_get ();
        yyarg[yycount++] = yytname_[yytoken];

        int yyn = yypact_[+yystate];
        if (!yy_pact_value_is_default_ (yyn))
          {
            /* Start YYX at -YYN if negative to avoid negative indexes in
               YYCHECK.  In other words, skip the first -YYN actions for
               this state because they are default actions.  */
            int yyxbegin = yyn < 0 ? -yyn : 0;
            // Stay within bounds of both yycheck and yytname.
            int yychecklim = yylast_ - yyn + 1;
            int yyxend = yychecklim < yyntokens_ ? yychecklim : yyntokens_;
            for (int yyx = yyxbegin; yyx < yyxend; ++yyx)
              if (yycheck_[yyx + yyn] == yyx && yyx != yy_error_token_
                  && !yy_table_value_is_error_ (yytable_[yyx + yyn]))
                {
                  if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                    {
                      yycount = 1;
                      break;
                    }
                  else
                    yyarg[yycount++] = yytname_[yyx];
                }
          }
      }

    char const* yyformat = YY_NULLPTR;
    switch (yycount)
      {
#define YYCASE_(N, S)                         \
        case N:                               \
          yyformat = S;                       \
        break
      default: // Avoid compiler warnings.
        YYCASE_ (0, YY_("syntax error"));
        YYCASE_ (1, YY_("syntax error, unexpected %s"));
        YYCASE_ (2, YY_("syntax error, unexpected %s, expecting %s"));
        YYCASE_ (3, YY_("syntax error, unexpected %s, expecting %s or %s"));
        YYCASE_ (4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
        YYCASE_ (5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
      }

    std::string yyres;
    // Argument number.
    std::ptrdiff_t yyi = 0;
    for (char const* yyp = yyformat; *yyp; ++yyp)
      if (yyp[0] == '%' && yyp[1] == 's' && yyi < yycount)
        {
          yyres += yytnamerr_ (yyarg[yyi++]);
          ++yyp;
        }
      else
        yyres += *yyp;
    return yyres;
  }


  const short parser::yypact_ninf_ = -184;

  const signed char parser::yytable_ninf_ = -84;

  const short
  parser::yypact_[] =
  {
      23,   -29,    38,  -184,  -184,  -184,    49,    39,    29,  -184,
      62,  -184,    44,  -184,    63,    88,  -184,    95,  -184,  -184,
    -184,  -184,  -184,  -184,    93,  -184,    90,    79,  -184,   122,
      74,    44,   126,  -184,    89,  -184,   108,    97,     6,    28,
    -184,  -184,  -184,    33,  -184,  -184,  -184,   130,  -184,    44,
    -184,   116,  -184,  -184,  -184,  -184,    28,  -184,  -184,  -184,
    -184,   146,    61,    -6,    19,   101,    68,  -184,   144,   141,
     149,  -184,    63,  -184,   147,    74,   142,    71,    28,  -184,
     148,    28,    28,  -184,  -184,    28,    28,    28,  -184,  -184,
      54,  -184,  -184,  -184,  -184,  -184,  -184,  -184,   150,  -184,
     -12,   107,    44,  -184,   153,  -184,  -184,  -184,  -184,  -184,
    -184,  -184,  -184,    28,  -184,  -184,  -184,  -184,  -184,  -184,
    -184,   111,    28,  -184,   159,   161,  -184,  -184,    33,   155,
     154,   154,   157,   158,   160,   117,    55,  -184,   151,   164,
     -12,   -12,   -12,   -12,   -12,   -12,   -12,  -184,  -184,  -184,
     165,  -184,  -184,  -184,    39,    70,  -184,  -184,   170,   117,
    -184,  -184,   129,  -184,  -184,  -184,  -184,   175,   176,     8,
      28,    28,    67,   162,   117,   178,    28,  -184,  -184,  -184,
    -184,  -184,  -184,  -184,  -184,   155,    62,  -184,    28,    28,
    -184,  -184,    28,  -184,   171,  -184,    20,  -184,  -184,  -184,
     181,   173,   184,   177,   179,    28,  -184,   186,  -184,  -184,
    -184,   183,   185,  -184,  -184,   170,  -184,   129,   190,   192,
       8,   152,   156,   163,  -184,     6,   -12,  -184,     8,  -184,
    -184,   187,   191,    28,   194,   193,  -184,   -12,   -12,   166,
     107,  -184,  -184,   195,   196,   198,   200,  -184,    63,   167,
    -184,   -12,  -184,   201,  -184,  -184,   203,   -12,  -184,   204,
    -184
  };

  const signed char
  parser::yydefact_[] =
  {
       0,     0,     0,     2,     4,     1,     0,     3,     0,    28,
       3,    26,     0,    38,     3,     3,     6,     0,    37,    53,
      47,    48,    49,    31,     0,    52,     0,     0,    36,     0,
       0,     3,     0,     5,     0,    35,     3,     0,     0,     3,
       7,    10,    11,     0,    41,    40,    39,     0,    29,     0,
      43,     3,     8,    51,    50,    12,     3,   117,   118,   119,
     115,     3,     3,     3,     0,     0,     0,    13,     0,     0,
       0,    42,     3,    34,     0,     0,     0,    96,     3,    21,
       0,     3,     3,   109,   106,     3,     3,     3,   114,   110,
       3,   125,   123,   124,   122,   121,   116,   120,    15,    14,
       3,     0,     3,    33,     0,     9,    22,    97,    99,   100,
     101,   102,    98,     3,    20,    19,   107,   108,   111,   112,
     113,     0,     3,    57,     3,     3,    54,    90,     0,     0,
       0,     0,     0,     0,     0,     0,     3,    73,     0,     0,
       3,     3,     3,     3,     3,     3,     3,    88,    89,    60,
       0,    46,    45,    44,     3,     3,    55,    91,     3,     0,
      59,    56,     0,    94,    92,    16,    18,     0,     0,     3,
       3,     3,     3,     0,     0,     0,     3,    32,    66,    67,
      68,    69,    70,    71,    72,     3,     3,    27,     3,     3,
     105,    95,     3,    25,     0,    58,     0,    93,    77,    78,
      80,     0,    81,     0,     0,     3,    76,     0,    75,    65,
      64,     0,     0,   103,   104,     3,    23,     0,     0,     0,
       3,     0,     0,     0,    74,     0,     3,    24,     3,    79,
      82,     0,     0,     3,     3,     0,    84,     3,     3,     0,
       0,    63,    61,     0,     0,     0,     0,    62,     3,     3,
     126,     3,    30,     0,    87,    85,     0,     3,   127,     0,
      86
  };

  const short
  parser::yypgoto_[] =
  {
    -184,  -184,    -7,  -184,  -184,   -40,  -184,   143,  -184,  -184,
      76,    92,  -184,  -184,   -72,  -184,   -16,    81,     7,    69,
    -184,   -71,  -184,  -184,  -184,  -184,    35,   197,  -184,  -184,
     123,  -184,   -36,    -1,  -184,   -58,  -184,  -184,   -14,  -184,
    -184,  -184,  -129,  -184,  -184,  -184,  -184,  -184,  -184,  -183,
    -184,  -184,  -184,  -184,   -59,  -184,  -184,   -46,  -184,  -184,
     -35,  -184,    34,  -184,  -184,  -184,  -184,  -184,  -184,  -184
  };

  const short
  parser::yydefgoto_[] =
  {
      -1,     2,    59,     3,     6,    17,    30,    40,    75,    41,
      42,    67,   128,   129,    43,    80,    60,   125,   194,    10,
      15,    24,    69,    33,    74,    29,    14,    18,    46,    51,
      71,   153,    25,    55,    26,   138,   126,   161,   150,   185,
     242,   211,   139,   140,   207,   141,   142,   143,   144,   201,
     218,   145,   255,   146,   157,   127,   164,   202,   113,   191,
      77,    84,    62,    89,    63,    64,    96,    97,   147,   148
  };

  const short
  parser::yytable_[] =
  {
       9,   103,    54,    13,    61,    95,    94,    23,    28,    70,
      76,   178,   179,   180,   181,   182,   183,   184,   124,    85,
      86,    87,    56,     4,    44,   217,   130,   131,   132,    50,
      99,    57,    58,   133,   122,   134,   135,   230,     5,    65,
     136,    66,    56,   114,    73,   236,   116,   117,    20,    21,
      22,    57,    58,     1,    79,    83,    88,     7,    53,   121,
     174,   200,    70,   156,   124,    23,    39,    39,   122,   122,
       8,    90,   174,    91,    92,    93,   158,   173,   155,    39,
      37,    11,    38,   123,    81,    82,    39,   107,   108,   109,
     110,   111,   112,   137,    12,   151,    16,   235,   188,   189,
     124,   195,    31,   197,    19,    20,    21,    22,   244,   245,
      20,    21,    22,   210,   167,   168,   156,   160,   163,   118,
     119,   120,   256,    27,   203,   204,    32,    34,   259,   123,
     208,    35,    36,   137,   137,   137,   137,   137,   137,   137,
      47,    48,   213,   214,    49,    68,   215,     9,   190,    52,
      72,   193,    78,    98,   100,   101,   102,   106,   104,   149,
     154,   115,   -17,    90,   159,   123,   162,    39,    56,   172,
     223,   169,   170,   176,   171,   177,   192,   252,   209,    13,
     186,   196,   198,   199,   205,   206,   216,   -83,   219,    54,
     220,   225,   221,   224,   222,   226,   228,   237,   239,   229,
     240,   238,   248,   231,   243,   166,   232,   249,   193,   250,
     251,   257,   233,   253,   258,   260,   246,   175,   105,   137,
     165,   212,   227,   187,   234,   152,   247,   241,    45,     0,
     137,   137,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    23,   254,     0,   137,     0,     0,     0,     0,     0,
     137
  };

  const short
  parser::yycheck_[] =
  {
       7,    72,    38,    10,    39,    64,    64,    14,    15,    49,
      56,   140,   141,   142,   143,   144,   145,   146,    90,    25,
      26,    27,    14,    52,    31,     5,    38,    39,    40,    36,
      66,    23,    24,    45,    14,    47,    48,   220,     0,     6,
      52,     8,    14,    78,    51,   228,    81,    82,    42,    43,
      44,    23,    24,    30,    61,    62,    63,     8,    52,     5,
       5,    53,   102,   121,   136,    72,    12,    12,    14,    14,
      31,    52,     5,    54,    55,    56,   122,   135,   113,    12,
       6,    52,     8,    90,    23,    24,    12,    16,    17,    18,
      19,    20,    21,   100,    32,   102,    52,   226,    28,    29,
     172,   159,     7,   162,    41,    42,    43,    44,   237,   238,
      42,    43,    44,   185,   130,   131,   174,   124,   125,    85,
      86,    87,   251,    35,   170,   171,    33,    37,   257,   136,
     176,    52,    10,   140,   141,   142,   143,   144,   145,   146,
      14,    52,   188,   189,    36,    15,   192,   154,   155,    52,
      34,   158,     6,    52,    10,    14,     7,    15,    11,    52,
       7,    13,    12,    52,     5,   172,     5,    12,    14,    52,
     205,    14,    14,    22,    14,    11,     6,   248,   185,   186,
      15,    52,     7,     7,    22,     7,    15,     6,    15,   225,
       6,     8,    15,     7,    15,    10,     6,    10,   233,     7,
       6,    10,     7,    51,    11,   129,    50,    11,   215,    11,
      10,    10,    49,    46,    11,    11,    50,   136,    75,   226,
     128,   186,   215,   154,   225,   102,   240,   234,    31,    -1,
     237,   238,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   248,   249,    -1,   251,    -1,    -1,    -1,    -1,    -1,
     257
  };

  const signed char
  parser::yystos_[] =
  {
       0,    30,    58,    60,    52,     0,    61,     8,    31,    59,
      76,    52,    32,    59,    83,    77,    52,    62,    84,    41,
      42,    43,    44,    59,    78,    89,    91,    35,    59,    82,
      63,     7,    33,    80,    37,    52,    10,     6,     8,    12,
      64,    66,    67,    71,    59,    84,    85,    14,    52,    36,
      59,    86,    52,    52,    89,    90,    14,    23,    24,    59,
      73,   117,   119,   121,   122,     6,     8,    68,    15,    79,
      62,    87,    34,    59,    81,    65,   114,   117,     6,    59,
      72,    23,    24,    59,   118,    25,    26,    27,    59,   120,
      52,    54,    55,    56,    92,   111,   123,   124,    52,    89,
      10,    14,     7,    78,    11,    64,    15,    16,    17,    18,
      19,    20,    21,   115,   117,    13,   117,   117,   119,   119,
     119,     5,    14,    59,    71,    74,    93,   112,    69,    70,
      38,    39,    40,    45,    47,    48,    52,    59,    92,    99,
     100,   102,   103,   104,   105,   108,   110,   125,   126,    52,
      95,    59,    87,    88,     7,   117,    92,   111,   114,     5,
      59,    94,     5,    59,   113,    68,    67,    73,    73,    14,
      14,    14,    52,    92,     5,    74,    22,    11,    99,    99,
      99,    99,    99,    99,    99,    96,    15,    76,    28,    29,
      59,   116,     6,    59,    75,    92,    52,   111,     7,     7,
      53,   106,   114,   114,   114,    22,     7,   101,   114,    59,
      71,    98,    83,   114,   114,   114,    15,     5,   107,    15,
       6,    15,    15,   117,     7,     8,    10,    75,     6,     7,
     106,    51,    50,    49,    90,    99,   106,    10,    10,   117,
       6,    59,    97,    11,    99,    99,    50,    95,     7,    11,
      11,    10,    78,    46,    59,   109,    99,    10,    11,    99,
      11
  };

  const signed char
  parser::yyr1_[] =
  {
       0,    57,    58,    59,    61,    60,    63,    62,    65,    64,
      64,    66,    66,    67,    68,    69,    68,    70,    68,    71,
      72,    72,    73,    74,    75,    75,    77,    76,    76,    79,
      78,    78,    80,    81,    81,    82,    82,    83,    83,    84,
      85,    85,    86,    86,    87,    88,    88,    89,    89,    89,
      90,    90,    91,    91,    92,    93,    93,    93,    94,    94,
      96,    95,    97,    97,    98,    98,    99,    99,    99,    99,
      99,    99,    99,    99,   100,   101,   102,   103,   104,   105,
     106,   106,   106,   107,   106,   108,   109,   109,   110,   110,
     111,   112,   112,   113,   113,   114,   114,   115,   115,   115,
     115,   115,   115,   116,   116,   116,   117,   118,   118,   118,
     119,   120,   120,   120,   120,   121,   121,   122,   122,   122,
     123,   123,   123,   124,   124,   124,   125,   126
  };

  const signed char
  parser::yyr2_[] =
  {
       0,     2,     1,     0,     0,     8,     0,     3,     0,     4,
       1,     1,     2,     2,     2,     0,     4,     0,     4,     4,
       2,     1,     3,     4,     3,     1,     0,    10,     1,     0,
      13,     1,     6,     2,     1,     2,     1,     2,     1,     3,
       1,     1,     2,     1,     3,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     2,     2,     2,     1,     2,     1,
       0,     6,     2,     1,     1,     1,     2,     2,     2,     2,
       2,     2,     2,     1,     4,     1,     3,     3,     3,     5,
       1,     1,     3,     0,     4,     9,     4,     1,     1,     1,
       2,     2,     2,     2,     1,     4,     1,     1,     1,     1,
       1,     1,     1,     2,     2,     1,     2,     2,     2,     1,
       2,     2,     2,     2,     1,     1,     2,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     8,    10
  };



  // YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
  // First, the terminals, then, starting at \a yyntokens_, nonterminals.
  const char*
  const parser::yytname_[] =
  {
  "\"eof\"", "error", "$undefined", "COMENTARIO", "SIMBOLO", "PUNTO",
  "COMA", "SCOL", "COL", "GBAJO", "LCUR", "RCUR", "LBRA", "RBRA", "LPAR",
  "RPAR", "EQ", "GE", "LE", "GT", "LT", "NE", "ASSIGN", "SUM", "RES",
  "MUL", "DIV", "MOD", "AND", "OR", "PROGRAMA", "CLASE", "VARIABLES",
  "MAIN", "METODOS", "HEREDA", "ATRIBUTOS", "FUNCION", "RETORNAR", "LEER",
  "ESCRIBIR", "VOID", "INT_T", "FLOAT_T", "CHAR_T", "SI", "SINO",
  "MIENTRAS", "PARA", "EN", "HACER", "ENTONCES", "ID", "STRING", "CHAR",
  "INT", "FLOAT", "$accept", "script", "empty", "program", "$@1",
  "declare_var", "$@2", "declare_bridge1", "$@3", "declare_bridge2",
  "declare_bridge3", "declare_bridge4", "$@4", "$@5", "dimensions",
  "matrix", "single_express", "mult_express", "expression_loop", "classes",
  "$@6", "functions", "$@7", "main", "methods", "inheritance", "variables",
  "var_bridge1", "var_bridge2", "attributes", "attr_bridge1",
  "attr_bridge2", "primitive_type", "var_type", "return_type", "call_var",
  "call_options", "call_cont", "parameters", "$@8", "par_cont",
  "par_array", "statutes", "assignment", "assignment_opt", "call_void",
  "function_return", "read", "write", "write_expression_opt", "$@9",
  "decision_statement", "dec_else", "repetition_statement",
  "call_function", "func_options", "func_cont", "expression", "relop",
  "express_loop", "exp", "exp_loop", "term", "term_loop", "factor", "sign",
  "call", "var_cte", "conditional", "nonconditional", YY_NULLPTR
  };

#if YYDEBUG
  const short
  parser::yyrline_[] =
  {
       0,   127,   127,   130,   133,   133,   137,   137,   138,   138,
     139,   140,   141,   142,   143,   144,   144,   145,   145,   150,
     151,   152,   159,   162,   163,   164,   169,   169,   170,   173,
     173,   174,   177,   181,   182,   185,   186,   191,   192,   193,
     194,   195,   202,   203,   204,   205,   206,   211,   211,   211,
     214,   214,   217,   217,   220,   221,   222,   223,   224,   225,
     229,   229,   230,   231,   232,   233,   237,   238,   239,   240,
     241,   242,   243,   244,   247,   248,   251,   254,   257,   260,
     261,   262,   263,   264,   264,   267,   268,   269,   273,   273,
     276,   277,   278,   279,   280,   283,   284,   285,   286,   287,
     288,   289,   290,   291,   292,   293,   296,   297,   298,   299,
     302,   303,   304,   305,   306,   309,   310,   311,   312,   313,
     314,   315,   316,   319,   320,   321,   324,   327
  };

  // Print the state stack on the debug stream.
  void
  parser::yystack_print_ ()
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << int (i->state);
    *yycdebug_ << '\n';
  }

  // Report on the debug stream that the rule \a yyrule is going to be reduced.
  void
  parser::yy_reduce_print_ (int yyrule)
  {
    int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):\n";
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG


#line 6 "parser.yy"
} // yy
#line 1314 "parser.tab.cc"

#line 330 "parser.yy"

void yy::parser::error(const location_type& lugar, const std::string& lexema)
{
  std::cout << "SYNTAX ERROR !!! " << lexema << std::endl;
}
