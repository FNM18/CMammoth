#!/bin/bash

c++ main.cpp Scanner.cpp driver.cpp parser.tab.cc
./a.out