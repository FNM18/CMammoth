#include <stdio.h>
#include "driver.h"
#include "semantic.cpp"

using namespace std;

int main(){
  
  //Pruebas de scope
  Scope scope = Scope();
  //Se genera metodo global main
  scope.globalInsert("global","void","function");
  scope.installGlobalVars("global");
  scope.changeCurrentState(0,"global");
  scope.insertLocalVariable("joe biden","int","15");
  //Se genera clase asignada
  scope.globalInsert("Persona", "class","class");
  scope.installGlobalClassDir("Persona");
  scope.changeCurrentState(1,"Persona");
  scope.installFunctionDir();
  //Fin pruebas de scope
  

  //SemanticConsideration sc = SemanticConsideration();
  //sc.testCube(sc.varType::Float,sc.varType::Int,sc.opType::Sum);

  //Analizador sintactico
  parser_driver driver;
  if(!driver.parse("test.txt"))  
    printf("\n\nInput Accepted\n\n");
}
