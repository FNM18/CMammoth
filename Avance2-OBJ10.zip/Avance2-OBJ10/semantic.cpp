#include <string>
#include "driver.h"
using namespace std;

class ClassTable;
class FunctionTable;
class VarTable;

//Tabla de clases heredada de SymbolTable que genera una clase
//Esta clase puede generar una tabla de funciones para guardar sus respectivas variables y funciones internas
class ClassTable : public SymbolTable{
  public:
  struct symbolRow{
      string name;
      //VarTable * varTable;
      FunctionTable * functionTable;
      ClassTable * inheritance;
  };
  symbolRow * classRow;
  ClassTable(string name){
    setType("class");
    classRow = new symbolRow();
    classRow->name = name;
    classRow->functionTable = NULL;
    classRow->inheritance = NULL;
    cout << "Class table initialized" << endl;
  };

  string getType(){
    string g = ClassTable::type;
    return g;
  }

  void setType(string type){
    ClassTable::type = type;
  }
};

//Tabla de variables heredada de SymbolTable que genera un mapa de variables
//Cada renglon de variable puede guardar diferentes variables y su respectivo valor
class VarTable : public SymbolTable{
  public:
    struct symbolRow{
      string name;
      string type;
      string value;
      //void * value;
    };

    VarTable(){
      setType("variable");
      cout << "Variable table initialized" << endl;
    };

    string getType(){
      string g = VarTable::type;
      return g;
    }

    void setType(string type){
      VarTable::type = type;
    }

    void insert(struct symbolRow * row){
      if(lookup(row)){
        throw runtime_error("Error, it's already declared!");
      }
      cout << "Name: " << (*row).name << endl;
      cout << "Type: " << (*row).type << endl;
      cout << "Value: " << (*row).value << endl;
      VarTable::umap[(*row).name] = row;
    }

    int lookup(symbolRow * row){
      symbolRow * exist = VarTable::umap[(*row).name];
      if(exist != NULL){
        cout << "Exists!" << endl;
        cout << "Name: " << (*exist).name << endl;
        return 1;
      }
      return 0;
    }

    symbolRow * find(string row){
      symbolRow * exist = VarTable::umap[row];
      if(exist != NULL){
        cout << "Exists!" << endl;
        cout << "Name: " << (*exist).name << endl;
        return exist;
      }
      return NULL;
    }

    void modify(struct symbolRow * row){
      struct symbolRow * exist = VarTable::umap[(*row).name];
      if(exist != NULL){
        (*exist).type = (*row).type;
        //(*exist).role = (*row).role;
        (*exist).value = (*row).value;
      }
    }
  protected:
    unordered_map<string, symbolRow*> umap;
};

//Tabla de funciones heredada de SymbolTable que genera un mapa de funciones
//Cada renglon de funcion puede guardar una tabla de clase o una tabla de variables
class FunctionTable : public SymbolTable{
  public:
    struct symbolRow{
      string name;
      string return_type;
      string scope;
      string role;
      VarTable * varTable;
      ClassTable * classTable;
    };

    FunctionTable(){
      setType("function");
      cout << "Function table initialized" << endl;
    };

    string getType(){
      string g = FunctionTable::type;
      return g;
    }

    void setType(string type){
      FunctionTable::type = type;
    }

    void insert(struct symbolRow * row){
      if(lookup(row)){
        throw runtime_error("Error, it's already declared!");
      }
      cout << "Name: " << (*row).name << endl;
      cout << "Return_type: " << (*row).return_type << endl;
      cout << "Role: " << (*row).role << endl;
      cout << "Scope: " << (*row).scope << endl;
      umap[(*row).name] = row;
    }

    int lookup(symbolRow * row){
      symbolRow * exist = FunctionTable::umap[(*row).name];
      if(exist != NULL){
        cout << "Exists!" << endl;
        cout << "Name: " << (*exist).name << endl;
        return 1;
      }
      return 0;
    }

    symbolRow * find(string row){
      symbolRow * exist = umap[row];
      if(exist != NULL){
        cout << "Exists!" << endl;
        return exist;
      }
      return NULL;
    }

    void modify(struct symbolRow * row){
      struct symbolRow * exist = FunctionTable::umap[(*row).name];
      if(exist != NULL){
        (*exist).return_type = (*row).return_type;
        (*exist).role = (*row).role;
        (*exist).scope = (*row).scope;
        (*exist).varTable = (*row).varTable;
        (*exist).classTable = (*row).classTable;
      }
    }
  protected:
    unordered_map<string, symbolRow*> umap;
};

//Clase para verificar estados y manipulacion de las tablas.
class Scope{
  public:
    string currentState = "global";
    string currentRole = "function";
    SymbolTable * currentTable;
    FunctionTable globalTable;
    
    Scope(){
      currentTable = &globalTable;
    };

    void restartState(){
      currentTable = &globalTable;
      currentRole = "function";
      currentState = "global";
    }

    void changeCurrentState(int root, string name){
      if(root){
        restartState();
      }
      if(currentRole == "function"){
        FunctionTable * ft = (FunctionTable *) currentTable;
        FunctionTable::symbolRow * srow = ft->find(name);
        if(!srow){
          throw runtime_error("Error, variable, class or function doesn't exist.");
        }
        if(srow->role == "class"){
          currentTable = srow->classTable;
          cout << "Current State: " << currentRole << " -> class." << endl;
          currentRole = "class";
        }else if(srow->role == "function"){
          currentTable = srow->varTable;
          cout << "Current State: " << currentRole << " -> variable." << endl;
          currentRole = "variable";
        }else{
          throw runtime_error("Error, role not yet defined.");
        }
      }else if (currentRole == "variable"){
        VarTable* vt = (VarTable *) currentTable;
        VarTable::symbolRow * vrow = vt->find(name);
        cout << "Current State: " << currentRole << " -> Cant change state" << endl;
      }else if (currentRole == "class"){
        ClassTable * ct = (ClassTable *) currentTable;
        ClassTable::symbolRow * crow = ct->classRow; 
        if(!crow){
          throw runtime_error("Error, variable, class or function doesn't exist.");
        }
        if(crow->functionTable != NULL){
          currentTable = crow->functionTable;
          cout << "Current State: " << currentRole << " -> class." << endl;
          currentRole = "function";
          currentState = "local";
        }
      }else{
          throw runtime_error("Error, role not yet defined.");
      }
    }

    int globalfind(string row){
      FunctionTable::symbolRow * exist = globalTable.find(row);
      if(exist == NULL){
        throw runtime_error("Error, variable of function doesn't exist.");
      }
    }

    int globalInsert(string name, string type, string role){
      FunctionTable::symbolRow * frow = new FunctionTable::symbolRow();
      frow->name = name;
      frow->return_type = type;
      frow->role = role;
      frow->scope = "global";
      frow->varTable = NULL;
      frow->classTable = NULL;
      globalTable.insert(frow);

      return 1;
    }

    void findOnGlobalVars(string row){
      FunctionTable * ft = (FunctionTable *) currentTable;
      FunctionTable::symbolRow * exist = ft->find(row);
      if(exist == NULL){
        throw runtime_error("Error, variable of function doesn't exist.");
      }
    }

    void installGlobalVars(string index){
      FunctionTable::symbolRow * exist = globalTable.find(index);
      if(exist == NULL){
        throw runtime_error("Error, variable doesn't exist.");
      }

      cout << "Exists!" << endl;
      cout << "Name: " << (*exist).name << endl;
      (*exist).varTable = new VarTable();
      //currentTable = (*exist).varTable;
    }

    void insertLocalVariable(string name, string type,string value){
      VarTable * vt = (VarTable *) currentTable;
      if(!vt){
        throw runtime_error("Error, variable directory doesn't exist.");
      }
      VarTable::symbolRow * vrow = new VarTable::symbolRow();
      vrow->name = name;
      vrow->type = type;
      vrow->value = value;
      vt->insert(vrow);
    }

    void installFunctionDir(){
      cout<<currentRole<<endl;
      if(currentRole != "class"){
        throw runtime_error("Error, scope not on class.");
      }

      ClassTable * ct = (ClassTable *) currentTable;
      if(ct == NULL){
        throw runtime_error("Error, class doesn't exist.");
      }
        ClassTable::symbolRow * crow = ct->classRow;

        cout << "Exists!" << endl;
        cout << "Name: " << (*crow).name << endl;
        crow->functionTable = new FunctionTable();
    }

    void installGlobalClassDir(string index){
      FunctionTable::symbolRow * exist = globalTable.find(index);
      if(exist == NULL){
        throw runtime_error("Error, class doesn't exist.");
      }

      cout << "Exists!" << endl;
      cout << "Name: " << (*exist).name << endl;
      (*exist).classTable = new ClassTable((*exist).name);
    }
};