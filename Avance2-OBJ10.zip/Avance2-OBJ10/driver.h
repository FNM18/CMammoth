#include <string>
#include "parser.tab.hh"
#include <unordered_map>
using namespace std;
using namespace yy;
#ifndef DRIVER
#define DRIVER
#define YY_DECL \
parser::symbol_type yylex (parser_driver& driver)
YY_DECL;

class SymbolTable{
  public:
    string getType();
    void setType(string typ){
      type = typ;
    };
  protected:
    string type;
};

//clase para verificar el tipo de salida dependiendo de las combinaciones de los operadores
//se utilizan enumeradores y una matriz para realizar las combinaciones , al igual se incluyen funciones y switches  para verificar su funcionamiento 
class SemanticConsideration{
  public:
   
    enum varType{
      Int , 
      Float, 
      Char,
      Err
    };

    enum opType{
      Sum,
      Sub,
      Mul,
      Res,
      Mod,
      Assign,
      Eq,
      Ne,
      Gt,
      Lt,
      Ge,
      Le,
      And,
      Or
    };


    int cube[3][3][14] = {
        {
          {Int,Int,Int,Int,Int,Int,Int,Int,Int,Int,Int,Int,Int,Int},
          {Float,Float,Float,Float,Float,Err,Int,Int,Int,Int,Int,Int,Int,Int},
          {Err,Err,Err,Err,Err,Err,Int,Int,Int,Int,Int,Int,Int,Int}
        },
        {
          {Float,Float,Float,Float,Err,Float,Int,Int,Int,Int,Int,Int,Int,Int},
          {Float,Float,Float,Float,Err,Float,Int,Int,Int,Int,Int,Int,Int,Int},
          {Err,Err,Err,Err,Err,Err,Int,Int,Int,Int,Int,Int,Int,Int}
        },
        {
          {Err,Err,Err,Err,Err,Err,Int,Int,Int,Int,Int,Int,Int,Int},
          {Err,Err,Err,Err,Err,Err,Int,Int,Int,Int,Int,Int,Int,Int},
          {Char,Char,Err,Err,Err,Char,Int,Int,Int,Int,Int,Int,Int,Int}
        }
      }; 

      int returnRes(varType lv, varType rv, opType op){
        return cube[lv][rv][op];
      }

      void testCube(varType lv, varType rv, opType op){
        if(lv == 3 || rv == 3){
          throw runtime_error("Error, operator error.");
        }
        
        
        int res = returnRes(lv,rv,op);
        cout << "testing cube: " <<  res << endl;

        cout << "left op type: ";
         switch(lv){
           case 0 : 
              cout << "Integer" << endl;
              break;
           case 1 : 
              cout << "Float" << endl;
              break;
           case 2 : 
              cout << "Char" << endl;
              break;
           case 3 : 
              cout << "Error" << endl;
              break;
         }
         
         cout << "right op type: ";
          switch(rv){
           case 0 : 
              cout << "Integer" << endl;
              break;
           case 1 : 
              cout << "Float" << endl;
              break;
           case 2 : 
              cout << "Char" << endl;
              break;
           case 3 : 
              cout << "Error" << endl;
              break;
         }

        cout << "result type: ";
         switch(res){
           case 0 : 
              cout << "Integer" << endl;
              break;
           case 1 : 
              cout << "Float" << endl;
              break;
           case 2 : 
              cout << "Char" << endl;
              break;
           case 3 : 
              cout << "Error" << endl;
              break;
         }
      }
};

class parser_driver{
  public:
    void scannerInit();
    void scannerEnd();
    int parse(const string &archivo);
    string file;
};
#endif