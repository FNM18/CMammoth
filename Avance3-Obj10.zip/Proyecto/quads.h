// #include <stdio.h>
// #include "driver.h"
// #include "semantic.cpp"
#include <stack>
#include <vector>

// using namespace std;

// extern Scope scope;

// class Quad{
//   public:

//     struct varAndType{
//       string var;
//       int type;
//     };

//     struct quadruple{
//         int op;
//         string operandLeft;
//         string operandRight;
//         string result;
//     };

//     vector<quadruple> result;
      
//     Quad(){
//       cout << "Se creo un objeto Quad." << endl;
//     }
// };


// class ExpressionSolver{
//   public:

//     struct varAndType{
//       string var;
//       int type;
//       int constant;
//     };

//     stack<int> operators;
//     stack<struct varAndType> operands;
//     stack<char> types;
//     static int count;
//     struct quadruple{
//         int op;
//         string operandLeft;
//         string operandRight;
//         string result;
//     };

//     vector<quadruple> result;
      
//     ExpressionSolver(){
//       cout<< "Se creo un objeto Expression Solver" << endl;
//     }

//     void insertOprnd(string id){
      
//       VarTable::symbolRow * var = scope.getGlobalVariable(id);
//       struct varAndType vt = varAndType();
//       vt.constant = 0;
//       vt.type = var->type;
//       vt.var = var->name;
//       operands.push(vt);
//       checkStacks();
//     }

//     void insertOprnd(int id){
//       struct varAndType vt = varAndType();
//       vt.constant = 1;
//       vt.type = 0;
//       vt.var = to_string(id);
//       operands.push(vt);
//       checkStacks();
//     }

//     void insertOprnd(float id){
//       struct varAndType vt = varAndType();
//       vt.constant = 1;
//       vt.type = 1;
//       vt.var = to_string(id);
//       operands.push(vt);
//       checkStacks();
//     }

//     void insertOptr(int oper){
//       operators.push(oper);
//     }
    
//     //crea fondo falso
//     void installPar(){
//       operators.push(99);
//     }
    
//     //termina el fondo falso
//     void closePar(){
//       int par = operators.top();
//       if(par != 99){
//         throw runtime_error("Error, incomplete expression.");
//       }
//       operators.pop();
//       checkStacks();
//     }

//     //verifica que haya dos operandos y un operador para agruparlos
//     int checkStacks(){
//         int optr;
//         varAndType opndLeft, opndRight;
//         if(operands.size() >= 2 && operators.size() >= 1 && operators.top() != 99 ){
//           optr = operators.top();
//           operators.pop();
//           opndRight = operands.top();
//           operands.pop();
//           opndLeft = operands.top();
//           operands.pop();
//           cout<<"CCC5"<<endl;
//           varAndType res = solveQuadruple(optr, opndLeft,opndRight);
//           cout<<"CCC6"<<endl;
//           operands.push(res);
//           cout<<"CCC7"<<endl;
//           quadruple quad = quadruple();
//           quad.op = optr;
//           quad.operandLeft = opndLeft.var;
//           quad.operandRight = opndRight.var;
//           quad.result = res.var;
//           result.push_back(quad);
//           return 1;
//         }
//         return 0;
//     }

//     //resuelve la expresion 
//     varAndType solveQuadruple(int optr, varAndType opndLeft, varAndType opndRight){
        
//         //busca si la operacion es valida (checar cubo) 
//         SemanticConsideration sc = SemanticConsideration();
//         int cubeRes= sc.testCube( opndLeft.type, opndRight.type ,optr);
//         varAndType vt = varAndType();
//         vt.type = cubeRes;
//         vt.var = "t" + to_string(count++);

//         return vt;
//          //si es valida hacer operacion, sino mandar error
        
//     }

// };

// void printVar(VarTable::symbolRow * vrow){
//     cout<<"Name: " << vrow->name << endl;
//     cout<<"Type: " << vrow->type << endl;
//     cout<<"Value: " << vrow->value << endl;
//     cout << endl;
// }

// void printVarType(ExpressionSolver::varAndType * vt){
//     cout<<"Name: " << vt->var << endl;
//     cout<<"Type: " << vt->type << endl;
//     cout << endl;
// }
