#include <stdio.h>
#include <string>
#include "driver.h"
#include <stack>
#include <vector>

using namespace std;

class ClassTable;
class FunctionTable;
class VarTable;
class Scope;
class Quad;
class ExpressionSolver;

extern Scope scope;

//Tabla de clases heredada de SymbolTable que genera una clase
//Esta clase puede generar una tabla de funciones para guardar sus respectivas variables y funciones internas
class ClassTable : public SymbolTable{
  public:
  struct symbolRow{
      string name;
      //VarTable * varTable;
      FunctionTable * functionTable;
      ClassTable * inheritance;
  };
  symbolRow * classRow;
  ClassTable(string name){
    setType("class");
    classRow = new symbolRow();
    classRow->name = name;
    classRow->functionTable = NULL;
    classRow->inheritance = NULL;
    cout << "Class table initialized" << endl;
  };

  string getType(){
    string g = ClassTable::type;
    return g;
  }

  void setType(string type){
    ClassTable::type = type;
  }
};

//Tabla de variables heredada de SymbolTable que genera un mapa de variables
//Cada renglon de variable puede guardar diferentes variables y su respectivo valor
class VarTable : public SymbolTable{
  public:
    struct symbolRow{
      string name;
      int type; //0->Int, 1->float, 2->char, 3->error, 4->Quad
      string value;
      //void * value;
    };

    VarTable(){
      setType("variable");
      cout << "Variable table initialized" << endl;
    };

    string getType(){
      string g = VarTable::type;
      return g;
    }

    void setType(string type){
      VarTable::type = type;
    }

    void insert(struct symbolRow * row){
      if(lookup(row)){
        throw runtime_error("Error, it's already declared!");
      }
      cout << "Name: " << (*row).name << endl;
      cout << "Type: " << (*row).type << endl;
      cout << "Value: " << (*row).value << endl;
      VarTable::umap[(*row).name] = row;
    }

    int lookup(symbolRow * row){
      symbolRow * exist = VarTable::umap[(*row).name];
      if(exist != NULL){
        cout << "Exists!" << endl;
        cout << "Name: " << (*exist).name << endl;
        return 1;
      }
      return 0;
    }

    symbolRow * find(string row){
      symbolRow * exist = VarTable::umap[row];
      if(exist != NULL){
        return exist;
      }
      return NULL;
    }

    void modify(struct symbolRow * row){
      struct symbolRow * exist = VarTable::umap[(*row).name];
      if(exist != NULL){
        (*exist).type = (*row).type;
        //(*exist).role = (*row).role;
        (*exist).value = (*row).value;
      }
    }
  protected:
    unordered_map<string, symbolRow*> umap;
};

//Tabla de funciones heredada de SymbolTable que genera un mapa de funciones
//Cada renglon de funcion puede guardar una tabla de clase o una tabla de variables
class FunctionTable : public SymbolTable{
  public:
    struct symbolRow{
      string name;
      int return_type;//0->int 1->float 2->char 20->void 10->class
      string scope;
      string role;
      VarTable * varTable;
      ClassTable * classTable;
      ExpressionSolver * quad;
    };

    FunctionTable(){
      setType("function");
      cout << "Function table initialized" << endl;
    };

    string getType(){
      string g = FunctionTable::type;
      return g;
    }

    void setType(string type){
      FunctionTable::type = type;
    }

    void insert(struct symbolRow * row){
      if(lookup(row)){
        throw runtime_error("Error, it's already declared!");
      }
      cout << "Name: " << (*row).name << endl;
      cout << "Return_type: " << (*row).return_type << endl;
      cout << "Role: " << (*row).role << endl;
      cout << "Scope: " << (*row).scope << endl;
      umap[(*row).name] = row;
    }

    int lookup(symbolRow * row){
      symbolRow * exist = FunctionTable::umap[(*row).name];
      if(exist != NULL){
        cout << "Exists!" << endl;
        cout << "Name: " << (*exist).name << endl;
        return 1;
      }
      return 0;
    }

    symbolRow * find(string row){
      symbolRow * exist = umap[row];
      if(exist != NULL){
        cout << "Exists!" << endl;
        return exist;
      }
      return NULL;
    }

    void modify(struct symbolRow * row){
      struct symbolRow * exist = FunctionTable::umap[(*row).name];
      if(exist != NULL){
        (*exist).return_type = (*row).return_type;
        (*exist).role = (*row).role;
        (*exist).scope = (*row).scope;
        (*exist).varTable = (*row).varTable;
        (*exist).classTable = (*row).classTable;
      }
    }
  protected:
    unordered_map<string, symbolRow*> umap;
};

//Clase para verificar estados y manipulacion de las tablas.
class Scope{
  public:
    string currentState = "global";
    string currentRole = "function";
    SymbolTable * currentTable;
    FunctionTable globalTable;

    FunctionTable::symbolRow * functionScope = NULL;
    
    Scope(){
      currentTable = &globalTable;
      globalInsertFunction("global",20,"function");
      installGlobalVars();
    };

    void restartState(){
      currentTable = &globalTable;
      currentRole = "function";
      currentState = "global";
    }

    //Cambiar de estados, se usara al implementar clases
    void changeCurrentState(int root, string name){
      if(root){
        restartState();
      }
      if(currentRole == "function"){
        FunctionTable * ft = (FunctionTable *) currentTable;
        FunctionTable::symbolRow * srow = ft->find(name);
        if(!srow){
          throw runtime_error("Error, variable, class or function doesn't exist.");
        }
        if(srow->role == "class"){
          currentTable = srow->classTable;
          cout << "Current State: " << currentRole << " -> class." << endl;
          currentRole = "class";
        }else if(srow->role == "function"){
          currentTable = srow->varTable;
          cout << "Current State: " << currentRole << " -> variable." << endl;
          currentRole = "variable";
        }else{
          throw runtime_error("Error, role not yet defined.");
        }
      }else if (currentRole == "variable"){
        VarTable* vt = (VarTable *) currentTable;
        VarTable::symbolRow * vrow = vt->find(name);
        cout << "Current State: " << currentRole << " -> Cant change state" << endl;
      }else if (currentRole == "class"){
        ClassTable * ct = (ClassTable *) currentTable;
        ClassTable::symbolRow * crow = ct->classRow; 
        if(!crow){
          throw runtime_error("Error, variable, class or function doesn't exist.");
        }
        if(crow->functionTable != NULL){
          currentTable = crow->functionTable;
          cout << "Current State: " << currentRole << " -> class." << endl;
          currentRole = "function";
          currentState = "local";
        }
      }else{
          throw runtime_error("Error, role not yet defined.");
      }
    }

    //GLOBAL FUNCTIONS

    int globalInsertFunction(string name, int type, string role){
      FunctionTable::symbolRow * frow = new FunctionTable::symbolRow();
      frow->name = name;
      frow->return_type = type;
      frow->role = role;
      frow->scope = "global";
      frow->varTable = NULL;
      frow->classTable = NULL;
      globalTable.insert(frow);

      return 1;
    }

    int globalFindFunction(string row){
      FunctionTable::symbolRow * exist = globalTable.find(row);
      if(exist == NULL){
        throw runtime_error("Error, function doesn't exist.");
      }
      return 1;
    }

    void installGlobalVars(){
      FunctionTable::symbolRow * exist = globalTable.find("global");
      if(exist == NULL){
        throw runtime_error("Error, variable doesn't exist.");
      }

      (*exist).varTable = new VarTable();
    }

    void installFunctionVars(string name){
      FunctionTable::symbolRow * exist = globalTable.find(name);
      if(exist == NULL){
        throw runtime_error("Error, function doesn't exist.");
      }

      exist->varTable = new VarTable();
    }

    void installQuad(ExpressionSolver * es){
      FunctionTable::symbolRow * exist = globalTable.find("global");
      if(exist == NULL){
        throw runtime_error("Error, function doesn't exist.");
      }

      exist->quad = es;
    }

    int lookupGlobalVariable(string name){
      VarTable * vt = (VarTable *) globalTable.find("global")->varTable;
      if(!vt){
        throw runtime_error("Error, variable directory doesn't exist.");
      }

      return 1;
    }

    VarTable::symbolRow * getGlobalVariable(string name){
      VarTable * vt = (VarTable *) globalTable.find("global")->varTable;
      if(!vt){
        throw runtime_error("Error, variable directory doesn't exist.");
      }
      VarTable::symbolRow * vrow = vt->find(name);
      return vrow;
    }

    void insertGlobalVariable(string name, int type,string value){
      VarTable * vt = (VarTable *) globalTable.find("global")->varTable;
      if(!vt){
        throw runtime_error("Error, variable directory doesn't exist.");
      }
      VarTable::symbolRow * vrow = new VarTable::symbolRow();
      vrow->name = name;
      vrow->type = type;
      vrow->value = value;
      vt->insert(vrow);
    }

    void updateGlobalVariable(string name, int type,string value){
      VarTable * vt = (VarTable *) globalTable.find("global")->varTable;
      if(!vt){
        throw runtime_error("Error, variable directory doesn't exist.");
      }

      VarTable::symbolRow * vrow = new VarTable::symbolRow();
      vrow->name = name;
      vrow->type = type;
      vrow->value = value;
      vt->modify(vrow);
    }

    void insertLocalVariable(string name, int type,string value){
      VarTable * vt = (VarTable *) currentTable;
      if(!vt){
        throw runtime_error("Error, variable directory doesn't exist.");
      }
      VarTable::symbolRow * vrow = new VarTable::symbolRow();
      vrow->name = name;
      vrow->type = type;
      vrow->value = value;
      vt->insert(vrow);
    }

    //FUNCTION SCOPE - LOCAL VARIABLES

    void setFunctionScope(string id){
        FunctionTable::symbolRow * func = globalTable.find(id);
        if(!func){
            throw runtime_error("Error, function doesn't exist.");
        }
        functionScope = func;
        cout << "Scope on function: " << id << endl;
    }

    void freeFunctionScope(){
        functionScope = NULL;
    }

    VarTable::symbolRow * getVarOnScope(string id){
      if(functionScope == NULL){
        throw runtime_error("Error, no function on scope.");
      }
      VarTable * vt = (VarTable *) functionScope->varTable;
      if(vt == NULL){
        throw runtime_error("Error, no variable directory installed on function.");
      }
      VarTable::symbolRow * vrow = vt->find(id);
      // if(vrow == NULL){
      //   throw runtime_error("Error, variable doesn't exist.");
      // }
      return vrow;
    }

    void insertVarOnScope(string name, int type, string value){
      if(functionScope == NULL){
        throw runtime_error("Error, no function on scope.");
      }
      VarTable * vt = (VarTable *) functionScope->varTable;
      if(vt == NULL){
        throw runtime_error("Error, no variable directory installed on function.");
      }
      VarTable::symbolRow * vrow = new VarTable::symbolRow();
      vrow->name = name;
      vrow->type = type;
      vrow->value = value;

      vt->insert(vrow);
    }

    void updateVarOnScope(string name, int type, string value){
      if(functionScope == NULL){
        throw runtime_error("Error, no function on scope.");
      }
      VarTable * vt = (VarTable *) functionScope->varTable;
      if(vt == NULL){
        throw runtime_error("Error, no variable directory installed on function.");
      }
      VarTable::symbolRow * vrow = new VarTable::symbolRow();
      vrow->name = name;
      vrow->type = type;
      vrow->value = value;
      if(vrow == NULL){
        throw runtime_error("Error, variable doesn't exist.");
      }
      vt->modify(vrow);
    }

    void installQuadOnScope(ExpressionSolver * es){
      if(functionScope == NULL){
        throw runtime_error("Error, no function on scope.");
      }

      functionScope->quad = es;
    }

    //CLASSES

    void installFunctionDir(){
      cout<<currentRole<<endl;
      if(currentRole != "class"){
        throw runtime_error("Error, scope not on class.");
      }

      ClassTable * ct = (ClassTable *) currentTable;
      if(ct == NULL){
        throw runtime_error("Error, class doesn't exist.");
      }
        ClassTable::symbolRow * crow = ct->classRow;

        cout << "Exists!" << endl;
        cout << "Name: " << (*crow).name << endl;
        crow->functionTable = new FunctionTable();
    }

    void installGlobalClassDir(string index){
      FunctionTable::symbolRow * exist = globalTable.find(index);
      if(exist == NULL){
        throw runtime_error("Error, class doesn't exist.");
      }

      cout << "Exists!" << endl;
      cout << "Name: " << (*exist).name << endl;
      (*exist).classTable = new ClassTable((*exist).name);
    }
};

class Quad{
  public:

    struct varAndType{
      string var;
      int type;
    };

    struct quadruple{
        int op;
        string operandLeft;
        string operandRight;
        string result;
    };

    vector<quadruple> result;
      
    Quad(){
      cout << "Se creo un objeto Quad." << endl;
    }
};


class ExpressionSolver{
  public:

    struct varAndType{
      string var;
      int type;
      int constant;
    };

    stack<int> operators;
    stack<struct varAndType> operands;
    stack<char> types;
    int count = 0;
    struct quadruple{
        int op;
        string operandLeft;
        string operandRight;
        string result;
    };

    vector<quadruple> result;
      
    ExpressionSolver(){
      cout<< "Se creo un objeto Expression Solver" << endl;
    }

    void insertOprnd(string id){
      cout<<"Operand: " << id << endl;
      VarTable::symbolRow * var = NULL;
      if(scope.functionScope == NULL){
        var = scope.getGlobalVariable(id);
      }else{
        var = scope.getVarOnScope(id);
        if(var == NULL){
          var = scope.getGlobalVariable(id);
        }
      }
      cout<<"Operand: " << id << endl;
      if(var == NULL){
        throw runtime_error("Error, variable not found.");
      }
      varAndType vt = varAndType();
      vt.constant = 0;
      vt.type = var->type;
      vt.var = var->name;
      operands.push(vt);
      checkStacks();
    }

    void insertOprnd(int id){
      struct varAndType vt = varAndType();
      vt.constant = 1;
      vt.type = 0;
      vt.var = to_string(id);
      operands.push(vt);
      checkStacks();
    }

    void insertOprnd(float id){
      struct varAndType vt = varAndType();
      vt.constant = 1;
      vt.type = 1;
      vt.var = to_string(id);
      operands.push(vt);
      checkStacks();
    }

    void insertOprnd(char id){
      struct varAndType vt = varAndType();
      vt.constant = 1;
      vt.type = 2;
      vt.var = to_string(id);
      operands.push(vt);
      checkStacks();
    }

    void insertOptr(int oper){
      operators.push(oper);
    }
    
    //crea fondo falso
    void installPar(){
      operators.push(99);
    }
    
    //termina el fondo falso
    void closePar(){
      int par = operators.top();
      if(par != 99){
        throw runtime_error("Error, incomplete expression.");
      }
      operators.pop();
      checkStacks();
    }

    //verifica que haya dos operandos y un operador para agruparlos
    int checkStacks(){
        int optr;
        varAndType opndLeft, opndRight;
        if(operands.size() >= 2 && operators.size() >= 1 && operators.top() != 99 ){
          optr = operators.top();
          operators.pop();
          opndRight = operands.top();
          operands.pop();
          opndLeft = operands.top();
          operands.pop();
          varAndType res = solveQuadruple(optr, opndLeft,opndRight);
          operands.push(res);
          quadruple quad = quadruple();
          quad.op = optr;
          quad.operandLeft = opndLeft.var;
          quad.operandRight = opndRight.var;
          quad.result = res.var;
          result.push_back(quad);
          return 1;
        }
        return 0;
    }

    //resuelve la expresion 
    varAndType solveQuadruple(int optr, varAndType opndLeft, varAndType opndRight){
        
        //busca si la operacion es valida (checar cubo) 
        SemanticConsideration sc = SemanticConsideration();
        int cubeRes= sc.testCube( opndLeft.type, opndRight.type ,optr);
        varAndType vt = varAndType();
        vt.type = cubeRes;
        vt.var = "t" + to_string(count++);

        return vt;
         //si es valida hacer operacion, sino mandar error
        
    }

};

// void printVar(VarTable::symbolRow * vrow){
//     cout<<"Name: " << vrow->name << endl;
//     cout<<"Type: " << vrow->type << endl;
//     cout<<"Value: " << vrow->value << endl;
//     cout << endl;
// }

// void printVarType(ExpressionSolver::varAndType * vt){
//     cout<<"Name: " << vt->var << endl;
//     cout<<"Type: " << vt->type << endl;
//     cout << endl;
// }