#include <string>
#include <vector>
using namespace std;

//FLAGS VARS FUNCTIONS
int xreadFlag = 0;
int globalFlag = 0;
int expressionFlag = 0;

vector<string> currentIds;
int currentType = -1;
string currentFunction = "";

void resetFlags(){
  xreadFlag = 0;
};
  

void resetID(){
    currentIds.clear();
    currentType = -1;
};

void setID(std::string id){
    currentIds.push_back(id);
};

void setCurrentType(int type){
    currentType = type;
}

void resetCurrentType(){
    currentType = -1;
}

void setCurrentFunction(string id){
    currentFunction = id;
}

void resetCurrentFunction(){
    currentFunction = "";
}
