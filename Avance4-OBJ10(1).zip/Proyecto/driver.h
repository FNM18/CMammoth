#include <string>
#include "parser.tab.hh"
#include <unordered_map>

using namespace std;
using namespace yy;
#ifndef DRIVER
#define DRIVER
#define YY_DECL \
parser::symbol_type yylex (parser_driver& driver)
YY_DECL;

class SymbolTable{
  public:
    string getType();
    void setType(string typ){
      type = typ;
    };
  protected:
    string type;
};

//clase para verificar el tipo de salida dependiendo de las combinaciones de los operadores
//se utilizan enumeradores y una matriz para realizar las combinaciones , al igual se incluyen funciones y switches  para verificar su funcionamiento 
class SemanticConsideration{
  public:
   
    enum varType{
      Int , 
      Float, 
      Char,
      Err
    };

    enum opType{
      Sum, //0
      Sub,
      Mul, //2
      Div,
      Mod, //4
      Assign,
      Eq, //6
      Ne,
      Gt, //8
      Lt,
      Ge, //10
      Le,
      And, //12
      Or
    };


    int cube[3][3][14] = {
        {
          {Int,Int,Int,Int,Int,Int,Int,Int,Int,Int,Int,Int,Int,Int},
          {Float,Float,Float,Float,Float,Err,Int,Int,Int,Int,Int,Int,Int,Int},
          {Err,Err,Err,Err,Err,Err,Int,Int,Int,Int,Int,Int,Int,Int}
        },
        {
          {Float,Float,Float,Float,Err,Float,Int,Int,Int,Int,Int,Int,Int,Int},
          {Float,Float,Float,Float,Err,Float,Int,Int,Int,Int,Int,Int,Int,Int},
          {Err,Err,Err,Err,Err,Err,Int,Int,Int,Int,Int,Int,Int,Int}
        },
        {
          {Err,Err,Err,Err,Err,Err,Int,Int,Int,Int,Int,Int,Int,Int},
          {Err,Err,Err,Err,Err,Err,Int,Int,Int,Int,Int,Int,Int,Int},
          {Char,Char,Err,Err,Err,Char,Int,Int,Int,Int,Int,Int,Int,Int}
        }
      }; 

      int testCube(int lv, int rv, int op){
        cout << "Left: " << lv << " Right: " << rv << " op: " << op << endl;
        if(lv == 3 || rv == 3){
          throw runtime_error("Error, operands and operator mismatch.");
        }
        
        int cubeRes = cube[lv][rv][op];
        cout << "testing cube: " <<  cubeRes << endl;
        
        if(cubeRes == 3){
          throw runtime_error("Error, operands and operator mismatch.");
        }

        cout << "left op type: ";
         switch(lv){
           case 0 : 
              cout << "Integer" << endl;
              break;
           case 1 : 
              cout << "Float" << endl;
              break;
           case 2 : 
              cout << "Char" << endl;
              break;
           case 3 : 
              cout << "Error" << endl;
              break;
         }
         
         cout << "right op type: ";
          switch(rv){
           case 0 : 
              cout << "Integer" << endl;
              break;
           case 1 : 
              cout << "Float" << endl;
              break;
           case 2 : 
              cout << "Char" << endl;
              break;
           case 3 : 
              cout << "Error" << endl;
              break;
         }

        cout << "result type: ";
         switch(cubeRes){
           case 0 : 
              cout << "Integer" << endl;
              break;
           case 1 : 
              cout << "Float" << endl;
              break;
           case 2 : 
              cout << "Char" << endl;
              break;
           case 3 : 
              cout << "Error" << endl;
              break;
         }

         return cubeRes;
      }
};

class parser_driver{
  public:
    void scannerInit();
    void scannerEnd();
    int parse(const string &archivo);
    string file;
};
#endif