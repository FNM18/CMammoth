// A Bison parser, made by GNU Bison 3.5.1.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2020 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// Undocumented macros, especially those whose name start with YY_,
// are private implementation details.  Do not rely on them.





#include "parser.tab.hh"


// Unqualified %code blocks.
#line 22 "parser.yy"

#include "driver.h"
#include "flags.h"
#include "semantic.cpp"
#include <iostream>
#include <vector>
#include <stack>

Scope scope = Scope();
int tempCount = 0;
ExpressionSolver es;
ParamSolver ps = ParamSolver("global");
stack<ParamSolver> params;

stack<ExpressionSolver> pes;
Quad quads = Quad();
VarTable::symbolRow * var = NULL;

#line 64 "parser.tab.cc"


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

// Whether we are compiled with exception support.
#ifndef YY_EXCEPTIONS
# if defined __GNUC__ && !defined __EXCEPTIONS
#  define YY_EXCEPTIONS 0
# else
#  define YY_EXCEPTIONS 1
# endif
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K].location)
/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

# ifndef YYLLOC_DEFAULT
#  define YYLLOC_DEFAULT(Current, Rhs, N)                               \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).begin  = YYRHSLOC (Rhs, 1).begin;                   \
          (Current).end    = YYRHSLOC (Rhs, N).end;                     \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).begin = (Current).end = YYRHSLOC (Rhs, 0).end;      \
        }                                                               \
    while (false)
# endif


// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << '\n';                       \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yystack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YYUSE (Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void> (0)
# define YY_STACK_PRINT()                static_cast<void> (0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)

#line 6 "parser.yy"
namespace yy {
#line 156 "parser.tab.cc"


  /* Return YYSTR after stripping away unnecessary quotes and
     backslashes, so that it's suitable for yyerror.  The heuristic is
     that double-quoting is unnecessary unless the string contains an
     apostrophe, a comma, or backslash (other than backslash-backslash).
     YYSTR is taken from yytname.  */
  std::string
  parser::yytnamerr_ (const char *yystr)
  {
    if (*yystr == '"')
      {
        std::string yyr;
        char const *yyp = yystr;

        for (;;)
          switch (*++yyp)
            {
            case '\'':
            case ',':
              goto do_not_strip_quotes;

            case '\\':
              if (*++yyp != '\\')
                goto do_not_strip_quotes;
              else
                goto append;

            append:
            default:
              yyr += *yyp;
              break;

            case '"':
              return yyr;
            }
      do_not_strip_quotes: ;
      }

    return yystr;
  }


  /// Build a parser object.
  parser::parser (parser_driver& driver_yyarg)
#if YYDEBUG
    : yydebug_ (false),
      yycdebug_ (&std::cerr),
#else
    :
#endif
      driver (driver_yyarg)
  {}

  parser::~parser ()
  {}

  parser::syntax_error::~syntax_error () YY_NOEXCEPT YY_NOTHROW
  {}

  /*---------------.
  | Symbol types.  |
  `---------------*/



  // by_state.
  parser::by_state::by_state () YY_NOEXCEPT
    : state (empty_state)
  {}

  parser::by_state::by_state (const by_state& that) YY_NOEXCEPT
    : state (that.state)
  {}

  void
  parser::by_state::clear () YY_NOEXCEPT
  {
    state = empty_state;
  }

  void
  parser::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  parser::by_state::by_state (state_type s) YY_NOEXCEPT
    : state (s)
  {}

  parser::symbol_number_type
  parser::by_state::type_get () const YY_NOEXCEPT
  {
    if (state == empty_state)
      return empty_symbol;
    else
      return yystos_[+state];
  }

  parser::stack_symbol_type::stack_symbol_type ()
  {}

  parser::stack_symbol_type::stack_symbol_type (YY_RVREF (stack_symbol_type) that)
    : super_type (YY_MOVE (that.state), YY_MOVE (that.location))
  {
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.YY_MOVE_OR_COPY< char > (YY_MOVE (that.value));
        break;

      case 55: // INT
      case 56: // FLOAT
        value.YY_MOVE_OR_COPY< float > (YY_MOVE (that.value));
        break;

      case 52: // ID
      case 53: // STRING
        value.YY_MOVE_OR_COPY< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

#if 201103L <= YY_CPLUSPLUS
    // that is emptied.
    that.state = empty_state;
#endif
  }

  parser::stack_symbol_type::stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) that)
    : super_type (s, YY_MOVE (that.location))
  {
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.move< char > (YY_MOVE (that.value));
        break;

      case 55: // INT
      case 56: // FLOAT
        value.move< float > (YY_MOVE (that.value));
        break;

      case 52: // ID
      case 53: // STRING
        value.move< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

    // that is emptied.
    that.type = empty_symbol;
  }

#if YY_CPLUSPLUS < 201103L
  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.copy< char > (that.value);
        break;

      case 55: // INT
      case 56: // FLOAT
        value.copy< float > (that.value);
        break;

      case 52: // ID
      case 53: // STRING
        value.copy< std::string > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    return *this;
  }

  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (stack_symbol_type& that)
  {
    state = that.state;
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.move< char > (that.value);
        break;

      case 55: // INT
      case 56: // FLOAT
        value.move< float > (that.value);
        break;

      case 52: // ID
      case 53: // STRING
        value.move< std::string > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    // that is emptied.
    that.state = empty_state;
    return *this;
  }
#endif

  template <typename Base>
  void
  parser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);
  }

#if YYDEBUG
  template <typename Base>
  void
  parser::yy_print_ (std::ostream& yyo,
                                     const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YYUSE (yyoutput);
    symbol_number_type yytype = yysym.type_get ();
#if defined __GNUC__ && ! defined __clang__ && ! defined __ICC && __GNUC__ * 100 + __GNUC_MINOR__ <= 408
    // Avoid a (spurious) G++ 4.8 warning about "array subscript is
    // below array bounds".
    if (yysym.empty ())
      std::abort ();
#endif
    yyo << (yytype < yyntokens_ ? "token" : "nterm")
        << ' ' << yytname_[yytype] << " ("
        << yysym.location << ": ";
    switch (yytype)
    {
      case 52: // ID
#line 138 "parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 408 "parser.tab.cc"
        break;

      case 53: // STRING
#line 138 "parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 414 "parser.tab.cc"
        break;

      case 54: // CHAR
#line 138 "parser.yy"
                 { yyoutput << yysym.value.template as < char > (); }
#line 420 "parser.tab.cc"
        break;

      case 55: // INT
#line 138 "parser.yy"
                 { yyoutput << yysym.value.template as < float > (); }
#line 426 "parser.tab.cc"
        break;

      case 56: // FLOAT
#line 138 "parser.yy"
                 { yyoutput << yysym.value.template as < float > (); }
#line 432 "parser.tab.cc"
        break;

      default:
        break;
    }
    yyo << ')';
  }
#endif

  void
  parser::yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym)
  {
    if (m)
      YY_SYMBOL_PRINT (m, sym);
    yystack_.push (YY_MOVE (sym));
  }

  void
  parser::yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym)
  {
#if 201103L <= YY_CPLUSPLUS
    yypush_ (m, stack_symbol_type (s, std::move (sym)));
#else
    stack_symbol_type ss (s, sym);
    yypush_ (m, ss);
#endif
  }

  void
  parser::yypop_ (int n)
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  parser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  parser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  parser::debug_level_type
  parser::debug_level () const
  {
    return yydebug_;
  }

  void
  parser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  parser::state_type
  parser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - yyntokens_] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - yyntokens_];
  }

  bool
  parser::yy_pact_value_is_default_ (int yyvalue)
  {
    return yyvalue == yypact_ninf_;
  }

  bool
  parser::yy_table_value_is_error_ (int yyvalue)
  {
    return yyvalue == yytable_ninf_;
  }

  int
  parser::operator() ()
  {
    return parse ();
  }

  int
  parser::parse ()
  {
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The locations where the error started and ended.
    stack_symbol_type yyerror_range[3];

    /// The return value of parse ().
    int yyresult;

#if YY_EXCEPTIONS
    try
#endif // YY_EXCEPTIONS
      {
    YYCDEBUG << "Starting parse\n";


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, YY_MOVE (yyla));

  /*-----------------------------------------------.
  | yynewstate -- push a new symbol on the stack.  |
  `-----------------------------------------------*/
  yynewstate:
    YYCDEBUG << "Entering state " << int (yystack_[0].state) << '\n';

    // Accept?
    if (yystack_[0].state == yyfinal_)
      YYACCEPT;

    goto yybackup;


  /*-----------.
  | yybackup.  |
  `-----------*/
  yybackup:
    // Try to take a decision without lookahead.
    yyn = yypact_[+yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token: ";
#if YY_EXCEPTIONS
        try
#endif // YY_EXCEPTIONS
          {
            symbol_type yylookahead (yylex (driver));
            yyla.move (yylookahead);
          }
#if YY_EXCEPTIONS
        catch (const syntax_error& yyexc)
          {
            YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
            error (yyexc);
            goto yyerrlab1;
          }
#endif // YY_EXCEPTIONS
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.type_get ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.type_get ())
      {
        goto yydefault;
      }

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", state_type (yyn), YY_MOVE (yyla));
    goto yynewstate;


  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[+yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;


  /*-----------------------------.
  | yyreduce -- do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_ (yystack_[yylen].state, yyr1_[yyn]);
      /* Variants are always initialized to an empty instance of the
         correct type. The default '$$ = $1' action is NOT applied
         when using variants.  */
      switch (yyr1_[yyn])
    {
      case 54: // CHAR
        yylhs.value.emplace< char > ();
        break;

      case 55: // INT
      case 56: // FLOAT
        yylhs.value.emplace< float > ();
        break;

      case 52: // ID
      case 53: // STRING
        yylhs.value.emplace< std::string > ();
        break;

      default:
        break;
    }


      // Default location.
      {
        stack_type::slice range (yystack_, yylen);
        YYLLOC_DEFAULT (yylhs.location, range, yylen);
        yyerror_range[1].location = yylhs.location;
      }

      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
#if YY_EXCEPTIONS
      try
#endif // YY_EXCEPTIONS
        {
          switch (yyn)
            {
  case 4:
#line 149 "parser.yy"
                      {quads.prepareMainQuad();}
#line 687 "parser.tab.cc"
    break;

  case 5:
#line 149 "parser.yy"
                                                             {globalFlag = 1;}
#line 693 "parser.tab.cc"
    break;

  case 7:
#line 153 "parser.yy"
                 {setID(yystack_[0].value.as < std::string > ());}
#line 699 "parser.tab.cc"
    break;

  case 9:
#line 154 "parser.yy"
                          {setID(yystack_[0].value.as < std::string > ());}
#line 705 "parser.tab.cc"
    break;

  case 16:
#line 160 "parser.yy"
                          {setID(yystack_[0].value.as < std::string > ());}
#line 711 "parser.tab.cc"
    break;

  case 18:
#line 161 "parser.yy"
                          {setID(yystack_[0].value.as < std::string > ());}
#line 717 "parser.tab.cc"
    break;

  case 26:
#line 178 "parser.yy"
                     {
        if(paramsFlag){
                pes.top().installPar();
        }else{
                if(expressionFlag){
                        es.installPar();
                }
        }
        }
#line 731 "parser.tab.cc"
    break;

  case 27:
#line 186 "parser.yy"
                          {
                if(paramsFlag){
                        pes.top().closePar();
                }else{
                        if(expressionFlag){
                                es.closePar();
                        }
                }
        }
#line 745 "parser.tab.cc"
    break;

  case 28:
#line 197 "parser.yy"
                    {
        if(paramsFlag){
                pes.push(ExpressionSolver());
        }
}
#line 755 "parser.tab.cc"
    break;

  case 29:
#line 201 "parser.yy"
             {
        if(paramsFlag){
                quads.importSolver(pes.top()); 
                int single = pes.top().singleVar();
                if(single){
                        cout<<"Direction -> " << single << endl;
                        int paramNum = params.top().insertParam(single);
                        quads.insertQuad(203,single,-1,paramNum);
                }else{
                        cout<<"Direction -> " << quads.getLastQuad().result << endl;
                        int paramNum = params.top().insertParam(quads.getLastQuad().result);
                        quads.insertQuad(203,quads.getLastQuad().result,-1,paramNum);
                }
                pes.pop();
        }
}
#line 776 "parser.tab.cc"
    break;

  case 31:
#line 217 "parser.yy"
                       {
        if(paramsFlag){
                pes.push(ExpressionSolver());
        }
}
#line 786 "parser.tab.cc"
    break;

  case 32:
#line 221 "parser.yy"
             {
        if(paramsFlag){
                quads.importSolver(pes.top());
                int single = pes.top().singleVar();
                if(single){
                        cout<<"Direction -> " << single << endl;
                        int paramNum = params.top().insertParam(single);
                        quads.insertQuad(203,single,-1,paramNum);
                }else{
                        cout<<"Direction -> " << quads.getLastQuad().result << endl;
                        int paramNum = params.top().insertParam(quads.getLastQuad().result);
                        quads.insertQuad(203,quads.getLastQuad().result,-1,paramNum);
                }
                pes.pop();
        }
}
#line 807 "parser.tab.cc"
    break;

  case 35:
#line 242 "parser.yy"
                   {cout << "Clase id : " << yystack_[0].value.as < std::string > () << endl;}
#line 813 "parser.tab.cc"
    break;

  case 38:
#line 246 "parser.yy"
                                   {
        setCurrentFunction(yystack_[0].value.as < std::string > ());
        scope.globalInsertFunction(yystack_[0].value.as < std::string > (),currentType,"function",quads.getQuadLastDir());
        scope.setFunctionScope(yystack_[0].value.as < std::string > ());
        scope.installFunctionVars(yystack_[0].value.as < std::string > ());
        if(currentType<10){
                scope.insertGlobalVariable(yystack_[0].value.as < std::string > (),currentType);
        }
        resetCurrentType();
        globalFlag = 0;
}
#line 829 "parser.tab.cc"
    break;

  case 39:
#line 256 "parser.yy"
                                                         {
        resetCurrentFunction();
        quads.insertQuad(299,-1,-1,-1);
}
#line 838 "parser.tab.cc"
    break;

  case 42:
#line 263 "parser.yy"
            {
        quads.setMainQuad();
        scope.setFunctionScope("global");
}
#line 847 "parser.tab.cc"
    break;

  case 43:
#line 266 "parser.yy"
                               {quads.insertQuad(999,-1,-1,-1);quads.printQuadList();}
#line 853 "parser.tab.cc"
    break;

  case 46:
#line 274 "parser.yy"
                        {cout << "Herencia id : " << yystack_[0].value.as < std::string > () << endl;}
#line 859 "parser.tab.cc"
    break;

  case 50:
#line 284 "parser.yy"
{       
        if(globalFlag){
                for(auto var : currentIds){
                        scope.insertGlobalVariable(var,currentType);
                }
        }else{
                for(auto var : currentIds){
                        scope.insertVarOnScope(var,currentType);
                } 
        }
        resetID();
        resetCurrentType();
}
#line 877 "parser.tab.cc"
    break;

  case 59:
#line 316 "parser.yy"
                       {setCurrentType(0);}
#line 883 "parser.tab.cc"
    break;

  case 60:
#line 317 "parser.yy"
                          {setCurrentType(1);}
#line 889 "parser.tab.cc"
    break;

  case 61:
#line 318 "parser.yy"
                         {setCurrentType(2);}
#line 895 "parser.tab.cc"
    break;

  case 63:
#line 321 "parser.yy"
                               {setCurrentType(10);}
#line 901 "parser.tab.cc"
    break;

  case 65:
#line 324 "parser.yy"
                                    {setCurrentType(20);}
#line 907 "parser.tab.cc"
    break;

  case 66:
#line 327 "parser.yy"
              {
        if(paramsFlag){
                pes.top().insertOprnd(yystack_[0].value.as < std::string > ());
        }else{
                if(expressionFlag){
                        es.insertOprnd(yystack_[0].value.as < std::string > ());
                }else{
                        var = scope.getVarOnScope(yystack_[0].value.as < std::string > ());
                        if(var == NULL)
                                var = scope.getGlobalVariable(yystack_[0].value.as < std::string > ());
                }
        }
}
#line 925 "parser.tab.cc"
    break;

  case 73:
#line 348 "parser.yy"
                {setID(yystack_[0].value.as < std::string > ());}
#line 931 "parser.tab.cc"
    break;

  case 74:
#line 349 "parser.yy"
{
        scope.insertParameterOnScope(yystack_[4].value.as < std::string > (),currentType);
        resetCurrentType();
        resetID();
}
#line 941 "parser.tab.cc"
    break;

  case 89:
#line 375 "parser.yy"
{
        es = ExpressionSolver();
        expressionFlag = 1;
        es.insertOprnd(var->name);
        es.insertOptr(5);
}
#line 952 "parser.tab.cc"
    break;

  case 90:
#line 382 "parser.yy"
{
        es.assign();
        quads.importSolver(es); 
        expressionFlag = 0;
        //int id = var->dir;
        //quads.insertQuad(101,quads.getLastQuad().result,-1,id);
}
#line 964 "parser.tab.cc"
    break;

  case 92:
#line 394 "parser.yy"
               {
        ps = ParamSolver(yystack_[0].value.as < std::string > ());
        params.push(ps);
        paramsFlag = 1;
        quads.insertQuad(202,params.top().getFunctionGlobalDir(),-1,-1);
}
#line 975 "parser.tab.cc"
    break;

  case 93:
#line 399 "parser.yy"
                    {
        params.top().checkParams(); 
        paramsFlag = 0; 
        quads.insertQuad(204,params.top().getFunctionGlobalDir(),-1,-1);
        params.pop();
        }
#line 986 "parser.tab.cc"
    break;

  case 94:
#line 407 "parser.yy"
                          {
        es = ExpressionSolver();
        expressionFlag = 1;
}
#line 995 "parser.tab.cc"
    break;

  case 95:
#line 410 "parser.yy"
                  {
        quads.importSolver(es); 
        expressionFlag = 0;
        int single = es.singleVar();
        if(single){
                es.checkVarType(single);
                quads.insertQuad(298,single,-1,-1);
        }else{
                es.checkVarType(quads.getLastQuad().result);
                quads.insertQuad(298,quads.getLastQuad().result,-1,-1);
        }
}
#line 1012 "parser.tab.cc"
    break;

  case 96:
#line 424 "parser.yy"
                                    { quads.insertQuad(103,-1,-1,var->dir);}
#line 1018 "parser.tab.cc"
    break;

  case 97:
#line 427 "parser.yy"
                      { es = ExpressionSolver(); expressionFlag = 1;}
#line 1024 "parser.tab.cc"
    break;

  case 99:
#line 428 "parser.yy"
                              {cout << "Constante string : " << yystack_[0].value.as < std::string > () << endl;}
#line 1030 "parser.tab.cc"
    break;

  case 100:
#line 429 "parser.yy"
                             {
                        cout<<"Antes"<<endl;
                        quads.importSolver(es); 
                        expressionFlag = 0;
                        cout<<"Antes 2"<<endl;
                        int single = es.singleVar();
                        cout<<"Antes3"<<endl;
                        if(single){
                                quads.insertQuad(102,single,-1,-1);
                        }else{
                                quads.insertQuad(102,quads.getLastQuad().result,-1,-1);
                        }
                }
#line 1048 "parser.tab.cc"
    break;

  case 101:
#line 442 "parser.yy"
                                  {
                        quads.importSolver(es); 
                        expressionFlag = 0;
                        int single = es.singleVar();
                        if(single){
                                quads.insertQuad(102,single,-1,-1);
                        }else{
                                quads.insertQuad(102,quads.getLastQuad().result,-1,-1);
                        }
                        es = ExpressionSolver(); 
                        expressionFlag = 1;
                }
#line 1065 "parser.tab.cc"
    break;

  case 103:
#line 454 "parser.yy"
                         {cout << "Constante string : " << yystack_[0].value.as < std::string > () << endl;}
#line 1071 "parser.tab.cc"
    break;

  case 105:
#line 457 "parser.yy"
                             {es = ExpressionSolver(); expressionFlag = 1;}
#line 1077 "parser.tab.cc"
    break;

  case 106:
#line 457 "parser.yy"
                                                                                            {
        quads.importSolver(es); 
        expressionFlag = 0;
        int single = es.singleVar();
        setJDir(quads.getQuadLastDir());
        if(single){
                quads.insertQuad(201,single,-1,-1);
        }else{
                quads.insertQuad(201,quads.getLastQuad().result,-1,-1);
        }
}
#line 1093 "parser.tab.cc"
    break;

  case 108:
#line 469 "parser.yy"
                { 
                int dir = getJDir();
                quads.updateQuadResult(dir,quads.getQuadLastDir()); 
                setJDir(quads.getQuadLastDir());
                quads.insertQuad(200,-1,-1,-1);
        }
#line 1104 "parser.tab.cc"
    break;

  case 109:
#line 474 "parser.yy"
                             {
                int dir = getJDir();
                quads.updateQuadResult(dir,quads.getQuadLastDir());
        }
#line 1113 "parser.tab.cc"
    break;

  case 110:
#line 478 "parser.yy"
                {
                int dir = getJDir();
                quads.updateQuadResult(dir,quads.getQuadLastDir()); 
        }
#line 1122 "parser.tab.cc"
    break;

  case 113:
#line 487 "parser.yy"
                   {
        ps = ParamSolver(yystack_[0].value.as < std::string > ());
        params.push(ps);
        paramsFlag = 1;
        quads.insertQuad(202,params.top().getFunctionGlobalDir(),-1,-1);
        }
#line 1133 "parser.tab.cc"
    break;

  case 116:
#line 494 "parser.yy"
                       {
                params.top().checkParams();
                if(params.size()<2){
                        paramsFlag = 0; 
                } 
                quads.insertQuad(204,params.top().getFunctionGlobalDir(),-1,-1);
                string temp = params.top().generateReturnQuad();
                int dir = scope.getVarOnScope(temp)->dir;
                quads.insertQuad(5,params.top().getFunctionGlobalDir(),-1,dir);
                if(params.size()>1){
                        pes.top().insertOprnd(temp);
                }else{
                        if(expressionFlag){
                                es.insertOprnd(temp);
                        }
                }
                params.pop();
        }
#line 1156 "parser.tab.cc"
    break;

  case 122:
#line 518 "parser.yy"
           {if(paramsFlag){pes.top().insertOptr(6);}else{ if(expressionFlag){es.insertOptr(6);}}}
#line 1162 "parser.tab.cc"
    break;

  case 123:
#line 519 "parser.yy"
           {if(paramsFlag){pes.top().insertOptr(7);}else{ if(expressionFlag){es.insertOptr(7);}}}
#line 1168 "parser.tab.cc"
    break;

  case 124:
#line 520 "parser.yy"
           {if(paramsFlag){pes.top().insertOptr(10);}else{ if(expressionFlag){es.insertOptr(10);}}}
#line 1174 "parser.tab.cc"
    break;

  case 125:
#line 521 "parser.yy"
           {if(paramsFlag){pes.top().insertOptr(11);}else{ if(expressionFlag){es.insertOptr(11);}}}
#line 1180 "parser.tab.cc"
    break;

  case 126:
#line 522 "parser.yy"
           {if(paramsFlag){pes.top().insertOptr(8);}else{ if(expressionFlag){es.insertOptr(8);}}}
#line 1186 "parser.tab.cc"
    break;

  case 127:
#line 523 "parser.yy"
           {if(paramsFlag){pes.top().insertOptr(9);}else{ if(expressionFlag){es.insertOptr(9);}}}
#line 1192 "parser.tab.cc"
    break;

  case 128:
#line 524 "parser.yy"
                   {if(paramsFlag){pes.top().insertOptr(12);}else{ if(expressionFlag){es.insertOptr(12);}}}
#line 1198 "parser.tab.cc"
    break;

  case 130:
#line 525 "parser.yy"
                  {if(paramsFlag){pes.top().insertOptr(13);}else{ if(expressionFlag){es.insertOptr(13);}}}
#line 1204 "parser.tab.cc"
    break;

  case 133:
#line 529 "parser.yy"
           {
        if(paramsFlag){
                cout<<"Aqui se rompe exp"<<endl;
                if(pes.top().operators.size() > 0){
                        if(pes.top().operators.top() == 0 || pes.top().operators.top() == 1){
                                pes.top().checkStacks();
                        }
                }
        }else{ 
                cout<<"Aqui se rompe exp"<<endl;
                if(expressionFlag){
                        cout<<"Aqui se rompe exp2"<<endl;
                        if(es.operators.size() > 0){
                                if(es.operators.top() == 0 || es.operators.top() == 1){
                                        es.checkStacks();
                                }
                        }
                        cout<<"Aqui se rompe exp3"<<endl;
                }
        }
        }
#line 1230 "parser.tab.cc"
    break;

  case 135:
#line 550 "parser.yy"
               {if(paramsFlag){pes.top().insertOptr(0);}else{ if(expressionFlag){es.insertOptr(0);}}}
#line 1236 "parser.tab.cc"
    break;

  case 137:
#line 551 "parser.yy"
               {if(paramsFlag){pes.top().insertOptr(1);}else{ if(expressionFlag){es.insertOptr(1);}}}
#line 1242 "parser.tab.cc"
    break;

  case 140:
#line 555 "parser.yy"
              {
        if(paramsFlag){
                cout<<"Aqui se rompe"<<endl;
                if(pes.top().operators.size() > 0){
                        if(pes.top().operators.top() == 2 || pes.top().operators.top() == 3 || pes.top().operators.top() == 4){
                                pes.top().checkStacks();
                        }
                }
        }else{
                if(expressionFlag){
                cout<<"Aqui se rompe term"<<endl;
                        if(es.operators.size() > 0){
                                if(es.operators.top() == 2 || es.operators.top() == 3 || es.operators.top() == 4){
                                        es.checkStacks();
                                }
                        }
                }
        }
        }
#line 1266 "parser.tab.cc"
    break;

  case 142:
#line 574 "parser.yy"
                {if(paramsFlag){pes.top().insertOptr(2);}else{if(expressionFlag){es.insertOptr(2);}}}
#line 1272 "parser.tab.cc"
    break;

  case 144:
#line 575 "parser.yy"
                {if(paramsFlag){pes.top().insertOptr(3);}else{if(expressionFlag){es.insertOptr(3);}}}
#line 1278 "parser.tab.cc"
    break;

  case 146:
#line 576 "parser.yy"
                {if(paramsFlag){pes.top().insertOptr(4);}else{if(expressionFlag){es.insertOptr(4);}}}
#line 1284 "parser.tab.cc"
    break;

  case 157:
#line 590 "parser.yy"
              {if(paramsFlag){pes.top().insertOprnd((int)yystack_[0].value.as < float > ());}else{ if(expressionFlag){es.insertOprnd((int)yystack_[0].value.as < float > ());}}}
#line 1290 "parser.tab.cc"
    break;

  case 158:
#line 591 "parser.yy"
                {if(paramsFlag){pes.top().insertOprnd((float)yystack_[0].value.as < float > ());}else{ if(expressionFlag){es.insertOprnd((float)yystack_[0].value.as < float > ());}}}
#line 1296 "parser.tab.cc"
    break;

  case 159:
#line 592 "parser.yy"
                {if(paramsFlag){pes.top().insertOprnd((char)yystack_[0].value.as < char > ());}else{ if(expressionFlag){es.insertOprnd((char)yystack_[0].value.as < char > ());}}}
#line 1302 "parser.tab.cc"
    break;

  case 160:
#line 595 "parser.yy"
                            {es = ExpressionSolver(); expressionFlag = 1;}
#line 1308 "parser.tab.cc"
    break;

  case 161:
#line 595 "parser.yy"
                                                                                           {
        setJDir(quads.getQuadLastDir());
        quads.importSolver(es); 
        expressionFlag = 0;
        int single = es.singleVar();
        setJDir(quads.getQuadLastDir());
        if(single){
                quads.insertQuad(201,single,-1,-1);
        }else{
                quads.insertQuad(201,quads.getLastQuad().result,-1,-1);
        }
}
#line 1325 "parser.tab.cc"
    break;

  case 162:
#line 606 "parser.yy"
                          {
        int dir = getJDir();
        int exp = getJDir();
        quads.insertQuad(200,-1,-1,exp);
        quads.updateQuadResult(dir,quads.getQuadLastDir());
}
#line 1336 "parser.tab.cc"
    break;

  case 163:
#line 614 "parser.yy"
                                      {
        es = ExpressionSolver(); 
        expressionFlag = 1;
        setforID(var->name);
        es.insertOprnd(var->name);
        es.insertOptr(5);
}
#line 1348 "parser.tab.cc"
    break;

  case 164:
#line 620 "parser.yy"
      {
        es.assign();
        quads.importSolver(es); 
        expressionFlag = 0;

        string assign = var->name;
        es = ExpressionSolver(); 
        expressionFlag = 1;
        es.insertOprnd(assign);
}
#line 1363 "parser.tab.cc"
    break;

  case 165:
#line 629 "parser.yy"
     { es.insertOptr(9);}
#line 1369 "parser.tab.cc"
    break;

  case 166:
#line 629 "parser.yy"
                              {
        quads.importSolver(es); 
        expressionFlag = 0; 
        int lastDir = quads.getQuadLastDir();
        setJDir(lastDir);
        quads.insertQuad(201,quads.getLastQuad().result,-1,-1);
}
#line 1381 "parser.tab.cc"
    break;

  case 167:
#line 635 "parser.yy"
                          {
        string fid = getforID();
        es = ExpressionSolver(); 
        expressionFlag = 1;
        es.insertOprnd(fid);
        es.insertOptr(5);
        es.insertOprnd(fid);
        es.insertOptr(0);
        es.insertOprnd(1);
        es.assign();
        quads.importSolver(es); 
        expressionFlag = 0;

        int dir = getJDir();
        quads.insertQuad(200,-1,-1,dir-1);
        quads.updateQuadResult(dir,quads.getQuadLastDir());
}
#line 1403 "parser.tab.cc"
    break;


#line 1407 "parser.tab.cc"

            default:
              break;
            }
        }
#if YY_EXCEPTIONS
      catch (const syntax_error& yyexc)
        {
          YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
          error (yyexc);
          YYERROR;
        }
#endif // YY_EXCEPTIONS
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;
      YY_STACK_PRINT ();

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, YY_MOVE (yylhs));
    }
    goto yynewstate;


  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        error (yyla.location, yysyntax_error_ (yystack_[0].state, yyla));
      }


    yyerror_range[1].location = yyla.location;
    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.type_get () == yyeof_)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:
    /* Pacify compilers when the user code never invokes YYERROR and
       the label yyerrorlab therefore never appears in user code.  */
    if (false)
      YYERROR;

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    goto yyerrlab1;


  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    {
      stack_symbol_type error_token;
      for (;;)
        {
          yyn = yypact_[+yystack_[0].state];
          if (!yy_pact_value_is_default_ (yyn))
            {
              yyn += yy_error_token_;
              if (0 <= yyn && yyn <= yylast_ && yycheck_[yyn] == yy_error_token_)
                {
                  yyn = yytable_[yyn];
                  if (0 < yyn)
                    break;
                }
            }

          // Pop the current state because it cannot handle the error token.
          if (yystack_.size () == 1)
            YYABORT;

          yyerror_range[1].location = yystack_[0].location;
          yy_destroy_ ("Error: popping", yystack_[0]);
          yypop_ ();
          YY_STACK_PRINT ();
        }

      yyerror_range[2].location = yyla.location;
      YYLLOC_DEFAULT (error_token.location, yyerror_range, 2);

      // Shift the error token.
      error_token.state = state_type (yyn);
      yypush_ ("Shifting", YY_MOVE (error_token));
    }
    goto yynewstate;


  /*-------------------------------------.
  | yyacceptlab -- YYACCEPT comes here.  |
  `-------------------------------------*/
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;


  /*-----------------------------------.
  | yyabortlab -- YYABORT comes here.  |
  `-----------------------------------*/
  yyabortlab:
    yyresult = 1;
    goto yyreturn;


  /*-----------------------------------------------------.
  | yyreturn -- parsing is finished, return the result.  |
  `-----------------------------------------------------*/
  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
#if YY_EXCEPTIONS
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack\n";
        // Do not try to display the values of the reclaimed symbols,
        // as their printers might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
#endif // YY_EXCEPTIONS
  }

  void
  parser::error (const syntax_error& yyexc)
  {
    error (yyexc.location, yyexc.what ());
  }

  // Generate an error message.
  std::string
  parser::yysyntax_error_ (state_type yystate, const symbol_type& yyla) const
  {
    // Number of reported tokens (one for the "unexpected", one per
    // "expected").
    std::ptrdiff_t yycount = 0;
    // Its maximum.
    enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
    // Arguments of yyformat.
    char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];

    /* There are many possibilities here to consider:
       - If this state is a consistent state with a default action, then
         the only way this function was invoked is if the default action
         is an error action.  In that case, don't check for expected
         tokens because there are none.
       - The only way there can be no lookahead present (in yyla) is
         if this state is a consistent state with a default action.
         Thus, detecting the absence of a lookahead is sufficient to
         determine that there is no unexpected or expected token to
         report.  In that case, just report a simple "syntax error".
       - Don't assume there isn't a lookahead just because this state is
         a consistent state with a default action.  There might have
         been a previous inconsistent state, consistent state with a
         non-default action, or user semantic action that manipulated
         yyla.  (However, yyla is currently not documented for users.)
       - Of course, the expected token list depends on states to have
         correct lookahead information, and it depends on the parser not
         to perform extra reductions after fetching a lookahead from the
         scanner and before detecting a syntax error.  Thus, state merging
         (from LALR or IELR) and default reductions corrupt the expected
         token list.  However, the list is correct for canonical LR with
         one exception: it will still contain any token that will not be
         accepted due to an error action in a later state.
    */
    if (!yyla.empty ())
      {
        symbol_number_type yytoken = yyla.type_get ();
        yyarg[yycount++] = yytname_[yytoken];

        int yyn = yypact_[+yystate];
        if (!yy_pact_value_is_default_ (yyn))
          {
            /* Start YYX at -YYN if negative to avoid negative indexes in
               YYCHECK.  In other words, skip the first -YYN actions for
               this state because they are default actions.  */
            int yyxbegin = yyn < 0 ? -yyn : 0;
            // Stay within bounds of both yycheck and yytname.
            int yychecklim = yylast_ - yyn + 1;
            int yyxend = yychecklim < yyntokens_ ? yychecklim : yyntokens_;
            for (int yyx = yyxbegin; yyx < yyxend; ++yyx)
              if (yycheck_[yyx + yyn] == yyx && yyx != yy_error_token_
                  && !yy_table_value_is_error_ (yytable_[yyx + yyn]))
                {
                  if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                    {
                      yycount = 1;
                      break;
                    }
                  else
                    yyarg[yycount++] = yytname_[yyx];
                }
          }
      }

    char const* yyformat = YY_NULLPTR;
    switch (yycount)
      {
#define YYCASE_(N, S)                         \
        case N:                               \
          yyformat = S;                       \
        break
      default: // Avoid compiler warnings.
        YYCASE_ (0, YY_("syntax error"));
        YYCASE_ (1, YY_("syntax error, unexpected %s"));
        YYCASE_ (2, YY_("syntax error, unexpected %s, expecting %s"));
        YYCASE_ (3, YY_("syntax error, unexpected %s, expecting %s or %s"));
        YYCASE_ (4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
        YYCASE_ (5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
      }

    std::string yyres;
    // Argument number.
    std::ptrdiff_t yyi = 0;
    for (char const* yyp = yyformat; *yyp; ++yyp)
      if (yyp[0] == '%' && yyp[1] == 's' && yyi < yycount)
        {
          yyres += yytnamerr_ (yyarg[yyi++]);
          ++yyp;
        }
      else
        yyres += *yyp;
    return yyres;
  }


  const short parser::yypact_ninf_ = -234;

  const signed char parser::yytable_ninf_ = -114;

  const short
  parser::yypact_[] =
  {
      -9,    25,    63,  -234,  -234,  -234,    87,    65,    46,  -234,
    -234,  -234,    74,    72,    64,  -234,    23,    66,  -234,   109,
    -234,   113,  -234,  -234,  -234,  -234,  -234,  -234,    88,  -234,
      85,  -234,    90,    36,  -234,  -234,  -234,    75,    64,  -234,
      95,    76,   -14,    77,  -234,  -234,  -234,    80,    64,   116,
    -234,   124,  -234,    23,  -234,   122,  -234,  -234,  -234,  -234,
     128,    83,    16,  -234,  -234,  -234,  -234,   121,   123,    64,
    -234,   133,    36,    86,  -234,   129,   131,  -234,   134,    93,
    -234,  -234,  -234,    65,  -234,  -234,  -234,    80,   135,    45,
    -234,  -234,   136,  -234,  -234,  -234,  -234,   132,   138,   139,
     140,    96,   142,  -234,   127,   147,    45,    45,    45,    45,
      45,    45,    45,  -234,  -234,   148,    74,     8,    96,  -234,
    -234,  -234,  -234,   137,    22,   149,  -234,  -234,  -234,  -234,
    -234,  -234,  -234,  -234,  -234,     8,  -234,  -234,   153,   152,
    -234,  -234,  -234,  -234,  -234,   157,    94,  -234,  -234,     0,
     150,    -6,     8,     8,  -234,    96,  -234,   165,  -234,  -234,
     164,     8,   166,   -14,    45,     8,  -234,  -234,  -234,  -234,
    -234,  -234,  -234,     8,    57,    44,   159,  -234,  -234,  -234,
    -234,  -234,  -234,  -234,   167,   169,   161,   171,   163,   170,
       8,  -234,    96,  -234,  -234,     8,  -234,   172,  -234,     8,
    -234,   168,  -234,   175,   173,    11,  -234,  -234,  -234,  -234,
    -234,  -234,  -234,  -234,  -234,    21,  -234,   174,   180,  -234,
    -234,  -234,  -234,  -234,  -234,  -234,  -234,  -234,   176,   182,
    -234,  -234,  -234,  -234,  -234,     8,     8,     8,     8,     8,
     141,  -234,  -234,    -6,  -234,    -6,   143,   145,   151,   184,
      93,  -234,  -234,  -234,     8,     8,  -234,  -234,  -234,  -234,
    -234,  -234,  -234,   186,  -234,  -234,   187,   189,  -234,  -234,
    -234,   177,  -234,    23,  -234,  -234,   141,  -234,  -234,    45,
      45,     8,     8,  -234,  -234,  -234,   185,   190,  -234,  -234,
     156,  -234,   158,   184,  -234,  -234,  -234,   193,  -234,   196,
      45,    45,   198,   199,  -234,  -234
  };

  const unsigned char
  parser::yydefact_[] =
  {
       0,     0,     0,     2,     4,     1,     0,     3,     0,    37,
       5,    35,     3,     3,     0,    49,     3,     0,    47,     0,
       7,     0,    48,    65,    59,    60,    61,    41,     0,    64,
       0,    46,     3,     0,    50,    42,     6,     0,     0,    55,
       3,     0,     0,     0,     8,    11,    12,     0,     3,     0,
      38,     0,    54,     3,    45,     0,     9,    63,    62,    13,
       3,     0,     0,    14,    53,    52,    51,     0,     0,     3,
      44,     0,     0,     0,    22,     0,    16,    15,     0,     3,
      58,    57,    56,     3,    10,    21,    20,     0,     0,     3,
      73,    76,     0,    36,    17,    19,    94,     0,     0,     0,
       0,     0,    66,    88,     0,     0,     3,     3,     3,     3,
       3,     3,     3,   111,   112,     3,     3,     3,     0,    97,
     105,   160,    66,     0,     3,     0,    89,    43,    81,    82,
      83,    84,    85,    86,    87,     3,    80,    79,     0,     0,
      26,   151,   152,   153,   149,     0,   121,   133,   140,     0,
       0,     3,     3,     3,   163,     0,    70,     3,    67,    28,
       0,     3,     3,     0,     3,     3,    95,   122,   124,   125,
     126,   127,   123,     3,     3,     3,    66,   159,   157,   158,
     156,   155,   150,   154,     0,    99,     0,   100,     0,     0,
       3,    68,     0,    72,    69,     3,    93,     0,    91,     3,
      25,     0,    74,     0,     0,     3,   135,   137,   139,   134,
     142,   144,   146,   148,   141,     0,    96,     0,     0,   101,
     106,   161,   164,    71,    29,    90,    24,    23,     3,     0,
      27,   128,   130,   132,   120,     3,     3,     3,     3,     3,
       0,   116,   114,     3,    98,     3,     0,     0,     0,     3,
       3,    78,    75,    39,     3,     3,   136,   138,   143,   145,
     147,   113,   115,     3,   104,   102,     0,     0,   165,    31,
      34,     0,    77,     3,   129,   131,     0,   119,   117,     3,
       3,     3,     3,    30,    40,   118,     0,     0,   166,    32,
       3,   162,     0,     3,   108,   110,   107,     0,    33,     0,
       3,     3,     0,     0,   167,   109
  };

  const short
  parser::yypgoto_[] =
  {
    -234,  -234,    -7,  -234,  -234,  -234,   -19,  -234,   144,  -234,
    -234,   119,   125,  -234,  -234,  -234,  -234,    89,  -234,  -234,
    -234,    -4,  -234,  -234,   -79,  -234,  -234,   146,  -234,   -51,
    -234,  -234,  -234,  -234,  -234,  -234,    99,   178,  -234,  -234,
    -234,   154,  -234,   -38,    54,  -234,   -98,  -234,  -234,  -234,
     -32,  -234,  -234,  -234,  -234,   -96,  -234,  -234,  -234,  -234,
    -234,  -234,  -234,  -234,  -234,  -234,  -154,  -234,  -234,  -234,
    -234,  -234,  -234,  -234,  -234,  -233,  -234,  -234,  -234,  -234,
    -116,  -234,  -234,  -234,  -234,  -112,  -234,  -234,  -234,  -234,
    -164,  -234,  -234,  -234,  -234,  -234,  -234,  -234,  -234,  -234,
    -234,  -234,  -234,  -234,  -234,  -234,  -234,  -234
  };

  const short
  parser::yydefgoto_[] =
  {
      -1,     2,   143,     3,     6,    12,    21,    33,    44,    72,
      45,    46,    63,    87,    88,    47,    75,   137,   201,   144,
     165,   160,   195,   249,   271,   282,   293,    10,    13,    28,
      68,   273,    36,    49,    55,    19,    16,    22,    48,    66,
      40,    52,    82,    29,    59,    30,   104,   124,   158,   194,
      92,   115,   228,   252,   138,   105,   106,   161,   197,   107,
     125,   108,   117,   109,   110,   151,   186,   245,   217,   111,
     152,   246,   296,   299,   112,   181,   215,   242,   263,   278,
     187,   173,   234,   254,   255,   146,   174,   209,   235,   236,
     147,   175,   214,   237,   238,   239,   148,   149,   182,   183,
     113,   153,   247,   114,   190,   248,   281,   292
  };

  const short
  parser::yytable_[] =
  {
       9,   145,    70,   123,    58,    15,    18,   262,   140,    27,
     128,   129,   130,   131,   132,   133,   134,   141,   142,    51,
     150,     1,   140,   162,    77,    39,   240,   155,    24,    25,
      26,   141,   142,    54,   135,   159,   188,   189,    57,   231,
     232,    64,    41,   285,    42,   198,    27,   185,    43,   204,
      51,   180,   176,    74,   177,   178,   179,   191,    24,    25,
      26,   205,    80,     5,    23,    24,    25,    26,   203,   210,
     211,   212,    91,   258,   259,   260,     9,     4,   222,   224,
     206,   207,   103,    96,    97,    98,    61,   226,    62,   264,
      99,   265,   100,   101,   223,     7,     8,   102,    11,   103,
     103,   103,   103,   103,   103,   103,    14,    17,   136,    15,
     167,   168,   169,   170,   171,   172,    20,   156,    31,    32,
      34,    35,    37,   256,   257,    58,    38,    50,    56,    53,
      67,    69,    60,    71,    73,    76,    78,    79,   274,   275,
      83,    85,    86,   -18,    89,    90,   118,    43,   122,   126,
     193,   116,   119,   120,   121,   200,   -92,   103,   127,   154,
     135,   163,   164,   159,   166,   184,   289,   208,   213,   288,
     192,   196,   199,  -113,   216,  -103,   218,   219,   220,   225,
     243,   227,   250,   286,   287,   221,   229,   244,   230,   253,
     269,   276,   283,   261,   266,   267,   290,   279,   233,   280,
     268,   291,   294,   300,   302,   303,   301,    95,   297,   304,
     305,   241,    94,   157,   298,   139,    84,   202,   272,     0,
       0,   251,   284,    81,     0,     0,    65,     0,     0,    93,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   270,    91,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   277,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    27,     0,     0,     0,
       0,     0,   103,   103,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   295,     0,     0,   270,     0,     0,     0,
       0,     0,     0,   103,   103
  };

  const short
  parser::yycheck_[] =
  {
       7,   117,    53,   101,    42,    12,    13,   240,    14,    16,
     106,   107,   108,   109,   110,   111,   112,    23,    24,    38,
     118,    30,    14,   135,    62,    32,     5,     5,    42,    43,
      44,    23,    24,    40,    12,    14,   152,   153,    52,    28,
      29,    48,     6,   276,     8,   161,    53,    53,    12,   165,
      69,   149,    52,    60,    54,    55,    56,   155,    42,    43,
      44,   173,    69,     0,    41,    42,    43,    44,   164,    25,
      26,    27,    79,   237,   238,   239,    83,    52,   190,   195,
      23,    24,    89,    38,    39,    40,     6,   199,     8,   243,
      45,   245,    47,    48,   192,     8,    31,    52,    52,   106,
     107,   108,   109,   110,   111,   112,    32,    35,   115,   116,
      16,    17,    18,    19,    20,    21,    52,   124,    52,    10,
       7,    33,    37,   235,   236,   163,    36,    52,    52,    34,
      14,     7,    55,    11,     6,    52,    15,    14,   254,   255,
       7,    55,    13,    12,    10,    52,    14,    12,    52,    22,
     157,    15,    14,    14,    14,   162,    14,   164,    11,    22,
      12,     8,    10,    14,     7,    15,   282,   174,   175,   281,
       5,     7,     6,    14,     7,     6,    15,     6,    15,     7,
       6,    13,     6,   279,   280,    15,    11,     7,    15,     7,
       6,     5,    15,    52,    51,    50,    11,    10,   205,    10,
      49,    11,    46,    10,   300,   301,    10,    88,    50,    11,
      11,   215,    87,   124,   293,   116,    72,   163,   250,    -1,
      -1,   228,   273,    69,    -1,    -1,    48,    -1,    -1,    83,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   249,   250,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   263,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   273,    -1,    -1,    -1,
      -1,    -1,   279,   280,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   290,    -1,    -1,   293,    -1,    -1,    -1,
      -1,    -1,    -1,   300,   301
  };

  const unsigned char
  parser::yystos_[] =
  {
       0,    30,    58,    60,    52,     0,    61,     8,    31,    59,
      84,    52,    62,    85,    32,    59,    93,    35,    59,    92,
      52,    63,    94,    41,    42,    43,    44,    59,    86,   100,
     102,    52,    10,    64,     7,    33,    89,    37,    36,    59,
      97,     6,     8,    12,    65,    67,    68,    72,    95,    90,
      52,    63,    98,    34,    59,    91,    52,    52,   100,   101,
      55,     6,     8,    69,    59,    94,    96,    14,    87,     7,
      86,    11,    66,     6,    59,    73,    52,   100,    15,    14,
      59,    98,    99,     7,    65,    55,    13,    70,    71,    10,
      52,    59,   107,    84,    69,    68,    38,    39,    40,    45,
      47,    48,    52,    59,   103,   112,   113,   116,   118,   120,
     121,   126,   131,   157,   160,   108,    15,   119,    14,    14,
      14,    14,    52,   103,   104,   117,    22,    11,   112,   112,
     112,   112,   112,   112,   112,    12,    59,    74,   111,    93,
      14,    23,    24,    59,    76,   137,   142,   147,   153,   154,
     103,   122,   127,   158,    22,     5,    59,    74,   105,    14,
      78,   114,   142,     8,    10,    77,     7,    16,    17,    18,
      19,    20,    21,   138,   143,   148,    52,    54,    55,    56,
     103,   132,   155,   156,    15,    53,   123,   137,   137,   137,
     161,   103,     5,    59,   106,    79,     7,   115,   137,     6,
      59,    75,   101,   112,   137,   142,    23,    24,    59,   144,
      25,    26,    27,    59,   149,   133,     7,   125,    15,     6,
      15,    15,   142,   103,   137,     7,   142,    13,   109,    11,
      15,    28,    29,    59,   139,   145,   146,   150,   151,   152,
       5,    78,   134,     6,     7,   124,   128,   159,   162,    80,
       6,    59,   110,     7,   140,   141,   142,   142,   147,   147,
     147,    52,   132,   135,   123,   123,    51,    50,    49,     6,
      59,    81,   107,    88,   137,   137,     5,    59,   136,    10,
      10,   163,    82,    15,    86,   132,   112,   112,   142,   137,
      11,    11,   164,    83,    46,    59,   129,    50,    81,   130,
      10,    10,   112,   112,    11,    11
  };

  const unsigned char
  parser::yyr1_[] =
  {
       0,    57,    58,    59,    61,    62,    60,    64,    63,    66,
      65,    65,    67,    67,    68,    69,    70,    69,    71,    69,
      72,    73,    73,    74,    75,    75,    77,    76,    79,    80,
      78,    82,    83,    81,    81,    85,    84,    84,    87,    88,
      86,    86,    90,    89,    91,    91,    92,    92,    93,    93,
      95,    94,    96,    96,    97,    97,    98,    99,    99,   100,
     100,   100,   101,   101,   102,   102,   104,   103,   105,   105,
     105,   106,   106,   108,   109,   107,   107,   110,   110,   111,
     111,   112,   112,   112,   112,   112,   112,   112,   112,   114,
     113,   115,   117,   116,   119,   118,   120,   122,   121,   123,
     123,   124,   123,   125,   123,   127,   128,   126,   130,   129,
     129,   131,   131,   133,   132,   134,   135,   134,   136,   136,
     137,   137,   138,   138,   138,   138,   138,   138,   140,   139,
     141,   139,   139,   143,   142,   145,   144,   146,   144,   144,
     148,   147,   150,   149,   151,   149,   152,   149,   149,   153,
     153,   154,   154,   154,   155,   155,   155,   156,   156,   156,
     158,   159,   157,   161,   162,   163,   164,   160
  };

  const signed char
  parser::yyr2_[] =
  {
       0,     2,     1,     0,     0,     0,     9,     0,     3,     0,
       4,     1,     1,     2,     2,     2,     0,     4,     0,     4,
       4,     2,     1,     4,     2,     1,     0,     4,     0,     0,
       6,     0,     0,     5,     1,     0,    10,     1,     0,     0,
      14,     1,     0,     7,     2,     1,     2,     1,     2,     1,
       0,     4,     1,     1,     2,     1,     3,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     0,     3,     2,     2,
       1,     2,     1,     0,     0,     7,     1,     2,     1,     1,
       1,     2,     2,     2,     2,     2,     2,     2,     1,     0,
       5,     1,     0,     4,     0,     4,     5,     0,     6,     1,
       1,     0,     4,     0,     4,     0,     0,    11,     0,     5,
       1,     1,     1,     0,     3,     2,     0,     3,     2,     1,
       4,     1,     1,     1,     1,     1,     1,     1,     0,     3,
       0,     3,     1,     0,     3,     0,     3,     0,     3,     1,
       0,     3,     0,     3,     0,     3,     0,     3,     1,     1,
       2,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       0,     0,    10,     0,     0,     0,     0,    14
  };



  // YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
  // First, the terminals, then, starting at \a yyntokens_, nonterminals.
  const char*
  const parser::yytname_[] =
  {
  "\"eof\"", "error", "$undefined", "COMENTARIO", "SIMBOLO", "PUNTO",
  "COMA", "SCOL", "COL", "GBAJO", "LCUR", "RCUR", "LBRA", "RBRA", "LPAR",
  "RPAR", "EQ", "GE", "LE", "GT", "LT", "NE", "ASSIGN", "SUM", "RES",
  "MUL", "DIV", "MOD", "AND", "OR", "PROGRAMA", "CLASE", "VARIABLES",
  "MAIN", "METODOS", "HEREDA", "ATRIBUTOS", "FUNCION", "RETORNAR", "LEER",
  "ESCRIBIR", "VOID", "INT_T", "FLOAT_T", "CHAR_T", "SI", "SINO",
  "MIENTRAS", "PARA", "EN", "HACER", "ENTONCES", "ID", "STRING", "CHAR",
  "INT", "FLOAT", "$accept", "script", "empty", "program", "$@1", "$@2",
  "declare_var", "$@3", "declare_bridge1", "$@4", "declare_bridge2",
  "declare_bridge3", "declare_bridge4", "$@5", "$@6", "dimensionsdecl",
  "matrixdecl", "dimensions", "matrix", "single_express", "$@7",
  "mult_express", "$@8", "$@9", "expression_loop", "$@10", "$@11",
  "classes", "$@12", "functions", "$@13", "$@14", "main", "$@15",
  "methods", "inheritance", "variables", "var_bridge1", "$@16",
  "var_bridge2", "attributes", "attr_bridge1", "attr_bridge2",
  "primitive_type", "var_type", "return_type", "call_var", "$@17",
  "call_options", "call_cont", "parameters", "$@18", "$@19", "par_cont",
  "par_array", "statutes", "assignment", "$@20", "assignment_opt",
  "call_void", "$@21", "function_return", "$@22", "read", "write", "$@23",
  "write_expression_opt", "$@24", "$@25", "decision_statement", "$@26",
  "$@27", "dec_else", "$@28", "repetition_statement", "call_function",
  "$@29", "func_options", "$@30", "func_cont", "expression", "relop",
  "express_loop", "$@31", "$@32", "exp", "$@33", "exp_loop", "$@34",
  "$@35", "term", "$@36", "term_loop", "$@37", "$@38", "$@39", "factor",
  "sign", "call", "var_cte", "conditional", "$@40", "$@41",
  "nonconditional", "$@42", "$@43", "$@44", "$@45", YY_NULLPTR
  };

#if YYDEBUG
  const short
  parser::yyrline_[] =
  {
       0,   143,   143,   146,   149,   149,   149,   153,   153,   154,
     154,   155,   156,   157,   158,   159,   160,   160,   161,   161,
     166,   167,   168,   171,   172,   173,   178,   178,   197,   201,
     197,   217,   221,   217,   237,   242,   242,   243,   246,   256,
     246,   260,   263,   263,   270,   271,   274,   275,   280,   281,
     284,   283,   299,   300,   307,   308,   309,   310,   311,   316,
     317,   318,   321,   321,   324,   324,   327,   327,   340,   341,
     342,   343,   344,   348,   349,   348,   354,   356,   357,   359,
     360,   364,   365,   366,   367,   368,   369,   370,   371,   375,
     374,   391,   394,   394,   407,   407,   424,   427,   427,   428,
     429,   442,   442,   454,   454,   457,   457,   457,   469,   469,
     478,   484,   484,   487,   487,   493,   494,   494,   512,   513,
     516,   517,   518,   519,   520,   521,   522,   523,   524,   524,
     525,   525,   526,   529,   529,   550,   550,   551,   551,   552,
     555,   555,   574,   574,   575,   575,   576,   576,   577,   580,
     581,   582,   583,   584,   585,   586,   587,   590,   591,   592,
     595,   595,   595,   614,   620,   629,   629,   614
  };

  // Print the state stack on the debug stream.
  void
  parser::yystack_print_ ()
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << int (i->state);
    *yycdebug_ << '\n';
  }

  // Report on the debug stream that the rule \a yyrule is going to be reduced.
  void
  parser::yy_reduce_print_ (int yyrule)
  {
    int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):\n";
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG


#line 6 "parser.yy"
} // yy
#line 2026 "parser.tab.cc"

#line 654 "parser.yy"

void yy::parser::error(const location_type& lugar, const std::string& lexema)
{
  std::cout << "SYNTAX ERROR !!! " << lexema << std::endl;
}
