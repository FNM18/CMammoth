#include <stdio.h>
#include <string>
#include "driver.h"
#include <stack>
#include <vector>
#include <iostream>

using namespace std;

class ClassTable;
class FunctionTable;
class VarTable;
class Scope;
class ExpressionSolver;
class Quad;

extern Scope scope;
extern int tempCount;
//Tabla de clases heredada de SymbolTable que genera una clase
//Esta clase puede generar una tabla de funciones para guardar sus respectivas variables y funciones internas
class ClassTable : public SymbolTable{
  public:
  struct symbolRow{
      string name;
      //VarTable * varTable;
      FunctionTable * functionTable;
      ClassTable * inheritance;
  };
  symbolRow * classRow;
  ClassTable(string name){
    setType("class");
    classRow = new symbolRow();
    classRow->name = name;
    classRow->functionTable = NULL;
    classRow->inheritance = NULL;
    cout << "Class table initialized" << endl;
  };

  string getType(){
    string g = ClassTable::type;
    return g;
  }

  void setType(string type){
    ClassTable::type = type;
  }
};

//Tabla de variables heredada de SymbolTable que genera un mapa de variables
//Cada renglon de variable puede guardar diferentes variables y su respectivo valor
class VarTable : public SymbolTable{
  public:
    struct symbolRow{
      string name;
      int type; //0->Int, 1->float, 2->char, 3->error, 4->Quad
      int dir;
    };

    VarTable(){
      setType("variable");
      cout << "Variable table initialized" << endl;
    };

    string getType(){
      string g = VarTable::type;
      return g;
    }

    void setType(string type){
      VarTable::type = type;
    }

    void insert(struct symbolRow * row){
      if(lookup(row)){
        throw CompilerError("Error, it's already declared!");
      }
      cout << "Name: " << (*row).name << endl;
      cout << "Type: " << (*row).type << endl;
      cout << "Direction: " << (*row).dir << endl;
      VarTable::umap[(*row).name] = row;
      VarTable::umapDir[(*row).dir] = row;
    }

    int lookup(symbolRow * row){
      symbolRow * exist = VarTable::umap[(*row).name];
      if(exist != NULL){
        cout << "Exists!" << endl;
        cout << "Name: " << (*exist).name << endl;
        return 1;
      }
      return 0;
    }

    symbolRow * find(string row){
      symbolRow * exist = VarTable::umap[row];
      if(exist != NULL){
        return exist;
      }
      return NULL;
    }

    symbolRow * find(int row){
      symbolRow * exist = VarTable::umapDir[row];
      if(exist != NULL){
        return exist;
      }
      return NULL;
    }

    void modify(struct symbolRow * row){
      struct symbolRow * exist = VarTable::umap[(*row).name];
      if(exist != NULL){
        (*exist).type = (*row).type;
        //(*exist).role = (*row).role;
        (*exist).dir = (*row).dir;
      }
    }
  protected:
    unordered_map<string, symbolRow*> umap;
    unordered_map<int, symbolRow*> umapDir;
};

//Tabla de funciones heredada de SymbolTable que genera un mapa de funciones
//Cada renglon de funcion puede guardar una tabla de clase o una tabla de variables
class FunctionTable : public SymbolTable{
  public:
    struct symbolRow{
      string name;
      int return_type;//0->int 1->float 2->char 20->void 10->class
      string scope;
      string role;
      VarTable * varTable;
      ClassTable * classTable;
      vector<VarTable::symbolRow> parameters;
      int quadDir = -1;
    };

    FunctionTable(){
      setType("function");
      cout << "Function table initialized" << endl;
    };

    string getType(){
      string g = FunctionTable::type;
      return g;
    }

    void setType(string type){
      FunctionTable::type = type;
    }

    void insert(struct symbolRow * row){
      if(lookup(row)){
        throw CompilerError("Error, it's already declared!");
      }
      cout << "Name: " << (*row).name << endl;
      cout << "Return_type: " << (*row).return_type << endl;
      cout << "Role: " << (*row).role << endl;
      cout << "Scope: " << (*row).scope << endl;
      umap[(*row).name] = row;
    }

    int lookup(symbolRow * row){
      symbolRow * exist = FunctionTable::umap[(*row).name];
      if(exist != NULL){
        cout << "Exists!" << endl;
        cout << "Name: " << (*exist).name << endl;
        return 1;
      }
      return 0;
    }

    symbolRow * find(string row){
      symbolRow * exist = umap[row];
      if(exist != NULL){
        cout << "Exists!" << endl;
        return exist;
      }
      return NULL;
    }

    void modify(struct symbolRow * row){
      struct symbolRow * exist = FunctionTable::umap[(*row).name];
      if(exist != NULL){
        (*exist).return_type = (*row).return_type;
        (*exist).role = (*row).role;
        (*exist).scope = (*row).scope;
        (*exist).varTable = (*row).varTable;
        (*exist).classTable = (*row).classTable;
      }
    }
  protected:
    unordered_map<string, symbolRow*> umap;
};

//Clase para verificar estados y manipulacion de las tablas.
class Scope{
  public:
    string currentState = "global";
    string currentRole = "function";
    SymbolTable * currentTable;
    FunctionTable globalTable;
    unordered_map<int,int> cte_ints;
    unordered_map<float,int> cte_floats;
    unordered_map<char,int> cte_chars;
    //Contadores para el manejo de psuedo direcciones
    //1000-10,000 = Global ; 10,001-20,000 = Local ; 20,001-30,000 = Constantes
    int globalIntCont    =  1000;
    int globalFloatCont  =  6001;
    int globalCharCont   =  9001;
    int localIntCont     = 10001;
    int localFloatCont   = 16001;
    int localCharCont    = 19001;
    int constanIntCont   = 20001; 
    int constanFloatCont = 26001; 
    int constanCharCont  = 29001; 


    FunctionTable::symbolRow * functionScope = NULL;
    
    Scope(){
      currentTable = &globalTable;
      globalInsertFunction("global",20,"function",0);
      installGlobalVars();
    };

    void resetConts(){
      int globalIntCont    =  1000;
      int globalFloatCont  =  6001;
      int globalCharCont   =  9001;
      int localIntCont     = 10001;
      int localFloatCont   = 16001;
      int localCharCont    = 19001;
      int constanIntCont   = 20001; 
      int constanFloatCont = 26001; 
      int constanCharCont  = 29001; 
    }

    void resetLocalConts(){
      int localIntCont     = 10001;
      int localFloatCont   = 16001;
      int localCharCont    = 19001;
    }

    int addGlobalVarDir(int type){
      switch (type){
      case 0:
        return globalIntCont++;
      case 1:
        return globalFloatCont++;
      case 2:
        return globalCharCont++;
      default:
        return -1;
      }
    }

    int addLocalVarDir(int type){
      switch (type){
      case 0:
        return localIntCont++;
      case 1:
        return localFloatCont++;
      case 2:
        return localCharCont++;
      default:
        return -1;
      }
    }

    int addConstantINTVarDir(int value){
      int num = cte_ints[value];
      cout << "El numero: " << num << endl;
      if(num)
        return cte_ints[value];
      cout << "Nueva dir cte: " << constanIntCont << endl;
      cte_ints[value] = constanIntCont;
      return constanIntCont++;
    }

    int addConstantFLOATVarDir(float value){
      int num = cte_floats[value];
      cout << "El numero: " << num << endl;
      if(num)
        return cte_floats[value];
      cout << "Nueva dir cte: " << constanFloatCont << endl;
      cte_floats[value] = constanFloatCont;
      return constanFloatCont++;
    }

    int addConstantCHARVarDir(char value){
      int num = cte_chars[value]; 
      cout << "El numero: " << num << endl;
      if(num)
        return cte_chars[value];
      cout << "Nueva dir cte: " << constanCharCont << endl;
      cte_chars[value] = constanCharCont;
      return constanCharCont++;
    }
  
    void restartState(){
      currentTable = &globalTable;
      currentRole = "function";
      currentState = "global";
    }


    //Cambiar de estados, se usara al implementar clases
    void changeCurrentState(int root, string name){
      if(root){
        restartState();
      }
      if(currentRole == "function"){
        FunctionTable * ft = (FunctionTable *) currentTable;
        FunctionTable::symbolRow * srow = ft->find(name);
        if(!srow){
          throw CompilerError("Error, variable, class or function doesn't exist.");
        }
        if(srow->role == "class"){
          currentTable = srow->classTable;
          cout << "Current State: " << currentRole << " -> class." << endl;
          currentRole = "class";
        }else if(srow->role == "function"){
          currentTable = srow->varTable;
          cout << "Current State: " << currentRole << " -> variable." << endl;
          currentRole = "variable";
        }else{
          throw CompilerError("Error, role not yet defined.");
        }
      }else if (currentRole == "variable"){
        VarTable* vt = (VarTable *) currentTable;
        VarTable::symbolRow * vrow = vt->find(name);
        cout << "Current State: " << currentRole << " -> Cant change state" << endl;
      }else if (currentRole == "class"){
        ClassTable * ct = (ClassTable *) currentTable;
        ClassTable::symbolRow * crow = ct->classRow; 
        if(!crow){
          throw CompilerError("Error, variable, class or function doesn't exist.");
        }
        if(crow->functionTable != NULL){
          currentTable = crow->functionTable;
          cout << "Current State: " << currentRole << " -> class." << endl;
          currentRole = "function";
          currentState = "local";
        }
      }else{
          throw CompilerError("Error, role not yet defined.");
      }
    }

    //GLOBAL FUNCTIONS

    int globalInsertFunction(string name, int type, string role, int quadDir){
      FunctionTable::symbolRow * frow = new FunctionTable::symbolRow();
      frow->name = name;
      frow->return_type = type;
      frow->role = role;
      frow->scope = "global";
      frow->varTable = NULL;
      frow->classTable = NULL;
      frow->quadDir = quadDir;
      globalTable.insert(frow);

      return 1;
    }

    int globalFindFunction(string row){
      FunctionTable::symbolRow * exist = globalTable.find(row);
      if(exist == NULL){
        throw CompilerError("Error, function doesn't exist.");
      }
      return 1;
    }

    FunctionTable::symbolRow * globalGetFunction(string row){
      FunctionTable::symbolRow * exist = globalTable.find(row);
      if(exist == NULL){
        throw CompilerError("Error, function doesn't exist.");
      }
      return exist;
    }

    void installGlobalVars(){
      FunctionTable::symbolRow * exist = globalTable.find("global");
      if(exist == NULL){
        throw CompilerError("Error, variable doesn't exist.");
      }

      (*exist).varTable = new VarTable();
    }

    void installFunctionVars(string name){
      FunctionTable::symbolRow * exist = globalTable.find(name);
      if(exist == NULL){
        throw CompilerError("Error, function doesn't exist.");
      }

      exist->varTable = new VarTable();
    }

    int lookupGlobalVariable(string name){
      VarTable * vt = (VarTable *) globalTable.find("global")->varTable;
      if(!vt){
        throw CompilerError("Error, variable directory doesn't exist.");
      }

      return 1;
    }

    VarTable::symbolRow * getGlobalVariable(string name){
      VarTable * vt = (VarTable *) globalTable.find("global")->varTable;
      if(!vt){
        throw CompilerError("Error, variable directory doesn't exist.");
      }
      VarTable::symbolRow * vrow = vt->find(name);
      return vrow;
    }

    VarTable::symbolRow * getGlobalVariable(int dir){
      VarTable * vt = (VarTable *) globalTable.find("global")->varTable;
      if(!vt){
        throw CompilerError("Error, variable directory doesn't exist.");
      }
      VarTable::symbolRow * vrow = vt->find(dir);
      return vrow;
    }

    void insertGlobalVariable(string name, int type){
      VarTable * vt = (VarTable *) globalTable.find("global")->varTable;
      if(!vt){
        throw CompilerError("Error, variable directory doesn't exist.");
      }
      VarTable::symbolRow * vrow = new VarTable::symbolRow();
      vrow->name = name;
      vrow->type = type;
      vrow->dir = addGlobalVarDir(type);
      vt->insert(vrow);
    }

    void updateGlobalVariable(string name, int type,int dir){
      VarTable * vt = (VarTable *) globalTable.find("global")->varTable;
      if(!vt){
        throw CompilerError("Error, variable directory doesn't exist.");
      }

      VarTable::symbolRow * vrow = new VarTable::symbolRow();
      vrow->name = name;
      vrow->type = type;
      vrow->dir = dir;
      vt->modify(vrow);
    }

    void insertLocalVariable(string name, int type){
      VarTable * vt = (VarTable *) currentTable;
      if(!vt){
        throw CompilerError("Error, variable directory doesn't exist.");
      }
      VarTable::symbolRow * vrow = new VarTable::symbolRow();
      vrow->name = name;
      vrow->type = type;
      vrow->dir = addLocalVarDir(type);
      vt->insert(vrow);
    }

    //FUNCTION SCOPE - LOCAL VARIABLES

    void setFunctionScope(string id){
        FunctionTable::symbolRow * func = globalTable.find(id);
        if(!func){
            throw CompilerError("Error, function doesn't exist.");
        }
        functionScope = func;
        cout << "Scope on function: " << id << endl;
        resetLocalConts();
        cout << "Local variables reset" << endl;
    }

    void freeFunctionScope(){
        functionScope = NULL;
    }

    VarTable::symbolRow * getVarOnScope(string id){
      if(functionScope == NULL){
        throw CompilerError("Error, no function on scope.");
      }
      VarTable * vt = (VarTable *) functionScope->varTable;
      if(vt == NULL){
        throw CompilerError("Error, no variable directory installed on function.");
      }
      VarTable::symbolRow * vrow = vt->find(id);
      // if(vrow == NULL){
      //   throw CompilerError("Error, variable doesn't exist.");
      // }
      return vrow;
    }

    VarTable::symbolRow *  getVarOnScope(int id){
      if(functionScope == NULL){
        throw CompilerError("Error, no function on scope.");
      }
      VarTable * vt = (VarTable *) functionScope->varTable;
      if(vt == NULL){
        throw CompilerError("Error, no variable directory installed on function.");
      }
      VarTable::symbolRow * vrow = vt->find(id);
      // if(vrow == NULL){
      //   throw CompilerError("Error, variable doesn't exist.");
      // }
      return vrow;
    }

    void verifyTypeOnScope(int type){
      if(functionScope == NULL){
        throw CompilerError("Error, no function on scope.");
      }
      if(type != functionScope->return_type){
        throw CompilerError("Error, return type mismatch");
      }
      
    }

    void insertVarOnScope(string name, int type){
      if(functionScope == NULL){
        throw CompilerError("Error, no function on scope.");
      }
      VarTable * vt = (VarTable *) functionScope->varTable;
      if(vt == NULL){
        throw CompilerError("Error, no variable directory installed on function.");
      }
      VarTable::symbolRow * vrow = new VarTable::symbolRow();
      vrow->name = name;
      vrow->type = type;
      vrow->dir = addLocalVarDir(type);

      vt->insert(vrow);
    }

    void insertParameterOnScope(string name, int type){
      insertVarOnScope(name,type);
      VarTable::symbolRow * var = getVarOnScope(name);
      (*functionScope).parameters.push_back(*var);
      cout << "Parametro: " << (*functionScope).parameters[(*functionScope).parameters.size()-1].name << endl;
    }

    void updateVarOnScope(string name, int type, int dir){
      if(functionScope == NULL){
        throw CompilerError("Error, no function on scope.");
      }
      VarTable * vt = (VarTable *) functionScope->varTable;
      if(vt == NULL){
        throw CompilerError("Error, no variable directory installed on function.");
      }
      VarTable::symbolRow * vrow = new VarTable::symbolRow();
      vrow->name = name;
      vrow->type = type;
      vrow->dir = dir;
      if(vrow == NULL){
        throw CompilerError("Error, variable doesn't exist.");
      }
      vt->modify(vrow);
    }

    

    //CLASSES

    void installFunctionDir(){
      cout<<currentRole<<endl;
      if(currentRole != "class"){
        throw CompilerError("Error, scope not on class.");
      }

      ClassTable * ct = (ClassTable *) currentTable;
      if(ct == NULL){
        throw CompilerError("Error, class doesn't exist.");
      }
        ClassTable::symbolRow * crow = ct->classRow;

        cout << "Exists!" << endl;
        cout << "Name: " << (*crow).name << endl;
        crow->functionTable = new FunctionTable();
    }

    void installGlobalClassDir(string index){
      FunctionTable::symbolRow * exist = globalTable.find(index);
      if(exist == NULL){
        throw CompilerError("Error, class doesn't exist.");
      }

      cout << "Exists!" << endl;
      cout << "Name: " << (*exist).name << endl;
      (*exist).classTable = new ClassTable((*exist).name);
    }
};

class ExpressionSolver{
  public:

    struct varAndType{
      string var;
      int type;
      int constant;
    };

    stack<int> operators;
    int optorCount = 0;
    stack<struct varAndType> operands;
    int opranCount = 0;
    stack<char> types;
    
    struct quadruple{
        int op;
        string operandLeft;
        string operandRight;
        string result;
    };

    vector<quadruple> result;
    unordered_map<string, int> resmap;
      
    ExpressionSolver(){
      cout<< "Se creo un objeto Expression Solver" << endl;
    }

    void insertOprnd(string id){
      opranCount++;
      cout<<"Operand: " << id << endl;
      VarTable::symbolRow * var = NULL;
      if(scope.functionScope == NULL){
        var = scope.getGlobalVariable(id);
      }else{
        var = scope.getVarOnScope(id);
        if(var == NULL){
          var = scope.getGlobalVariable(id);
        }
      }
      cout<<"Operand: " << id << endl;
      if(var == NULL){
        throw CompilerError("Error, variable not found.");
      }
      varAndType vt = varAndType();
      vt.constant = 0;
      vt.type = var->type;
      vt.var = var->name;
      operands.push(vt);
      checkStacks();
    }

    void insertOprnd(int id){
      opranCount++;
      struct varAndType vt = varAndType();
      int dir = scope.addConstantINTVarDir(id);
      vt.constant = 1;
      vt.type = 0;
      vt.var = to_string(dir);
      operands.push(vt);
      checkStacks();
    }

    void insertOprnd(float id){
      opranCount++;
      struct varAndType vt = varAndType();
      int dir = scope.addConstantFLOATVarDir(id);
      vt.constant = 1;
      vt.type = 1;
      vt.var = to_string(dir);
      operands.push(vt);
      checkStacks();
    }

    void insertOprnd(char id){
      opranCount++;
      struct varAndType vt = varAndType();
      int dir = scope.addConstantCHARVarDir(id);
      vt.constant = 1;
      vt.type = 2;
      vt.var = to_string(dir);
      operands.push(vt);
      checkStacks();
    }

    void insertOptr(int oper){
      optorCount++;
      operators.push(oper);
    }
    
    //crea fondo falso
    void installPar(){
      operators.push(99);
    }
    
    //termina el fondo falso
    void closePar(){
      int par = operators.top();
      if(par != 99){
        throw CompilerError("Error, incomplete expression.");
      }
      operators.pop();
      checkStacks();
    }

    void assign(){
      checkStacks();
      int assign = operators.top();
      cout << "Stack operandos: " << operands.size() << endl;
      cout << "Stack operadores: " << operators.size() << endl;
      if(assign != 5){
        throw CompilerError("Error, incomplete expression.");
      }
      // for(int i = 0; i < operands.size(); i++){
      //   cout << "ops -> " << operands.top().var << endl;
      //   operands.pop(); 
      // }
      operators.pop();
      operators.push(101);
      checkStacks();
    }

    //verifica que haya dos operandos y un operador para agruparlos
    int checkStacks(){
        int optr;
        varAndType opndLeft, opndRight;
        if(operands.size() >= 2 && operators.size() >= 1 && operators.top() != 99 && operators.top() != 5 ){
          optr = operators.top();
          operators.pop();
          if(optr == 101){
            optr = 5;
          }
          opndRight = operands.top();
          operands.pop();
          opndLeft = operands.top();
          operands.pop();
          varAndType res = solveQuadruple(optr, opndLeft,opndRight);
          operands.push(res);
          quadruple quad = quadruple();
          quad.op = optr;
          quad.operandLeft = opndLeft.var;
          quad.operandRight = opndRight.var;
          quad.result = res.var;
          if(optr == 5)
              quad.result = opndLeft.var;
          result.push_back(quad);
          return 1;
        }
        return 0;
    }

    //resuelve la expresion 
    varAndType solveQuadruple(int optr, varAndType opndLeft, varAndType opndRight){
        //busca si la operacion es valida (checar cubo) 
        SemanticConsideration sc = SemanticConsideration();
        int cubeRes= sc.testCube(opndLeft.type, opndRight.type ,optr);
        varAndType vt = varAndType();
        vt.type = cubeRes;
        vt.var = "_t" + to_string(tempCount++);
        if(optr != 5)
            scope.insertVarOnScope(vt.var,vt.type);
        return vt;
         //si es valida hacer operacion, sino mandar error
    }

    int singleVar(){
      if(opranCount == 1 && optorCount == 0){
        varAndType vt = operands.top();
        operands.pop();
        cout << "Es constante: " << vt.constant << endl;
        if(vt.constant){
          return stoi(vt.var);
        }
        VarTable::symbolRow * var = NULL;
        if(scope.functionScope == NULL){
          var = scope.getGlobalVariable(vt.var);
        }else{
          var = scope.getVarOnScope(vt.var);
          if(var == NULL){
            var = scope.getGlobalVariable(vt.var);
          }
        }

        return var->dir;
      }
      return 0;
    }

    void checkVarType(int dir){
        int paramType;
        if(dir > 20000){
            paramType = 0;
            if(dir > 26000)
              paramType = 1;
            if(dir > 29000)
              paramType = 2;
        }else{    
            VarTable::symbolRow * var = NULL;
            if(scope.functionScope == NULL){
              var = scope.getGlobalVariable(dir);
            }else{
              var = scope.getVarOnScope(dir);
              if(var == NULL){
                var = scope.getGlobalVariable(dir);
              }
            }
            paramType = var->type;
        }

        scope.verifyTypeOnScope(paramType);
    }

    vector<quadruple> exportQuads(){
      return result;
    }

};

class Quad{
  public:

    struct varAndType{
      string var;
      int type;
    };

    struct quadruple{
        int op;
        int operandLeft;
        int operandRight;
        int result;
    };

    vector<quadruple> quadList;
      
    Quad(){
      cout << "Se creo un objeto Quad." << endl;
    };

    void importSolver(ExpressionSolver es){
        vector<ExpressionSolver::quadruple> expList = es.exportQuads();
        for(int i = 0; i<expList.size();i++){
          insertQuad(expList[i]);
        }
    };

    int isNumber(const string str){
        for (char const c : str) {
            if (isdigit(c) == 0) return 0;
        }

        return 1;
    }

    void insertQuad(ExpressionSolver::quadruple quad){
        int opl, res;
        int opr = -1;
        if(isNumber(quad.operandLeft)){
            opl = stoi(quad.operandLeft);
        }else{
            VarTable::symbolRow * var = scope.getVarOnScope(quad.operandLeft);
            if(var == NULL){
                var = scope.getGlobalVariable(quad.operandLeft);
            }
            opl = var->dir;
        }
        if(isNumber(quad.operandRight)){
            opr = stoi(quad.operandRight);
        }else{
            VarTable::symbolRow * var = scope.getVarOnScope(quad.operandRight);
            if(var == NULL){
                var = scope.getGlobalVariable(quad.operandRight);
            }
            opr = var->dir;
        }
        VarTable::symbolRow * resvar = scope.getVarOnScope(quad.result);
        if(resvar == NULL){
            resvar = scope.getGlobalVariable(quad.operandLeft);
        }
        res = resvar->dir;
        quadruple convQuad = quadruple();
        convQuad.op = quad.op;
        convQuad.operandLeft = opl;
        convQuad.operandRight = opr;
        convQuad.result = res;
        if(convQuad.op == 5){
          convQuad.operandLeft = opr;
          convQuad.operandRight = -1;
        }
        quadList.push_back(convQuad);
    };

    void insertQuad(int op, int operandLeft, int operandRight, int result){
      quadruple quad = quadruple();
      quad.op = op;
      quad.operandLeft = operandLeft;
      quad.operandRight = operandRight;
      quad.result = result;
      quadList.push_back(quad);
    };

    void updateQuad(int dir,quadruple newQuad){
        if(dir < 0 || dir >= quadList.size()){
          throw CompilerError("Inexistent Quad");
        }
        quadList[dir] = newQuad;
    }

    void updateQuadResult(int dir,int result){
        if(dir < 0 || dir >= quadList.size()){
          throw CompilerError("Inexistent Quad");
        }
        quadList[dir].result = result;
    }

    void updateQuad(int dir,int op, int opleft, int opright, int result){
        if(dir < 0 || dir >= quadList.size()){
          throw CompilerError("Inexistent Quad");
        }
        
        quadList[dir].op = op;
        quadList[dir].operandLeft = opleft;
        quadList[dir].operandRight = opright;
        quadList[dir].result = result;
    }

    quadruple getLastQuad(){
      return quadList[quadList.size()-1];
    }

    int getQuadLastDir(){
      return quadList.size();
    }

    void prepareMainQuad(){
        insertQuad(200,-1,-1,-1);
    }

    void setMainQuad(int dir){
        updateQuad(0,200,-1,-1,dir);
    }

    void setMainQuad(){
        updateQuad(0,200,-1,-1,getQuadLastDir());
    }

    void printList(vector<ExpressionSolver::quadruple> es){
        for(int i = 0; i<es.size();i++){
            cout << es[i].op << " - " << es[i].operandLeft << " - " << es[i].operandRight << " - " << es[i].result << endl;
        };
    };

    void printList(vector<quadruple> es){
        for(int i = 0; i<es.size();i++){
            cout << es[i].op << " - " << es[i].operandLeft << " - " << es[i].operandRight << " - " << es[i].result << endl;
        };
    };

    void printQuadList(){
        cout << "Lista de Quads: \n" << endl;
        for(int i = 0; i<quadList.size();i++){
            cout << i << "| "<< quadList[i].op << " || " << quadList[i].operandLeft << " || " << quadList[i].operandRight << " || " << quadList[i].result << endl;
        };
    };
};

class ParamSolver{
  public:
    FunctionTable::symbolRow * table;
    vector<VarTable::symbolRow> params;
    SemanticConsideration sCube;
    int paramLength = 0;
    int paramCount = 0;
    void searchFunction(string func){
        table = scope.globalGetFunction(func);
        params = table->parameters;
        paramLength = params.size();
    }

    ParamSolver(string function){
      searchFunction(function);
    }

    int getFunctionQuadDir(){
      return table->quadDir;
    }

    int searchVar(int dir){
      VarTable::symbolRow * var = scope.getVarOnScope(dir);
      if(var == NULL){
          var = scope.getGlobalVariable(dir);
      }
      return var->type;
    }

    int insertParam(int dir){
      if(paramCount >= paramLength){
        throw CompilerError("Error: parameters insertion exceeded");
      }
      int paramType;
      if(dir > 20000){
          paramType = 0;
          if(dir > 26000)
            paramType = 1;
          if(dir > 29000)
            paramType = 2;
      }else{
          paramType = searchVar(dir);
      }
      int funcParamType = params[paramCount].type;
      cout<< "Param Insert: " << paramType << " - ParamFunc: " << funcParamType << endl;
      if(paramType != funcParamType){
          throw CompilerError("Error: type mismatch on parameter " + to_string(paramCount));
      }
      return paramCount++ + 1;
    }

    void checkParams(){
      if(paramCount != paramLength){
          throw CompilerError("Error: " + to_string(paramLength-paramCount) + " left");
      }
      cout << "Parametros listos para ser usados" << endl;
    }
};
