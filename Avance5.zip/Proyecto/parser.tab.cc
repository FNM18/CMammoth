// A Bison parser, made by GNU Bison 3.5.1.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2020 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// Undocumented macros, especially those whose name start with YY_,
// are private implementation details.  Do not rely on them.





#include "parser.tab.hh"


// Unqualified %code blocks.
#line 22 "parser.yy"

#include "driver.h"
#include "flags.h"
#include "semantic.cpp"
#include <iostream>
#include <vector>

Scope scope = Scope();
int tempCount = 0;
ExpressionSolver es;
ParamSolver ps = ParamSolver("global");
ExpressionSolver pes;
Quad quads = Quad();
VarTable::symbolRow * var = NULL;

#line 61 "parser.tab.cc"


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

// Whether we are compiled with exception support.
#ifndef YY_EXCEPTIONS
# if defined __GNUC__ && !defined __EXCEPTIONS
#  define YY_EXCEPTIONS 0
# else
#  define YY_EXCEPTIONS 1
# endif
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K].location)
/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

# ifndef YYLLOC_DEFAULT
#  define YYLLOC_DEFAULT(Current, Rhs, N)                               \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).begin  = YYRHSLOC (Rhs, 1).begin;                   \
          (Current).end    = YYRHSLOC (Rhs, N).end;                     \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).begin = (Current).end = YYRHSLOC (Rhs, 0).end;      \
        }                                                               \
    while (false)
# endif


// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << '\n';                       \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yystack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YYUSE (Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void> (0)
# define YY_STACK_PRINT()                static_cast<void> (0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)

#line 6 "parser.yy"
namespace yy {
#line 153 "parser.tab.cc"


  /* Return YYSTR after stripping away unnecessary quotes and
     backslashes, so that it's suitable for yyerror.  The heuristic is
     that double-quoting is unnecessary unless the string contains an
     apostrophe, a comma, or backslash (other than backslash-backslash).
     YYSTR is taken from yytname.  */
  std::string
  parser::yytnamerr_ (const char *yystr)
  {
    if (*yystr == '"')
      {
        std::string yyr;
        char const *yyp = yystr;

        for (;;)
          switch (*++yyp)
            {
            case '\'':
            case ',':
              goto do_not_strip_quotes;

            case '\\':
              if (*++yyp != '\\')
                goto do_not_strip_quotes;
              else
                goto append;

            append:
            default:
              yyr += *yyp;
              break;

            case '"':
              return yyr;
            }
      do_not_strip_quotes: ;
      }

    return yystr;
  }


  /// Build a parser object.
  parser::parser (parser_driver& driver_yyarg)
#if YYDEBUG
    : yydebug_ (false),
      yycdebug_ (&std::cerr),
#else
    :
#endif
      driver (driver_yyarg)
  {}

  parser::~parser ()
  {}

  parser::syntax_error::~syntax_error () YY_NOEXCEPT YY_NOTHROW
  {}

  /*---------------.
  | Symbol types.  |
  `---------------*/



  // by_state.
  parser::by_state::by_state () YY_NOEXCEPT
    : state (empty_state)
  {}

  parser::by_state::by_state (const by_state& that) YY_NOEXCEPT
    : state (that.state)
  {}

  void
  parser::by_state::clear () YY_NOEXCEPT
  {
    state = empty_state;
  }

  void
  parser::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  parser::by_state::by_state (state_type s) YY_NOEXCEPT
    : state (s)
  {}

  parser::symbol_number_type
  parser::by_state::type_get () const YY_NOEXCEPT
  {
    if (state == empty_state)
      return empty_symbol;
    else
      return yystos_[+state];
  }

  parser::stack_symbol_type::stack_symbol_type ()
  {}

  parser::stack_symbol_type::stack_symbol_type (YY_RVREF (stack_symbol_type) that)
    : super_type (YY_MOVE (that.state), YY_MOVE (that.location))
  {
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.YY_MOVE_OR_COPY< char > (YY_MOVE (that.value));
        break;

      case 55: // INT
      case 56: // FLOAT
        value.YY_MOVE_OR_COPY< float > (YY_MOVE (that.value));
        break;

      case 52: // ID
      case 53: // STRING
        value.YY_MOVE_OR_COPY< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

#if 201103L <= YY_CPLUSPLUS
    // that is emptied.
    that.state = empty_state;
#endif
  }

  parser::stack_symbol_type::stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) that)
    : super_type (s, YY_MOVE (that.location))
  {
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.move< char > (YY_MOVE (that.value));
        break;

      case 55: // INT
      case 56: // FLOAT
        value.move< float > (YY_MOVE (that.value));
        break;

      case 52: // ID
      case 53: // STRING
        value.move< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

    // that is emptied.
    that.type = empty_symbol;
  }

#if YY_CPLUSPLUS < 201103L
  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.copy< char > (that.value);
        break;

      case 55: // INT
      case 56: // FLOAT
        value.copy< float > (that.value);
        break;

      case 52: // ID
      case 53: // STRING
        value.copy< std::string > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    return *this;
  }

  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (stack_symbol_type& that)
  {
    state = that.state;
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.move< char > (that.value);
        break;

      case 55: // INT
      case 56: // FLOAT
        value.move< float > (that.value);
        break;

      case 52: // ID
      case 53: // STRING
        value.move< std::string > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    // that is emptied.
    that.state = empty_state;
    return *this;
  }
#endif

  template <typename Base>
  void
  parser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);
  }

#if YYDEBUG
  template <typename Base>
  void
  parser::yy_print_ (std::ostream& yyo,
                                     const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YYUSE (yyoutput);
    symbol_number_type yytype = yysym.type_get ();
#if defined __GNUC__ && ! defined __clang__ && ! defined __ICC && __GNUC__ * 100 + __GNUC_MINOR__ <= 408
    // Avoid a (spurious) G++ 4.8 warning about "array subscript is
    // below array bounds".
    if (yysym.empty ())
      std::abort ();
#endif
    yyo << (yytype < yyntokens_ ? "token" : "nterm")
        << ' ' << yytname_[yytype] << " ("
        << yysym.location << ": ";
    switch (yytype)
    {
      case 52: // ID
#line 133 "parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 405 "parser.tab.cc"
        break;

      case 53: // STRING
#line 133 "parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 411 "parser.tab.cc"
        break;

      case 54: // CHAR
#line 133 "parser.yy"
                 { yyoutput << yysym.value.template as < char > (); }
#line 417 "parser.tab.cc"
        break;

      case 55: // INT
#line 133 "parser.yy"
                 { yyoutput << yysym.value.template as < float > (); }
#line 423 "parser.tab.cc"
        break;

      case 56: // FLOAT
#line 133 "parser.yy"
                 { yyoutput << yysym.value.template as < float > (); }
#line 429 "parser.tab.cc"
        break;

      default:
        break;
    }
    yyo << ')';
  }
#endif

  void
  parser::yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym)
  {
    if (m)
      YY_SYMBOL_PRINT (m, sym);
    yystack_.push (YY_MOVE (sym));
  }

  void
  parser::yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym)
  {
#if 201103L <= YY_CPLUSPLUS
    yypush_ (m, stack_symbol_type (s, std::move (sym)));
#else
    stack_symbol_type ss (s, sym);
    yypush_ (m, ss);
#endif
  }

  void
  parser::yypop_ (int n)
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  parser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  parser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  parser::debug_level_type
  parser::debug_level () const
  {
    return yydebug_;
  }

  void
  parser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  parser::state_type
  parser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - yyntokens_] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - yyntokens_];
  }

  bool
  parser::yy_pact_value_is_default_ (int yyvalue)
  {
    return yyvalue == yypact_ninf_;
  }

  bool
  parser::yy_table_value_is_error_ (int yyvalue)
  {
    return yyvalue == yytable_ninf_;
  }

  int
  parser::operator() ()
  {
    return parse ();
  }

  int
  parser::parse ()
  {
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The locations where the error started and ended.
    stack_symbol_type yyerror_range[3];

    /// The return value of parse ().
    int yyresult;

#if YY_EXCEPTIONS
    try
#endif // YY_EXCEPTIONS
      {
    YYCDEBUG << "Starting parse\n";


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, YY_MOVE (yyla));

  /*-----------------------------------------------.
  | yynewstate -- push a new symbol on the stack.  |
  `-----------------------------------------------*/
  yynewstate:
    YYCDEBUG << "Entering state " << int (yystack_[0].state) << '\n';

    // Accept?
    if (yystack_[0].state == yyfinal_)
      YYACCEPT;

    goto yybackup;


  /*-----------.
  | yybackup.  |
  `-----------*/
  yybackup:
    // Try to take a decision without lookahead.
    yyn = yypact_[+yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token: ";
#if YY_EXCEPTIONS
        try
#endif // YY_EXCEPTIONS
          {
            symbol_type yylookahead (yylex (driver));
            yyla.move (yylookahead);
          }
#if YY_EXCEPTIONS
        catch (const syntax_error& yyexc)
          {
            YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
            error (yyexc);
            goto yyerrlab1;
          }
#endif // YY_EXCEPTIONS
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.type_get ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.type_get ())
      {
        goto yydefault;
      }

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", state_type (yyn), YY_MOVE (yyla));
    goto yynewstate;


  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[+yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;


  /*-----------------------------.
  | yyreduce -- do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_ (yystack_[yylen].state, yyr1_[yyn]);
      /* Variants are always initialized to an empty instance of the
         correct type. The default '$$ = $1' action is NOT applied
         when using variants.  */
      switch (yyr1_[yyn])
    {
      case 54: // CHAR
        yylhs.value.emplace< char > ();
        break;

      case 55: // INT
      case 56: // FLOAT
        yylhs.value.emplace< float > ();
        break;

      case 52: // ID
      case 53: // STRING
        yylhs.value.emplace< std::string > ();
        break;

      default:
        break;
    }


      // Default location.
      {
        stack_type::slice range (yystack_, yylen);
        YYLLOC_DEFAULT (yylhs.location, range, yylen);
        yyerror_range[1].location = yylhs.location;
      }

      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
#if YY_EXCEPTIONS
      try
#endif // YY_EXCEPTIONS
        {
          switch (yyn)
            {
  case 4:
#line 144 "parser.yy"
                      {quads.prepareMainQuad();}
#line 684 "parser.tab.cc"
    break;

  case 5:
#line 144 "parser.yy"
                                                             {globalFlag = 1;}
#line 690 "parser.tab.cc"
    break;

  case 7:
#line 148 "parser.yy"
                 {setID(yystack_[0].value.as < std::string > ());}
#line 696 "parser.tab.cc"
    break;

  case 9:
#line 149 "parser.yy"
                          {setID(yystack_[0].value.as < std::string > ());}
#line 702 "parser.tab.cc"
    break;

  case 16:
#line 155 "parser.yy"
                          {setID(yystack_[0].value.as < std::string > ());}
#line 708 "parser.tab.cc"
    break;

  case 18:
#line 156 "parser.yy"
                          {setID(yystack_[0].value.as < std::string > ());}
#line 714 "parser.tab.cc"
    break;

  case 23:
#line 168 "parser.yy"
                     {
        if(paramsFlag){
                pes.installPar();
        }else{
                if(expressionFlag){
                        es.installPar();
                }
        }
        }
#line 728 "parser.tab.cc"
    break;

  case 24:
#line 176 "parser.yy"
                          {
                if(paramsFlag){
                        pes.installPar();
                }else{
                        if(expressionFlag){
                                es.closePar();
                        }
                }
        }
#line 742 "parser.tab.cc"
    break;

  case 25:
#line 187 "parser.yy"
                    {
        if(paramsFlag){
                pes = ExpressionSolver();
        }
}
#line 752 "parser.tab.cc"
    break;

  case 26:
#line 191 "parser.yy"
             {
        if(paramsFlag){
                quads.importSolver(pes); 
                int single = pes.singleVar();
                if(single){
                        cout<<"Direction -> " << single << endl;
                        int paramNum = ps.insertParam(single);
                        quads.insertQuad(203,single,-1,paramNum);
                }else{
                        cout<<"Direction -> " << quads.getLastQuad().result << endl;
                        int paramNum = ps.insertParam(quads.getLastQuad().result);
                        quads.insertQuad(203,quads.getLastQuad().result,-1,paramNum);
                }
        }
}
#line 772 "parser.tab.cc"
    break;

  case 28:
#line 206 "parser.yy"
                       {
        if(paramsFlag){
                pes = ExpressionSolver();
        }
}
#line 782 "parser.tab.cc"
    break;

  case 29:
#line 210 "parser.yy"
             {
        if(paramsFlag){
                quads.importSolver(pes);
                int single = pes.singleVar();
                if(single){
                        cout<<"Direction -> " << single << endl;
                        int paramNum = ps.insertParam(single);
                        quads.insertQuad(203,single,-1,paramNum);
                }else{
                        cout<<"Direction -> " << quads.getLastQuad().result << endl;
                        int paramNum = ps.insertParam(quads.getLastQuad().result);
                        quads.insertQuad(203,quads.getLastQuad().result,-1,paramNum);
                }
        }
}
#line 802 "parser.tab.cc"
    break;

  case 32:
#line 230 "parser.yy"
                   {cout << "Clase id : " << yystack_[0].value.as < std::string > () << endl;}
#line 808 "parser.tab.cc"
    break;

  case 35:
#line 234 "parser.yy"
                                   {
        setCurrentFunction(yystack_[0].value.as < std::string > ());
        scope.globalInsertFunction(yystack_[0].value.as < std::string > (),currentType,"function",quads.getQuadLastDir());
        scope.setFunctionScope(yystack_[0].value.as < std::string > ());
        scope.installFunctionVars(yystack_[0].value.as < std::string > ());
        resetCurrentType();
        globalFlag = 0;
}
#line 821 "parser.tab.cc"
    break;

  case 36:
#line 241 "parser.yy"
                                                         {
        resetCurrentFunction();
        quads.insertQuad(299,-1,-1,-1);
}
#line 830 "parser.tab.cc"
    break;

  case 39:
#line 248 "parser.yy"
            {
        quads.setMainQuad();
        scope.setFunctionScope("global");
}
#line 839 "parser.tab.cc"
    break;

  case 40:
#line 251 "parser.yy"
                               {quads.insertQuad(999,-1,-1,-1);quads.printQuadList();}
#line 845 "parser.tab.cc"
    break;

  case 43:
#line 259 "parser.yy"
                        {cout << "Herencia id : " << yystack_[0].value.as < std::string > () << endl;}
#line 851 "parser.tab.cc"
    break;

  case 47:
#line 269 "parser.yy"
{       
        if(globalFlag){
                for(auto var : currentIds){
                        scope.insertGlobalVariable(var,currentType);
                }
        }else{
                for(auto var : currentIds){
                        scope.insertVarOnScope(var,currentType);
                } 
        }
        resetID();
        resetCurrentType();
}
#line 869 "parser.tab.cc"
    break;

  case 56:
#line 301 "parser.yy"
                       {setCurrentType(0);}
#line 875 "parser.tab.cc"
    break;

  case 57:
#line 302 "parser.yy"
                          {setCurrentType(1);}
#line 881 "parser.tab.cc"
    break;

  case 58:
#line 303 "parser.yy"
                         {setCurrentType(2);}
#line 887 "parser.tab.cc"
    break;

  case 60:
#line 306 "parser.yy"
                               {setCurrentType(10);}
#line 893 "parser.tab.cc"
    break;

  case 62:
#line 309 "parser.yy"
                                    {setCurrentType(20);}
#line 899 "parser.tab.cc"
    break;

  case 63:
#line 312 "parser.yy"
              {
        if(paramsFlag){
                pes.insertOprnd(yystack_[0].value.as < std::string > ());
        }else{
                if(expressionFlag){
                        es.insertOprnd(yystack_[0].value.as < std::string > ());
                }else{
                        var = scope.getVarOnScope(yystack_[0].value.as < std::string > ());
                        if(var == NULL)
                                var = scope.getGlobalVariable(yystack_[0].value.as < std::string > ());
                }
        }
}
#line 917 "parser.tab.cc"
    break;

  case 70:
#line 333 "parser.yy"
                {setID(yystack_[0].value.as < std::string > ());}
#line 923 "parser.tab.cc"
    break;

  case 71:
#line 334 "parser.yy"
{
        scope.insertParameterOnScope(yystack_[4].value.as < std::string > (),currentType);
        resetCurrentType();
        resetID();
}
#line 933 "parser.tab.cc"
    break;

  case 86:
#line 360 "parser.yy"
{
        es = ExpressionSolver();
        expressionFlag = 1;
        es.insertOprnd(var->name);
        es.insertOptr(5);
}
#line 944 "parser.tab.cc"
    break;

  case 87:
#line 367 "parser.yy"
{
        es.assign();
        quads.importSolver(es); 
        expressionFlag = 0;
        //int id = var->dir;
        //quads.insertQuad(101,quads.getLastQuad().result,-1,id);
}
#line 956 "parser.tab.cc"
    break;

  case 89:
#line 379 "parser.yy"
               {
        ps = ParamSolver(yystack_[0].value.as < std::string > ());
        paramsFlag = 1;
        quads.insertQuad(202,ps.getFunctionQuadDir(),-1,-1);
}
#line 966 "parser.tab.cc"
    break;

  case 90:
#line 383 "parser.yy"
                    {ps.checkParams(); paramsFlag = 0; quads.insertQuad(204,ps.getFunctionQuadDir(),-1,-1);}
#line 972 "parser.tab.cc"
    break;

  case 91:
#line 386 "parser.yy"
                          {
        es = ExpressionSolver();
        expressionFlag = 1;
}
#line 981 "parser.tab.cc"
    break;

  case 92:
#line 389 "parser.yy"
                  {
        quads.importSolver(es); 
        expressionFlag = 0;
        int single = es.singleVar();
        if(single){
                es.checkVarType(single);
                quads.insertQuad(298,single,-1,-1);
        }else{
                es.checkVarType(quads.getLastQuad().result);
                quads.insertQuad(298,quads.getLastQuad().result,-1,-1);
        }
}
#line 998 "parser.tab.cc"
    break;

  case 93:
#line 403 "parser.yy"
                                    { quads.insertQuad(103,-1,-1,var->dir);}
#line 1004 "parser.tab.cc"
    break;

  case 94:
#line 406 "parser.yy"
                      { es = ExpressionSolver(); expressionFlag = 1;}
#line 1010 "parser.tab.cc"
    break;

  case 96:
#line 407 "parser.yy"
                              {cout << "Constante string : " << yystack_[0].value.as < std::string > () << endl;}
#line 1016 "parser.tab.cc"
    break;

  case 97:
#line 408 "parser.yy"
                             {
                        quads.importSolver(es); 
                        expressionFlag = 0;
                        int single = es.singleVar();
                        if(single){
                                quads.insertQuad(102,single,-1,-1);
                        }else{
                                quads.insertQuad(102,quads.getLastQuad().result,-1,-1);
                        }
                }
#line 1031 "parser.tab.cc"
    break;

  case 98:
#line 418 "parser.yy"
                                  {
                        quads.importSolver(es); 
                        expressionFlag = 0;
                        int single = es.singleVar();
                        if(single){
                                quads.insertQuad(102,single,-1,-1);
                        }else{
                                quads.insertQuad(102,quads.getLastQuad().result,-1,-1);
                        }
                        es = ExpressionSolver(); 
                        expressionFlag = 1;
                }
#line 1048 "parser.tab.cc"
    break;

  case 100:
#line 430 "parser.yy"
                         {cout << "Constante string : " << yystack_[0].value.as < std::string > () << endl;}
#line 1054 "parser.tab.cc"
    break;

  case 102:
#line 433 "parser.yy"
                             {es = ExpressionSolver(); expressionFlag = 1;}
#line 1060 "parser.tab.cc"
    break;

  case 103:
#line 433 "parser.yy"
                                                                                            {
        quads.importSolver(es); 
        expressionFlag = 0;
        int single = es.singleVar();
        setJDir(quads.getQuadLastDir());
        if(single){
                quads.insertQuad(201,single,-1,-1);
        }else{
                quads.insertQuad(201,quads.getLastQuad().result,-1,-1);
        }
}
#line 1076 "parser.tab.cc"
    break;

  case 105:
#line 445 "parser.yy"
                { 
                int dir = getJDir();
                quads.updateQuadResult(dir,quads.getQuadLastDir()); 
                setJDir(quads.getQuadLastDir());
                quads.insertQuad(200,-1,-1,-1);
        }
#line 1087 "parser.tab.cc"
    break;

  case 106:
#line 450 "parser.yy"
                             {
                int dir = getJDir();
                quads.updateQuadResult(dir,quads.getQuadLastDir());
        }
#line 1096 "parser.tab.cc"
    break;

  case 107:
#line 454 "parser.yy"
                {
                int dir = getJDir();
                quads.updateQuadResult(dir,quads.getQuadLastDir()); 
        }
#line 1105 "parser.tab.cc"
    break;

  case 117:
#line 472 "parser.yy"
           {if(paramsFlag){pes.insertOptr(6);}else{ if(expressionFlag){es.insertOptr(6);}}}
#line 1111 "parser.tab.cc"
    break;

  case 118:
#line 473 "parser.yy"
           {if(paramsFlag){pes.insertOptr(7);}else{ if(expressionFlag){es.insertOptr(7);}}}
#line 1117 "parser.tab.cc"
    break;

  case 119:
#line 474 "parser.yy"
           {if(paramsFlag){pes.insertOptr(10);}else{ if(expressionFlag){es.insertOptr(10);}}}
#line 1123 "parser.tab.cc"
    break;

  case 120:
#line 475 "parser.yy"
           {if(paramsFlag){pes.insertOptr(11);}else{ if(expressionFlag){es.insertOptr(11);}}}
#line 1129 "parser.tab.cc"
    break;

  case 121:
#line 476 "parser.yy"
           {if(paramsFlag){pes.insertOptr(8);}else{ if(expressionFlag){es.insertOptr(8);}}}
#line 1135 "parser.tab.cc"
    break;

  case 122:
#line 477 "parser.yy"
           {if(paramsFlag){pes.insertOptr(9);}else{ if(expressionFlag){es.insertOptr(9);}}}
#line 1141 "parser.tab.cc"
    break;

  case 123:
#line 478 "parser.yy"
                   {if(paramsFlag){pes.insertOptr(12);}else{ if(expressionFlag){es.insertOptr(12);}}}
#line 1147 "parser.tab.cc"
    break;

  case 125:
#line 479 "parser.yy"
                  {if(paramsFlag){pes.insertOptr(13);}else{ if(expressionFlag){es.insertOptr(13);}}}
#line 1153 "parser.tab.cc"
    break;

  case 128:
#line 483 "parser.yy"
           {if(paramsFlag){pes.checkStacks();}else{ if(expressionFlag){es.checkStacks();}}}
#line 1159 "parser.tab.cc"
    break;

  case 130:
#line 484 "parser.yy"
               {if(paramsFlag){pes.insertOptr(0);}else{ if(expressionFlag){es.insertOptr(0);}}}
#line 1165 "parser.tab.cc"
    break;

  case 132:
#line 485 "parser.yy"
               {if(paramsFlag){pes.insertOptr(1);}else{ if(expressionFlag){es.insertOptr(1);}}}
#line 1171 "parser.tab.cc"
    break;

  case 135:
#line 489 "parser.yy"
              {if(paramsFlag){pes.checkStacks();}else{if(expressionFlag){es.checkStacks();}}}
#line 1177 "parser.tab.cc"
    break;

  case 137:
#line 490 "parser.yy"
                {if(paramsFlag){pes.insertOptr(2);}else{if(expressionFlag){es.insertOptr(2);}}}
#line 1183 "parser.tab.cc"
    break;

  case 139:
#line 491 "parser.yy"
                {if(paramsFlag){pes.insertOptr(3);}else{if(expressionFlag){es.insertOptr(3);}}}
#line 1189 "parser.tab.cc"
    break;

  case 141:
#line 492 "parser.yy"
                {if(paramsFlag){pes.insertOptr(4);}else{if(expressionFlag){es.insertOptr(4);}}}
#line 1195 "parser.tab.cc"
    break;

  case 152:
#line 506 "parser.yy"
              {if(paramsFlag){pes.insertOprnd((int)yystack_[0].value.as < float > ());}else{ if(expressionFlag){es.insertOprnd((int)yystack_[0].value.as < float > ());}}}
#line 1201 "parser.tab.cc"
    break;

  case 153:
#line 507 "parser.yy"
                {if(paramsFlag){pes.insertOprnd((float)yystack_[0].value.as < float > ());}else{ if(expressionFlag){es.insertOprnd((float)yystack_[0].value.as < float > ());}}}
#line 1207 "parser.tab.cc"
    break;

  case 154:
#line 508 "parser.yy"
                {if(paramsFlag){pes.insertOprnd((char)yystack_[0].value.as < char > ());}else{ if(expressionFlag){es.insertOprnd((char)yystack_[0].value.as < char > ());}}}
#line 1213 "parser.tab.cc"
    break;

  case 155:
#line 511 "parser.yy"
                            {es = ExpressionSolver(); expressionFlag = 1;}
#line 1219 "parser.tab.cc"
    break;

  case 156:
#line 511 "parser.yy"
                                                                                           {
        setJDir(quads.getQuadLastDir());
        quads.importSolver(es); 
        expressionFlag = 0;
        int single = es.singleVar();
        setJDir(quads.getQuadLastDir());
        if(single){
                quads.insertQuad(201,single,-1,-1);
        }else{
                quads.insertQuad(201,quads.getLastQuad().result,-1,-1);
        }
}
#line 1236 "parser.tab.cc"
    break;

  case 157:
#line 522 "parser.yy"
                          {
        int dir = getJDir();
        int exp = getJDir();
        quads.insertQuad(200,-1,-1,exp);
        quads.updateQuadResult(dir,quads.getQuadLastDir());
}
#line 1247 "parser.tab.cc"
    break;

  case 158:
#line 530 "parser.yy"
                                      {
        es = ExpressionSolver(); 
        expressionFlag = 1;
        setforID(var->name);
        es.insertOprnd(var->name);
        es.insertOptr(5);
}
#line 1259 "parser.tab.cc"
    break;

  case 159:
#line 536 "parser.yy"
      {
        es.assign();
        quads.importSolver(es); 
        expressionFlag = 0;

        string assign = var->name;
        es = ExpressionSolver(); 
        expressionFlag = 1;
        es.insertOprnd(assign);
}
#line 1274 "parser.tab.cc"
    break;

  case 160:
#line 545 "parser.yy"
     { es.insertOptr(9);}
#line 1280 "parser.tab.cc"
    break;

  case 161:
#line 545 "parser.yy"
                              {
        quads.importSolver(es); 
        expressionFlag = 0; 
        int lastDir = quads.getQuadLastDir();
        setJDir(lastDir);
        quads.insertQuad(201,quads.getLastQuad().result,-1,-1);
}
#line 1292 "parser.tab.cc"
    break;

  case 162:
#line 551 "parser.yy"
                          {
        string fid = getforID();
        es = ExpressionSolver(); 
        expressionFlag = 1;
        es.insertOprnd(fid);
        es.insertOptr(5);
        es.insertOprnd(fid);
        es.insertOptr(0);
        es.insertOprnd(1);
        es.assign();
        quads.importSolver(es); 
        expressionFlag = 0;

        int dir = getJDir();
        quads.insertQuad(200,-1,-1,dir-1);
        quads.updateQuadResult(dir,quads.getQuadLastDir());
}
#line 1314 "parser.tab.cc"
    break;


#line 1318 "parser.tab.cc"

            default:
              break;
            }
        }
#if YY_EXCEPTIONS
      catch (const syntax_error& yyexc)
        {
          YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
          error (yyexc);
          YYERROR;
        }
#endif // YY_EXCEPTIONS
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;
      YY_STACK_PRINT ();

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, YY_MOVE (yylhs));
    }
    goto yynewstate;


  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        error (yyla.location, yysyntax_error_ (yystack_[0].state, yyla));
      }


    yyerror_range[1].location = yyla.location;
    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.type_get () == yyeof_)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:
    /* Pacify compilers when the user code never invokes YYERROR and
       the label yyerrorlab therefore never appears in user code.  */
    if (false)
      YYERROR;

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    goto yyerrlab1;


  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    {
      stack_symbol_type error_token;
      for (;;)
        {
          yyn = yypact_[+yystack_[0].state];
          if (!yy_pact_value_is_default_ (yyn))
            {
              yyn += yy_error_token_;
              if (0 <= yyn && yyn <= yylast_ && yycheck_[yyn] == yy_error_token_)
                {
                  yyn = yytable_[yyn];
                  if (0 < yyn)
                    break;
                }
            }

          // Pop the current state because it cannot handle the error token.
          if (yystack_.size () == 1)
            YYABORT;

          yyerror_range[1].location = yystack_[0].location;
          yy_destroy_ ("Error: popping", yystack_[0]);
          yypop_ ();
          YY_STACK_PRINT ();
        }

      yyerror_range[2].location = yyla.location;
      YYLLOC_DEFAULT (error_token.location, yyerror_range, 2);

      // Shift the error token.
      error_token.state = state_type (yyn);
      yypush_ ("Shifting", YY_MOVE (error_token));
    }
    goto yynewstate;


  /*-------------------------------------.
  | yyacceptlab -- YYACCEPT comes here.  |
  `-------------------------------------*/
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;


  /*-----------------------------------.
  | yyabortlab -- YYABORT comes here.  |
  `-----------------------------------*/
  yyabortlab:
    yyresult = 1;
    goto yyreturn;


  /*-----------------------------------------------------.
  | yyreturn -- parsing is finished, return the result.  |
  `-----------------------------------------------------*/
  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
#if YY_EXCEPTIONS
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack\n";
        // Do not try to display the values of the reclaimed symbols,
        // as their printers might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
#endif // YY_EXCEPTIONS
  }

  void
  parser::error (const syntax_error& yyexc)
  {
    error (yyexc.location, yyexc.what ());
  }

  // Generate an error message.
  std::string
  parser::yysyntax_error_ (state_type yystate, const symbol_type& yyla) const
  {
    // Number of reported tokens (one for the "unexpected", one per
    // "expected").
    std::ptrdiff_t yycount = 0;
    // Its maximum.
    enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
    // Arguments of yyformat.
    char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];

    /* There are many possibilities here to consider:
       - If this state is a consistent state with a default action, then
         the only way this function was invoked is if the default action
         is an error action.  In that case, don't check for expected
         tokens because there are none.
       - The only way there can be no lookahead present (in yyla) is
         if this state is a consistent state with a default action.
         Thus, detecting the absence of a lookahead is sufficient to
         determine that there is no unexpected or expected token to
         report.  In that case, just report a simple "syntax error".
       - Don't assume there isn't a lookahead just because this state is
         a consistent state with a default action.  There might have
         been a previous inconsistent state, consistent state with a
         non-default action, or user semantic action that manipulated
         yyla.  (However, yyla is currently not documented for users.)
       - Of course, the expected token list depends on states to have
         correct lookahead information, and it depends on the parser not
         to perform extra reductions after fetching a lookahead from the
         scanner and before detecting a syntax error.  Thus, state merging
         (from LALR or IELR) and default reductions corrupt the expected
         token list.  However, the list is correct for canonical LR with
         one exception: it will still contain any token that will not be
         accepted due to an error action in a later state.
    */
    if (!yyla.empty ())
      {
        symbol_number_type yytoken = yyla.type_get ();
        yyarg[yycount++] = yytname_[yytoken];

        int yyn = yypact_[+yystate];
        if (!yy_pact_value_is_default_ (yyn))
          {
            /* Start YYX at -YYN if negative to avoid negative indexes in
               YYCHECK.  In other words, skip the first -YYN actions for
               this state because they are default actions.  */
            int yyxbegin = yyn < 0 ? -yyn : 0;
            // Stay within bounds of both yycheck and yytname.
            int yychecklim = yylast_ - yyn + 1;
            int yyxend = yychecklim < yyntokens_ ? yychecklim : yyntokens_;
            for (int yyx = yyxbegin; yyx < yyxend; ++yyx)
              if (yycheck_[yyx + yyn] == yyx && yyx != yy_error_token_
                  && !yy_table_value_is_error_ (yytable_[yyx + yyn]))
                {
                  if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                    {
                      yycount = 1;
                      break;
                    }
                  else
                    yyarg[yycount++] = yytname_[yyx];
                }
          }
      }

    char const* yyformat = YY_NULLPTR;
    switch (yycount)
      {
#define YYCASE_(N, S)                         \
        case N:                               \
          yyformat = S;                       \
        break
      default: // Avoid compiler warnings.
        YYCASE_ (0, YY_("syntax error"));
        YYCASE_ (1, YY_("syntax error, unexpected %s"));
        YYCASE_ (2, YY_("syntax error, unexpected %s, expecting %s"));
        YYCASE_ (3, YY_("syntax error, unexpected %s, expecting %s or %s"));
        YYCASE_ (4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
        YYCASE_ (5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
      }

    std::string yyres;
    // Argument number.
    std::ptrdiff_t yyi = 0;
    for (char const* yyp = yyformat; *yyp; ++yyp)
      if (yyp[0] == '%' && yyp[1] == 's' && yyi < yycount)
        {
          yyres += yytnamerr_ (yyarg[yyi++]);
          ++yyp;
        }
      else
        yyres += *yyp;
    return yyres;
  }


  const short parser::yypact_ninf_ = -166;

  const signed char parser::yytable_ninf_ = -101;

  const short
  parser::yypact_[] =
  {
      -4,    10,    77,  -166,  -166,  -166,    81,    62,    50,  -166,
    -166,  -166,    72,    68,    53,  -166,    32,    54,  -166,    97,
    -166,   101,  -166,  -166,  -166,  -166,  -166,  -166,    78,  -166,
      73,  -166,    79,    51,  -166,  -166,  -166,    66,    53,  -166,
      80,    67,     9,    21,  -166,  -166,  -166,    63,    53,   102,
    -166,   113,  -166,    32,  -166,   110,  -166,  -166,  -166,  -166,
    -166,  -166,  -166,  -166,  -166,   116,  -166,  -166,    12,    76,
     -20,  -166,  -166,  -166,  -166,   108,   115,    53,  -166,   117,
      51,    21,    21,  -166,   119,    25,    29,    23,  -166,  -166,
    -166,  -166,  -166,  -166,  -166,   118,  -166,   123,    82,  -166,
    -166,  -166,    62,  -166,   120,    64,  -166,  -166,  -166,  -166,
    -166,  -166,  -166,  -166,  -166,  -166,  -166,    84,  -166,   132,
      22,  -166,    63,   135,    -9,  -166,  -166,   129,  -166,  -166,
    -166,  -166,  -166,  -166,  -166,  -166,    21,    21,    21,    21,
      21,    21,    23,  -166,    21,    84,  -166,  -166,    96,  -166,
     144,  -166,  -166,  -166,  -166,   136,   137,   138,   139,    96,
     140,  -166,   133,   145,    -9,    -9,    -9,    -9,    -9,    -9,
      -9,  -166,  -166,   135,    72,    71,  -166,  -166,  -166,  -166,
    -166,  -166,  -166,  -166,  -166,    96,  -166,  -166,    21,    96,
    -166,  -166,  -166,   142,   155,  -166,  -166,  -166,  -166,  -166,
    -166,  -166,  -166,  -166,  -166,  -166,   162,   161,  -166,  -166,
    -166,  -166,   166,  -166,   167,   158,    -3,    21,    21,  -166,
     168,    21,     9,    -9,    21,    21,  -166,  -166,   163,  -166,
     169,   171,   164,   174,   170,   172,    21,  -166,   175,  -166,
    -166,   177,  -166,  -166,    21,  -166,  -166,   180,   176,  -166,
    -166,  -166,  -166,  -166,   183,   184,  -166,    -3,  -166,    -3,
     130,   143,   141,    82,  -166,  -166,  -166,   166,  -166,  -166,
     182,   185,  -166,  -166,    32,  -166,    -9,    -9,    21,  -166,
     186,   187,  -166,   148,  -166,   149,  -166,  -166,  -166,   190,
     191,    -9,    -9,   192,   193,  -166,  -166
  };

  const unsigned char
  parser::yydefact_[] =
  {
       0,     0,     0,     2,     4,     1,     0,     3,     0,    34,
       5,    32,     3,     3,     0,    46,     3,     0,    44,     0,
       7,     0,    45,    62,    56,    57,    58,    38,     0,    61,
       0,    43,     3,     0,    47,    39,     6,     0,     0,    52,
       3,     0,     0,     3,     8,    11,    12,     0,     3,     0,
      35,     0,    51,     3,    42,     0,     9,    60,    59,    13,
      23,   146,   147,   148,   144,     3,   128,   135,     0,     0,
       0,    14,    50,    49,    48,     0,     0,     3,    41,     0,
       0,     3,     3,    22,     0,     3,     3,    63,   154,   152,
     153,   151,   150,   145,   149,    16,    15,     0,     3,    55,
      54,    53,     3,    10,     0,   116,    21,    20,   130,   132,
     134,   129,   137,   139,   141,   143,   136,     0,    25,     3,
       3,   110,     0,     0,     3,    70,    73,     0,    33,    24,
     117,   119,   120,   121,   122,   118,     3,     3,     3,     3,
       3,     3,     0,   111,     3,     0,   114,   112,     0,    67,
       3,    64,    17,    19,    91,     0,     0,     0,     0,     0,
      63,    85,     0,     0,     3,     3,     3,     3,     3,     3,
       3,   108,   109,     3,     3,     3,   131,   133,   138,   140,
     142,    26,   113,    63,    65,     0,    69,    66,     3,     0,
      94,   102,   155,     0,     0,    86,    40,    78,    79,    80,
      81,    82,    83,    84,    77,    76,     0,     0,   123,   125,
     127,   115,     3,    68,     0,     0,     3,     3,     3,   158,
       0,     3,     0,     3,     3,     3,    28,    31,     0,    92,
       0,    96,     0,    97,     0,     0,     3,    90,     0,    88,
      71,     0,   124,   126,     3,    27,    93,     0,     0,    98,
     103,   156,   159,    87,     3,     0,    29,     3,    95,     3,
       0,     0,     0,     3,    75,    72,    36,     3,   101,    99,
       0,     0,   160,    74,     3,    30,     3,     3,     3,    37,
       0,     0,   161,     3,   157,     0,   105,   107,   104,     0,
       0,     3,     3,     0,     0,   162,   106
  };

  const short
  parser::yypgoto_[] =
  {
    -166,  -166,    -7,  -166,  -166,  -166,   -30,  -166,   122,  -166,
    -166,    83,    85,  -166,  -166,  -113,  -166,  -166,  -166,    14,
    -166,  -166,   -57,  -166,  -166,   107,  -166,   -52,  -166,  -166,
    -166,  -166,  -166,  -166,    37,   165,  -166,  -166,  -166,   146,
    -166,   -38,   -10,  -166,   -58,  -166,  -166,  -166,   -49,  -166,
    -166,  -166,  -166,  -151,  -166,  -166,  -166,  -166,  -166,  -166,
    -166,  -166,  -166,  -166,  -165,  -166,  -166,  -166,  -166,  -166,
    -166,  -166,  -166,  -105,  -166,  -166,   -79,  -166,  -166,  -166,
    -166,   -40,  -166,  -166,  -166,  -166,   -53,  -166,  -166,  -166,
    -166,  -166,  -166,  -166,  -166,  -166,  -166,  -166,  -166,  -166,
    -166,  -166,  -166,  -166
  };

  const short
  parser::yydefgoto_[] =
  {
      -1,     2,    63,     3,     6,    12,    21,    33,    44,    80,
      45,    46,    71,   122,   123,    47,    84,    64,    81,   119,
     144,   212,   228,   244,   267,    10,    13,    28,    76,   274,
      36,    49,    55,    19,    16,    22,    48,    74,    40,    52,
     101,    29,    59,    30,   162,   120,   151,   187,   127,   173,
     254,   265,   206,   163,   164,   221,   238,   165,   194,   166,
     188,   167,   168,   216,   232,   259,   247,   169,   217,   260,
     288,   290,   170,    92,   121,   147,   233,   136,   211,   224,
     225,   105,    85,   111,   137,   138,    66,    86,   116,   139,
     140,   141,    67,    68,    93,    94,   171,   218,   261,   172,
     236,   262,   278,   285
  };

  const short
  parser::yytable_[] =
  {
       9,    78,   104,    65,    58,    15,    18,   150,    51,    27,
      91,    60,   143,   197,   198,   199,   200,   201,   202,   203,
      61,    62,    24,    25,    26,    39,     1,   148,   117,   154,
     155,   156,    96,    54,    43,    60,   157,   118,   158,   159,
     182,    72,   106,   160,    61,    62,    27,    51,   108,   109,
     231,    24,    25,    26,   112,   113,   114,    41,    83,    42,
     205,    57,     4,    43,    87,   181,    88,    89,    90,    69,
      99,    70,   241,    23,    24,    25,    26,     5,   110,   115,
     130,   131,   132,   133,   134,   135,   178,   179,   180,     7,
     184,   126,   268,     8,   269,     9,   175,   176,   177,   208,
     209,   193,    11,    17,    14,    20,    31,    32,    34,   214,
      37,    35,   146,   149,    53,    38,    75,   161,    50,    56,
      77,    79,    82,    97,   102,   280,   281,   213,    95,    98,
     -18,   215,   107,   124,   125,   129,   142,   145,   234,   235,
     293,   294,   239,   186,   174,   242,   243,    43,   183,   185,
     189,   190,   191,   192,   -89,   195,   196,   161,   161,   161,
     161,   161,   161,   161,   219,   256,   204,    15,   210,   118,
     222,   223,   226,   230,   229,   237,   246,  -100,   245,   248,
     249,   270,   253,   258,    58,   250,   257,   251,   255,   263,
     272,   266,   276,   271,   286,   277,   252,   283,   284,   289,
     291,   292,   103,   295,   296,   227,   153,   152,   220,   128,
     275,   207,   240,    73,   273,     0,   161,     0,     0,     0,
       0,     0,   279,   100,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   282,     0,
       0,     0,     0,     0,     0,     0,     0,   264,     0,     0,
       0,     0,     0,     0,     0,     0,   126,     0,     0,     0,
     227,     0,     0,     0,     0,     0,     0,    27,     0,   161,
     161,     0,     0,     0,     0,     0,   287,     0,     0,     0,
       0,     0,     0,     0,   161,   161
  };

  const short
  parser::yycheck_[] =
  {
       7,    53,    81,    43,    42,    12,    13,   120,    38,    16,
      68,    14,   117,   164,   165,   166,   167,   168,   169,   170,
      23,    24,    42,    43,    44,    32,    30,     5,     5,    38,
      39,    40,    70,    40,    12,    14,    45,    14,    47,    48,
     145,    48,    82,    52,    23,    24,    53,    77,    23,    24,
      53,    42,    43,    44,    25,    26,    27,     6,    65,     8,
     173,    52,    52,    12,    52,   144,    54,    55,    56,     6,
      77,     8,   223,    41,    42,    43,    44,     0,    85,    86,
      16,    17,    18,    19,    20,    21,   139,   140,   141,     8,
     148,    98,   257,    31,   259,   102,   136,   137,   138,    28,
      29,   159,    52,    35,    32,    52,    52,    10,     7,   188,
      37,    33,   119,   120,    34,    36,    14,   124,    52,    52,
       7,    11,     6,    15,     7,   276,   277,   185,    52,    14,
      12,   189,    13,    10,    52,    15,    52,     5,   217,   218,
     291,   292,   221,   150,    15,   224,   225,    12,    52,     5,
      14,    14,    14,    14,    14,    22,    11,   164,   165,   166,
     167,   168,   169,   170,    22,   244,   173,   174,   175,    14,
       8,    10,     6,    15,     7,     7,     7,     6,    15,    15,
       6,    51,     7,     7,   222,    15,     6,    15,    11,     6,
      49,     7,    10,    50,    46,    10,   236,    11,    11,    50,
      10,    10,    80,    11,    11,   212,   123,   122,   194,   102,
     267,   174,   222,    48,   263,    -1,   223,    -1,    -1,    -1,
      -1,    -1,   274,    77,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   278,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   254,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   263,    -1,    -1,    -1,
     267,    -1,    -1,    -1,    -1,    -1,    -1,   274,    -1,   276,
     277,    -1,    -1,    -1,    -1,    -1,   283,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   291,   292
  };

  const unsigned char
  parser::yystos_[] =
  {
       0,    30,    58,    60,    52,     0,    61,     8,    31,    59,
      82,    52,    62,    83,    32,    59,    91,    35,    59,    90,
      52,    63,    92,    41,    42,    43,    44,    59,    84,    98,
     100,    52,    10,    64,     7,    33,    87,    37,    36,    59,
      95,     6,     8,    12,    65,    67,    68,    72,    93,    88,
      52,    63,    96,    34,    59,    89,    52,    52,    98,    99,
      14,    23,    24,    59,    74,   138,   143,   149,   150,     6,
       8,    69,    59,    92,    94,    14,    85,     7,    84,    11,
      66,    75,     6,    59,    73,   139,   144,    52,    54,    55,
      56,   101,   130,   151,   152,    52,    98,    15,    14,    59,
      96,    97,     7,    65,   133,   138,   138,    13,    23,    24,
      59,   140,    25,    26,    27,    59,   145,     5,    14,    76,
     102,   131,    70,    71,    10,    52,    59,   105,    82,    15,
      16,    17,    18,    19,    20,    21,   134,   141,   142,   146,
     147,   148,    52,   130,    77,     5,    59,   132,     5,    59,
      72,   103,    69,    68,    38,    39,    40,    45,    47,    48,
      52,    59,   101,   110,   111,   114,   116,   118,   119,   124,
     129,   153,   156,   106,    15,   138,   138,   138,   143,   143,
     143,   133,   130,    52,   101,     5,    59,   104,   117,    14,
      14,    14,    14,   101,   115,    22,    11,   110,   110,   110,
     110,   110,   110,   110,    59,    72,   109,    91,    28,    29,
      59,   135,    78,   101,   133,   101,   120,   125,   154,    22,
      76,   112,     8,    10,   136,   137,     6,    59,    79,     7,
      15,    53,   121,   133,   133,   133,   157,     7,   113,   133,
      99,   110,   133,   133,    80,    15,     7,   123,    15,     6,
      15,    15,   138,     7,   107,    11,   133,     6,     7,   122,
     126,   155,   158,     6,    59,   108,     7,    81,   121,   121,
      51,    50,    49,   105,    86,    79,    10,    10,   159,    84,
     110,   110,   138,    11,    11,   160,    46,    59,   127,    50,
     128,    10,    10,   110,   110,    11,    11
  };

  const unsigned char
  parser::yyr1_[] =
  {
       0,    57,    58,    59,    61,    62,    60,    64,    63,    66,
      65,    65,    67,    67,    68,    69,    70,    69,    71,    69,
      72,    73,    73,    75,    74,    77,    78,    76,    80,    81,
      79,    79,    83,    82,    82,    85,    86,    84,    84,    88,
      87,    89,    89,    90,    90,    91,    91,    93,    92,    94,
      94,    95,    95,    96,    97,    97,    98,    98,    98,    99,
      99,   100,   100,   102,   101,   103,   103,   103,   104,   104,
     106,   107,   105,   105,   108,   108,   109,   109,   110,   110,
     110,   110,   110,   110,   110,   110,   112,   111,   113,   115,
     114,   117,   116,   118,   120,   119,   121,   121,   122,   121,
     123,   121,   125,   126,   124,   128,   127,   127,   129,   129,
     130,   131,   131,   132,   132,   133,   133,   134,   134,   134,
     134,   134,   134,   136,   135,   137,   135,   135,   139,   138,
     141,   140,   142,   140,   140,   144,   143,   146,   145,   147,
     145,   148,   145,   145,   149,   149,   150,   150,   150,   151,
     151,   151,   152,   152,   152,   154,   155,   153,   157,   158,
     159,   160,   156
  };

  const signed char
  parser::yyr2_[] =
  {
       0,     2,     1,     0,     0,     0,     9,     0,     3,     0,
       4,     1,     1,     2,     2,     2,     0,     4,     0,     4,
       4,     2,     1,     0,     4,     0,     0,     6,     0,     0,
       5,     1,     0,    10,     1,     0,     0,    14,     1,     0,
       7,     2,     1,     2,     1,     2,     1,     0,     4,     1,
       1,     2,     1,     3,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     0,     3,     2,     2,     1,     2,     1,
       0,     0,     7,     1,     2,     1,     1,     1,     2,     2,
       2,     2,     2,     2,     2,     1,     0,     5,     1,     0,
       4,     0,     4,     5,     0,     6,     1,     1,     0,     4,
       0,     4,     0,     0,    11,     0,     5,     1,     1,     1,
       2,     2,     2,     2,     1,     4,     1,     1,     1,     1,
       1,     1,     1,     0,     3,     0,     3,     1,     0,     3,
       0,     3,     0,     3,     1,     0,     3,     0,     3,     0,
       3,     0,     3,     1,     1,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     0,     0,    10,     0,     0,
       0,     0,    14
  };



  // YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
  // First, the terminals, then, starting at \a yyntokens_, nonterminals.
  const char*
  const parser::yytname_[] =
  {
  "\"eof\"", "error", "$undefined", "COMENTARIO", "SIMBOLO", "PUNTO",
  "COMA", "SCOL", "COL", "GBAJO", "LCUR", "RCUR", "LBRA", "RBRA", "LPAR",
  "RPAR", "EQ", "GE", "LE", "GT", "LT", "NE", "ASSIGN", "SUM", "RES",
  "MUL", "DIV", "MOD", "AND", "OR", "PROGRAMA", "CLASE", "VARIABLES",
  "MAIN", "METODOS", "HEREDA", "ATRIBUTOS", "FUNCION", "RETORNAR", "LEER",
  "ESCRIBIR", "VOID", "INT_T", "FLOAT_T", "CHAR_T", "SI", "SINO",
  "MIENTRAS", "PARA", "EN", "HACER", "ENTONCES", "ID", "STRING", "CHAR",
  "INT", "FLOAT", "$accept", "script", "empty", "program", "$@1", "$@2",
  "declare_var", "$@3", "declare_bridge1", "$@4", "declare_bridge2",
  "declare_bridge3", "declare_bridge4", "$@5", "$@6", "dimensions",
  "matrix", "single_express", "$@7", "mult_express", "$@8", "$@9",
  "expression_loop", "$@10", "$@11", "classes", "$@12", "functions",
  "$@13", "$@14", "main", "$@15", "methods", "inheritance", "variables",
  "var_bridge1", "$@16", "var_bridge2", "attributes", "attr_bridge1",
  "attr_bridge2", "primitive_type", "var_type", "return_type", "call_var",
  "$@17", "call_options", "call_cont", "parameters", "$@18", "$@19",
  "par_cont", "par_array", "statutes", "assignment", "$@20",
  "assignment_opt", "call_void", "$@21", "function_return", "$@22", "read",
  "write", "$@23", "write_expression_opt", "$@24", "$@25",
  "decision_statement", "$@26", "$@27", "dec_else", "$@28",
  "repetition_statement", "call_function", "func_options", "func_cont",
  "expression", "relop", "express_loop", "$@29", "$@30", "exp", "$@31",
  "exp_loop", "$@32", "$@33", "term", "$@34", "term_loop", "$@35", "$@36",
  "$@37", "factor", "sign", "call", "var_cte", "conditional", "$@38",
  "$@39", "nonconditional", "$@40", "$@41", "$@42", "$@43", YY_NULLPTR
  };

#if YYDEBUG
  const short
  parser::yyrline_[] =
  {
       0,   138,   138,   141,   144,   144,   144,   148,   148,   149,
     149,   150,   151,   152,   153,   154,   155,   155,   156,   156,
     161,   162,   163,   168,   168,   187,   191,   187,   206,   210,
     206,   225,   230,   230,   231,   234,   241,   234,   245,   248,
     248,   255,   256,   259,   260,   265,   266,   269,   268,   284,
     285,   292,   293,   294,   295,   296,   301,   302,   303,   306,
     306,   309,   309,   312,   312,   325,   326,   327,   328,   329,
     333,   334,   333,   339,   341,   342,   344,   345,   349,   350,
     351,   352,   353,   354,   355,   356,   360,   359,   376,   379,
     379,   386,   386,   403,   406,   406,   407,   408,   418,   418,
     430,   430,   433,   433,   433,   445,   445,   454,   460,   460,
     463,   464,   465,   466,   467,   470,   471,   472,   473,   474,
     475,   476,   477,   478,   478,   479,   479,   480,   483,   483,
     484,   484,   485,   485,   486,   489,   489,   490,   490,   491,
     491,   492,   492,   493,   496,   497,   498,   499,   500,   501,
     502,   503,   506,   507,   508,   511,   511,   511,   530,   536,
     545,   545,   530
  };

  // Print the state stack on the debug stream.
  void
  parser::yystack_print_ ()
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << int (i->state);
    *yycdebug_ << '\n';
  }

  // Report on the debug stream that the rule \a yyrule is going to be reduced.
  void
  parser::yy_reduce_print_ (int yyrule)
  {
    int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):\n";
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG


#line 6 "parser.yy"
} // yy
#line 1931 "parser.tab.cc"

#line 570 "parser.yy"

void yy::parser::error(const location_type& lugar, const std::string& lexema)
{
  std::cout << "SYNTAX ERROR !!! " << lexema << std::endl;
}
