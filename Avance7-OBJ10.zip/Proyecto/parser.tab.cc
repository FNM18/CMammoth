// A Bison parser, made by GNU Bison 3.5.1.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2020 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// Undocumented macros, especially those whose name start with YY_,
// are private implementation details.  Do not rely on them.





#include "parser.tab.hh"


// Unqualified %code blocks.
#line 22 "parser.yy"

#include "driver.h"
#include "flags.h"
#include "semantic.cpp"
#include <iostream>
#include <vector>
#include <stack>

Scope scope = Scope();
int tempCount = 0;
ExpressionSolver es;
ParamSolver ps = ParamSolver("global");
stack<ParamSolver> params;

stack<ExpressionSolver> pes;
Quad quads = Quad();
VarTable::symbolRow * var = NULL;

#line 64 "parser.tab.cc"


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

// Whether we are compiled with exception support.
#ifndef YY_EXCEPTIONS
# if defined __GNUC__ && !defined __EXCEPTIONS
#  define YY_EXCEPTIONS 0
# else
#  define YY_EXCEPTIONS 1
# endif
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K].location)
/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

# ifndef YYLLOC_DEFAULT
#  define YYLLOC_DEFAULT(Current, Rhs, N)                               \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).begin  = YYRHSLOC (Rhs, 1).begin;                   \
          (Current).end    = YYRHSLOC (Rhs, N).end;                     \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).begin = (Current).end = YYRHSLOC (Rhs, 0).end;      \
        }                                                               \
    while (false)
# endif


// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << '\n';                       \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yystack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YYUSE (Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void> (0)
# define YY_STACK_PRINT()                static_cast<void> (0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)

#line 6 "parser.yy"
namespace yy {
#line 156 "parser.tab.cc"


  /* Return YYSTR after stripping away unnecessary quotes and
     backslashes, so that it's suitable for yyerror.  The heuristic is
     that double-quoting is unnecessary unless the string contains an
     apostrophe, a comma, or backslash (other than backslash-backslash).
     YYSTR is taken from yytname.  */
  std::string
  parser::yytnamerr_ (const char *yystr)
  {
    if (*yystr == '"')
      {
        std::string yyr;
        char const *yyp = yystr;

        for (;;)
          switch (*++yyp)
            {
            case '\'':
            case ',':
              goto do_not_strip_quotes;

            case '\\':
              if (*++yyp != '\\')
                goto do_not_strip_quotes;
              else
                goto append;

            append:
            default:
              yyr += *yyp;
              break;

            case '"':
              return yyr;
            }
      do_not_strip_quotes: ;
      }

    return yystr;
  }


  /// Build a parser object.
  parser::parser (parser_driver& driver_yyarg)
#if YYDEBUG
    : yydebug_ (false),
      yycdebug_ (&std::cerr),
#else
    :
#endif
      driver (driver_yyarg)
  {}

  parser::~parser ()
  {}

  parser::syntax_error::~syntax_error () YY_NOEXCEPT YY_NOTHROW
  {}

  /*---------------.
  | Symbol types.  |
  `---------------*/



  // by_state.
  parser::by_state::by_state () YY_NOEXCEPT
    : state (empty_state)
  {}

  parser::by_state::by_state (const by_state& that) YY_NOEXCEPT
    : state (that.state)
  {}

  void
  parser::by_state::clear () YY_NOEXCEPT
  {
    state = empty_state;
  }

  void
  parser::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  parser::by_state::by_state (state_type s) YY_NOEXCEPT
    : state (s)
  {}

  parser::symbol_number_type
  parser::by_state::type_get () const YY_NOEXCEPT
  {
    if (state == empty_state)
      return empty_symbol;
    else
      return yystos_[+state];
  }

  parser::stack_symbol_type::stack_symbol_type ()
  {}

  parser::stack_symbol_type::stack_symbol_type (YY_RVREF (stack_symbol_type) that)
    : super_type (YY_MOVE (that.state), YY_MOVE (that.location))
  {
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.YY_MOVE_OR_COPY< char > (YY_MOVE (that.value));
        break;

      case 55: // INT
      case 56: // FLOAT
        value.YY_MOVE_OR_COPY< float > (YY_MOVE (that.value));
        break;

      case 52: // ID
      case 53: // STRING
        value.YY_MOVE_OR_COPY< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

#if 201103L <= YY_CPLUSPLUS
    // that is emptied.
    that.state = empty_state;
#endif
  }

  parser::stack_symbol_type::stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) that)
    : super_type (s, YY_MOVE (that.location))
  {
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.move< char > (YY_MOVE (that.value));
        break;

      case 55: // INT
      case 56: // FLOAT
        value.move< float > (YY_MOVE (that.value));
        break;

      case 52: // ID
      case 53: // STRING
        value.move< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

    // that is emptied.
    that.type = empty_symbol;
  }

#if YY_CPLUSPLUS < 201103L
  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.copy< char > (that.value);
        break;

      case 55: // INT
      case 56: // FLOAT
        value.copy< float > (that.value);
        break;

      case 52: // ID
      case 53: // STRING
        value.copy< std::string > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    return *this;
  }

  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (stack_symbol_type& that)
  {
    state = that.state;
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.move< char > (that.value);
        break;

      case 55: // INT
      case 56: // FLOAT
        value.move< float > (that.value);
        break;

      case 52: // ID
      case 53: // STRING
        value.move< std::string > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    // that is emptied.
    that.state = empty_state;
    return *this;
  }
#endif

  template <typename Base>
  void
  parser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);
  }

#if YYDEBUG
  template <typename Base>
  void
  parser::yy_print_ (std::ostream& yyo,
                                     const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YYUSE (yyoutput);
    symbol_number_type yytype = yysym.type_get ();
#if defined __GNUC__ && ! defined __clang__ && ! defined __ICC && __GNUC__ * 100 + __GNUC_MINOR__ <= 408
    // Avoid a (spurious) G++ 4.8 warning about "array subscript is
    // below array bounds".
    if (yysym.empty ())
      std::abort ();
#endif
    yyo << (yytype < yyntokens_ ? "token" : "nterm")
        << ' ' << yytname_[yytype] << " ("
        << yysym.location << ": ";
    switch (yytype)
    {
      case 52: // ID
#line 138 "parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 408 "parser.tab.cc"
        break;

      case 53: // STRING
#line 138 "parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 414 "parser.tab.cc"
        break;

      case 54: // CHAR
#line 138 "parser.yy"
                 { yyoutput << yysym.value.template as < char > (); }
#line 420 "parser.tab.cc"
        break;

      case 55: // INT
#line 138 "parser.yy"
                 { yyoutput << yysym.value.template as < float > (); }
#line 426 "parser.tab.cc"
        break;

      case 56: // FLOAT
#line 138 "parser.yy"
                 { yyoutput << yysym.value.template as < float > (); }
#line 432 "parser.tab.cc"
        break;

      default:
        break;
    }
    yyo << ')';
  }
#endif

  void
  parser::yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym)
  {
    if (m)
      YY_SYMBOL_PRINT (m, sym);
    yystack_.push (YY_MOVE (sym));
  }

  void
  parser::yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym)
  {
#if 201103L <= YY_CPLUSPLUS
    yypush_ (m, stack_symbol_type (s, std::move (sym)));
#else
    stack_symbol_type ss (s, sym);
    yypush_ (m, ss);
#endif
  }

  void
  parser::yypop_ (int n)
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  parser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  parser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  parser::debug_level_type
  parser::debug_level () const
  {
    return yydebug_;
  }

  void
  parser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  parser::state_type
  parser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - yyntokens_] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - yyntokens_];
  }

  bool
  parser::yy_pact_value_is_default_ (int yyvalue)
  {
    return yyvalue == yypact_ninf_;
  }

  bool
  parser::yy_table_value_is_error_ (int yyvalue)
  {
    return yyvalue == yytable_ninf_;
  }

  int
  parser::operator() ()
  {
    return parse ();
  }

  int
  parser::parse ()
  {
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The locations where the error started and ended.
    stack_symbol_type yyerror_range[3];

    /// The return value of parse ().
    int yyresult;

#if YY_EXCEPTIONS
    try
#endif // YY_EXCEPTIONS
      {
    YYCDEBUG << "Starting parse\n";


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, YY_MOVE (yyla));

  /*-----------------------------------------------.
  | yynewstate -- push a new symbol on the stack.  |
  `-----------------------------------------------*/
  yynewstate:
    YYCDEBUG << "Entering state " << int (yystack_[0].state) << '\n';

    // Accept?
    if (yystack_[0].state == yyfinal_)
      YYACCEPT;

    goto yybackup;


  /*-----------.
  | yybackup.  |
  `-----------*/
  yybackup:
    // Try to take a decision without lookahead.
    yyn = yypact_[+yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token: ";
#if YY_EXCEPTIONS
        try
#endif // YY_EXCEPTIONS
          {
            symbol_type yylookahead (yylex (driver));
            yyla.move (yylookahead);
          }
#if YY_EXCEPTIONS
        catch (const syntax_error& yyexc)
          {
            YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
            error (yyexc);
            goto yyerrlab1;
          }
#endif // YY_EXCEPTIONS
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.type_get ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.type_get ())
      {
        goto yydefault;
      }

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", state_type (yyn), YY_MOVE (yyla));
    goto yynewstate;


  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[+yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;


  /*-----------------------------.
  | yyreduce -- do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_ (yystack_[yylen].state, yyr1_[yyn]);
      /* Variants are always initialized to an empty instance of the
         correct type. The default '$$ = $1' action is NOT applied
         when using variants.  */
      switch (yyr1_[yyn])
    {
      case 54: // CHAR
        yylhs.value.emplace< char > ();
        break;

      case 55: // INT
      case 56: // FLOAT
        yylhs.value.emplace< float > ();
        break;

      case 52: // ID
      case 53: // STRING
        yylhs.value.emplace< std::string > ();
        break;

      default:
        break;
    }


      // Default location.
      {
        stack_type::slice range (yystack_, yylen);
        YYLLOC_DEFAULT (yylhs.location, range, yylen);
        yyerror_range[1].location = yylhs.location;
      }

      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
#if YY_EXCEPTIONS
      try
#endif // YY_EXCEPTIONS
        {
          switch (yyn)
            {
  case 4:
#line 149 "parser.yy"
                      {quads.prepareMainQuad();}
#line 687 "parser.tab.cc"
    break;

  case 5:
#line 149 "parser.yy"
                                                             {globalFlag = 1;}
#line 693 "parser.tab.cc"
    break;

  case 7:
#line 153 "parser.yy"
                 {setID(yystack_[0].value.as < std::string > (),0,0);}
#line 699 "parser.tab.cc"
    break;

  case 9:
#line 154 "parser.yy"
                          {setID(yystack_[0].value.as < std::string > (),0,0);}
#line 705 "parser.tab.cc"
    break;

  case 16:
#line 160 "parser.yy"
                          {setID(yystack_[0].value.as < std::string > (),0,0);}
#line 711 "parser.tab.cc"
    break;

  case 18:
#line 161 "parser.yy"
                          {setID(yystack_[0].value.as < std::string > (),0,0);}
#line 717 "parser.tab.cc"
    break;

  case 20:
#line 166 "parser.yy"
                          {currentIds.back().dim1 = yystack_[0].value.as < float > ();}
#line 723 "parser.tab.cc"
    break;

  case 22:
#line 167 "parser.yy"
                      {currentIds.back().dim2 = yystack_[0].value.as < float > ();}
#line 729 "parser.tab.cc"
    break;

  case 24:
#line 171 "parser.yy"
                  {
        int id = 0;
        cout << "sale" << endl;
        if(paramsFlag){
                id = pes.top().popOprnd();
        }else{
                if(expressionFlag){
                        id = es.popOprnd();
                }else{
                        id = var->dir;
                }
        }
        cout << "sale2 -> " << id <<  endl;
        ps = ParamSolver(id);
        params.push(ps);
        paramsFlag = 1;
        if(paramsFlag){
                pes.push(ExpressionSolver());
        }
        cout << "sale3" << endl;
}
#line 755 "parser.tab.cc"
    break;

  case 25:
#line 191 "parser.yy"
             {
        if(paramsFlag){
                quads.importSolver(pes.top()); 
                int single = pes.top().singleVar();
                if(single){
                        cout<<"Direction -> " << single << endl;
                        int paramNum = params.top().insertParamArray(single);
                        int dim = params.top().getDimension(paramNum);
                        quads.insertQuad(205,single,-1,dim);
                        if(params.top().getDimension(2) > 0){
                                int temp = params.top().generateArrayQuad();
                                quads.insertQuad(206,single,params.top().getDimension(2),temp);
                        }else{
                                int pointer = params.top().generatePointerQuad();
                                quads.insertQuad(207,params.top().getArrayDir(),single,pointer);
                        }
                }else{
                        cout<<"Direction -> " << quads.getLastQuad().result << endl;
                        int paramNum = params.top().insertParamArray(quads.getLastQuad().result);
                        int dim = params.top().getDimension(paramNum);
                        quads.insertQuad(205,quads.getLastQuad().result,-1,dim);
                        if(params.top().getDimension(2) > 0){
                                int temp = params.top().generateArrayQuad();
                                quads.insertQuad(206,quads.getLastQuad().result,params.top().getDimension(2),temp);
                        }else{
                                int pointer = params.top().generatePointerQuad();
                                quads.insertQuad(207,params.top().getArrayDir(),quads.getLastQuad().result,pointer);
                        }
                }
                pes.pop();
        }
}
#line 792 "parser.tab.cc"
    break;

  case 26:
#line 222 "parser.yy"
              {
        
        params.top().checkParams();
        if(params.size()<2){
                paramsFlag = 0; 
        }
        string pointer = scope.getGlobalVariable(quads.getLastQuad().result)->name;
        if(params.size()>1){
                pes.top().insertOprnd(pointer);
        }else{
                if(expressionFlag){
                        
                        es.insertOprnd(pointer);
                }else{
                        var = scope.getVarOnScope(quads.getLastQuad().result);
                }
        }
        cout << "Se sale 5" << endl;
        params.pop();
}
#line 817 "parser.tab.cc"
    break;

  case 27:
#line 242 "parser.yy"
              {
        if(paramsFlag){
                pes.push(ExpressionSolver());
        }
}
#line 827 "parser.tab.cc"
    break;

  case 28:
#line 246 "parser.yy"
             {
        if(paramsFlag){
                int result = quads.getLastQuad().result;
                quads.importSolver(pes.top()); 
                int single = pes.top().singleVar();
                if(single){
                        cout<<"Direction -> " << single << endl;
                        int paramNum = params.top().insertParamArray(single);
                        int dim = params.top().getDimension(paramNum);
                        int temp = params.top().generateArrayQuad();
                        int pointer = params.top().generatePointerQuad();
                        quads.insertQuad(205,single,-1,dim);
                        quads.insertQuad(0,result,single,temp);
                        quads.insertQuad(207,params.top().getArrayDir(),temp,pointer);
                }else{
                        cout<<"Direction -> " << quads.getLastQuad().result << endl;
                        int paramNum = params.top().insertParamArray(quads.getLastQuad().result);
                        int dim = params.top().getDimension(paramNum);
                        int temp = params.top().generateArrayQuad();
                        int pointer = params.top().generatePointerQuad();
                        quads.insertQuad(205,quads.getLastQuad().result,-1,dim);
                        quads.insertQuad(0,result,quads.getLastQuad().result,temp);
                        quads.insertQuad(207,params.top().getArrayDir(),temp,pointer);
                }
                pes.pop();
        }
}
#line 859 "parser.tab.cc"
    break;

  case 30:
#line 278 "parser.yy"
                     {
        if(paramsFlag){
                pes.top().installPar();
        }else{
                if(expressionFlag){
                        es.installPar();
                }
        }
        }
#line 873 "parser.tab.cc"
    break;

  case 31:
#line 286 "parser.yy"
                          {
                if(paramsFlag){
                        pes.top().closePar();
                }else{
                        if(expressionFlag){
                                es.closePar();
                        }
                }
        }
#line 887 "parser.tab.cc"
    break;

  case 32:
#line 297 "parser.yy"
                    {
        if(paramsFlag){
                pes.push(ExpressionSolver());
        }
}
#line 897 "parser.tab.cc"
    break;

  case 33:
#line 301 "parser.yy"
             {
        if(paramsFlag){
                quads.importSolver(pes.top()); 
                int single = pes.top().singleVar();
                if(single){
                        cout<<"Direction -> " << single << endl;
                        int paramNum = params.top().insertParam(single);
                        quads.insertQuad(203,single,-1,paramNum);
                }else{
                        cout<<"Direction -> " << quads.getLastQuad().result << endl;
                        int paramNum = params.top().insertParam(quads.getLastQuad().result);
                        quads.insertQuad(203,quads.getLastQuad().result,-1,paramNum);
                }
                pes.pop();
        }
}
#line 918 "parser.tab.cc"
    break;

  case 35:
#line 317 "parser.yy"
                       {
        if(paramsFlag){
                pes.push(ExpressionSolver());
        }
}
#line 928 "parser.tab.cc"
    break;

  case 36:
#line 321 "parser.yy"
             {
        if(paramsFlag){
                quads.importSolver(pes.top());
                int single = pes.top().singleVar();
                if(single){
                        cout<<"Direction -> " << single << endl;
                        int paramNum = params.top().insertParam(single);
                        quads.insertQuad(203,single,-1,paramNum);
                }else{
                        cout<<"Direction -> " << quads.getLastQuad().result << endl;
                        int paramNum = params.top().insertParam(quads.getLastQuad().result);
                        quads.insertQuad(203,quads.getLastQuad().result,-1,paramNum);
                }
                pes.pop();
        }
}
#line 949 "parser.tab.cc"
    break;

  case 39:
#line 342 "parser.yy"
                   {cout << "Clase id : " << yystack_[0].value.as < std::string > () << endl;}
#line 955 "parser.tab.cc"
    break;

  case 42:
#line 346 "parser.yy"
                                   {
        scope.resetLocalConts();
        setCurrentFunction(yystack_[0].value.as < std::string > ());
        scope.globalInsertFunction(yystack_[0].value.as < std::string > (),currentType,"function",quads.getQuadLastDir());
        scope.setFunctionScope(yystack_[0].value.as < std::string > ());
        scope.installFunctionVars(yystack_[0].value.as < std::string > ());
        if(currentType<10){
                scope.insertGlobalVariable(yystack_[0].value.as < std::string > (),currentType);
        }
        resetCurrentType();
        globalFlag = 0;
}
#line 972 "parser.tab.cc"
    break;

  case 43:
#line 357 "parser.yy"
                                                         {
        resetCurrentFunction();
        quads.insertQuad(299,-1,-1,-1);
}
#line 981 "parser.tab.cc"
    break;

  case 46:
#line 364 "parser.yy"
            {
        scope.resetLocalConts();
        quads.setMainQuad();
        scope.setFunctionScope("global");
}
#line 991 "parser.tab.cc"
    break;

  case 47:
#line 368 "parser.yy"
                               {quads.insertQuad(999,-1,-1,-1);quads.printQuadList();}
#line 997 "parser.tab.cc"
    break;

  case 50:
#line 376 "parser.yy"
                        {cout << "Herencia id : " << yystack_[0].value.as < std::string > () << endl;}
#line 1003 "parser.tab.cc"
    break;

  case 54:
#line 386 "parser.yy"
{       
        if(globalFlag){
                for(auto var : currentIds){
                        scope.insertGlobalVariable(var.id, var.dim1,var.dim2,currentType);
                }
        }else{
                for(auto var : currentIds){
                        scope.insertVarOnScope(var.id, var.dim1,var.dim2,currentType);
                } 
        }
        resetID();
        resetCurrentType();
}
#line 1021 "parser.tab.cc"
    break;

  case 63:
#line 418 "parser.yy"
                       {setCurrentType(0);}
#line 1027 "parser.tab.cc"
    break;

  case 64:
#line 419 "parser.yy"
                          {setCurrentType(1);}
#line 1033 "parser.tab.cc"
    break;

  case 65:
#line 420 "parser.yy"
                         {setCurrentType(2);}
#line 1039 "parser.tab.cc"
    break;

  case 67:
#line 423 "parser.yy"
                               {setCurrentType(10);}
#line 1045 "parser.tab.cc"
    break;

  case 69:
#line 426 "parser.yy"
                                    {setCurrentType(20);}
#line 1051 "parser.tab.cc"
    break;

  case 70:
#line 429 "parser.yy"
              {
        if(paramsFlag){
                pes.top().insertOprnd(yystack_[0].value.as < std::string > ());
        }else{
                if(expressionFlag){
                        es.insertOprnd(yystack_[0].value.as < std::string > ());
                }else{
                        var = scope.getVarOnScope(yystack_[0].value.as < std::string > ());
                        if(var == NULL)
                                var = scope.getGlobalVariable(yystack_[0].value.as < std::string > ());
                }
        }
}
#line 1069 "parser.tab.cc"
    break;

  case 77:
#line 450 "parser.yy"
                {setID(yystack_[0].value.as < std::string > (),0,0);}
#line 1075 "parser.tab.cc"
    break;

  case 78:
#line 451 "parser.yy"
{
        scope.insertParameterOnScope(yystack_[4].value.as < std::string > (),currentType);
        resetCurrentType();
        resetID();
}
#line 1085 "parser.tab.cc"
    break;

  case 93:
#line 477 "parser.yy"
{
        es = ExpressionSolver();
        expressionFlag = 1;
        es.insertOprnd(var->name);
        es.insertOptr(5);
}
#line 1096 "parser.tab.cc"
    break;

  case 94:
#line 484 "parser.yy"
{
        cout << "Se sale 6" << endl;
        es.assign();
        cout << "Se sale 7" << endl;
        quads.importSolver(es); 
        expressionFlag = 0;
        cout << "Se sale 8" << endl;
}
#line 1109 "parser.tab.cc"
    break;

  case 96:
#line 497 "parser.yy"
               {
        ps = ParamSolver(yystack_[0].value.as < std::string > ());
        params.push(ps);
        paramsFlag = 1;
        quads.insertQuad(202,params.top().getFunctionQuadDir(),-1,-1);
}
#line 1120 "parser.tab.cc"
    break;

  case 97:
#line 502 "parser.yy"
                    {
        params.top().checkParams(); 
        paramsFlag = 0; 
        quads.insertQuad(204,params.top().getFunctionQuadDir(),-1,-1);
        params.pop();
        }
#line 1131 "parser.tab.cc"
    break;

  case 98:
#line 510 "parser.yy"
                          {
        es = ExpressionSolver();
        expressionFlag = 1;
}
#line 1140 "parser.tab.cc"
    break;

  case 99:
#line 513 "parser.yy"
                  {
        quads.importSolver(es); 
        expressionFlag = 0;
        int single = es.singleVar();
        if(single){
                es.checkVarType(single);
                cout << "Single 1" << endl;
                int var = scope.getScopeDir();
                cout << "Single 2" << endl;
                quads.insertQuad(298,single,-1,var);
        }else{
                es.checkVarType(quads.getLastQuad().result);
                cout << "Mult 1" << endl;
                int var = scope.getScopeDir();
                cout << "Mult 2" << endl;
                quads.insertQuad(298,quads.getLastQuad().result,-1,var);
        }
}
#line 1163 "parser.tab.cc"
    break;

  case 100:
#line 533 "parser.yy"
                                    { quads.insertQuad(103,-1,-1,var->dir);}
#line 1169 "parser.tab.cc"
    break;

  case 101:
#line 536 "parser.yy"
                      { es = ExpressionSolver(); expressionFlag = 1;}
#line 1175 "parser.tab.cc"
    break;

  case 103:
#line 537 "parser.yy"
                              {
                        expressionFlag = 0;
                        cout << "Se mete string" << endl ;
                        int text = scope.addConstantSTRINGVarDir(yystack_[0].value.as < std::string > ());
                        cout << "Se mete string 2" << endl ;
                        quads.insertQuad(102,text,-1,-1);
                        int newLine = scope.addConstantSTRINGNewLine("\n");
                        quads.insertQuad(102,newLine,-1,-1);
                        }
#line 1189 "parser.tab.cc"
    break;

  case 104:
#line 546 "parser.yy"
                         {
                        expressionFlag = 0;
                        int text = scope.addConstantSTRINGVarDir(yystack_[0].value.as < std::string > ());
                        quads.insertQuad(102,text,-1,-1);
                        expressionFlag = 1;
                }
#line 1200 "parser.tab.cc"
    break;

  case 106:
#line 552 "parser.yy"
                             {
                        quads.importSolver(es); 
                        expressionFlag = 0;
                        int single = es.singleVar();
                        if(single){
                                quads.insertQuad(102,single,-1,-1);
                        }else{
                                quads.insertQuad(102,quads.getLastQuad().result,-1,-1);
                        }
                        
                        int newLine = scope.addConstantSTRINGNewLine("\n");
                        quads.insertQuad(102,newLine,-1,-1);
                }
#line 1218 "parser.tab.cc"
    break;

  case 107:
#line 565 "parser.yy"
                                  {
                        quads.importSolver(es); 
                        expressionFlag = 0;
                        int single = es.singleVar();
                        if(single){
                                quads.insertQuad(102,single,-1,-1);
                        }else{
                                quads.insertQuad(102,quads.getLastQuad().result,-1,-1);
                        }
                        es = ExpressionSolver(); 
                        expressionFlag = 1;
                }
#line 1235 "parser.tab.cc"
    break;

  case 109:
#line 579 "parser.yy"
                             {paramsFlag = 0; es = ExpressionSolver(); expressionFlag = 1;}
#line 1241 "parser.tab.cc"
    break;

  case 110:
#line 579 "parser.yy"
                                                                                                            {
        quads.importSolver(es); 
        expressionFlag = 0;
        int single = es.singleVar();
        setJDir(quads.getQuadLastDir());
        if(single){
                quads.insertQuad(201,single,-1,-1);
        }else{
                quads.insertQuad(201,quads.getLastQuad().result,-1,-1);
        }
}
#line 1257 "parser.tab.cc"
    break;

  case 112:
#line 591 "parser.yy"
                { 
                int dir = getJDir();
                quads.updateQuadResult(dir,quads.getQuadLastDir()+1); 
                setJDir(quads.getQuadLastDir());
                quads.insertQuad(200,-1,-1,-1);
        }
#line 1268 "parser.tab.cc"
    break;

  case 113:
#line 596 "parser.yy"
                             {
                int dir = getJDir();
                quads.updateQuadResult(dir,quads.getQuadLastDir());
        }
#line 1277 "parser.tab.cc"
    break;

  case 114:
#line 600 "parser.yy"
                {
                int dir = getJDir();
                quads.updateQuadResult(dir,quads.getQuadLastDir()); 
        }
#line 1286 "parser.tab.cc"
    break;

  case 117:
#line 609 "parser.yy"
                   {
        ps = ParamSolver(yystack_[0].value.as < std::string > ());
        params.push(ps);
        paramsFlag = 1;
        quads.insertQuad(202,params.top().getFunctionQuadDir(),-1,-1);
        }
#line 1297 "parser.tab.cc"
    break;

  case 120:
#line 616 "parser.yy"
                       {
                params.top().checkParams();
                if(params.size()<2){
                        paramsFlag = 0; 
                } 
                quads.insertQuad(204,params.top().getFunctionGlobalDir(),-1,-1);
                string temp = params.top().generateReturnQuad();
                int dir = scope.getVarOnScope(temp)->dir;
                quads.insertQuad(5,params.top().getFunctionGlobalDir(),-1,dir);
                if(params.size()>1){
                        pes.top().insertOprnd(temp);
                }else{
                        if(expressionFlag){
                                es.insertOprnd(temp);
                        }
                }
                params.pop();
        }
#line 1320 "parser.tab.cc"
    break;

  case 124:
#line 638 "parser.yy"
                           {es.checkStacks();}
#line 1326 "parser.tab.cc"
    break;

  case 127:
#line 640 "parser.yy"
           {if(paramsFlag){pes.top().insertOptr(6);}else{ if(expressionFlag){es.insertOptr(6);}}}
#line 1332 "parser.tab.cc"
    break;

  case 128:
#line 641 "parser.yy"
           {if(paramsFlag){pes.top().insertOptr(7);}else{ if(expressionFlag){es.insertOptr(7);}}}
#line 1338 "parser.tab.cc"
    break;

  case 129:
#line 642 "parser.yy"
           {if(paramsFlag){pes.top().insertOptr(10);}else{ if(expressionFlag){es.insertOptr(10);}}}
#line 1344 "parser.tab.cc"
    break;

  case 130:
#line 643 "parser.yy"
           {if(paramsFlag){pes.top().insertOptr(11);}else{ if(expressionFlag){es.insertOptr(11);}}}
#line 1350 "parser.tab.cc"
    break;

  case 131:
#line 644 "parser.yy"
           {if(paramsFlag){pes.top().insertOptr(8);}else{ if(expressionFlag){es.insertOptr(8);}}}
#line 1356 "parser.tab.cc"
    break;

  case 132:
#line 645 "parser.yy"
           {if(paramsFlag){pes.top().insertOptr(9);}else{ if(expressionFlag){es.insertOptr(9);}}}
#line 1362 "parser.tab.cc"
    break;

  case 133:
#line 646 "parser.yy"
                   {if(paramsFlag){pes.top().insertOptr(12);}else{ if(expressionFlag){es.insertOptr(12);}}}
#line 1368 "parser.tab.cc"
    break;

  case 135:
#line 647 "parser.yy"
                  {if(paramsFlag){pes.top().insertOptr(13);}else{ if(expressionFlag){es.insertOptr(13);}}}
#line 1374 "parser.tab.cc"
    break;

  case 138:
#line 651 "parser.yy"
           {
        if(paramsFlag){
                if(pes.top().operators.size() > 0){
                        if(pes.top().operators.top() == 0 || pes.top().operators.top() == 1){
                                pes.top().checkStacks();
                        }
                }
        }else{ 
                if(expressionFlag){
                        if(es.operators.size() > 0){
                                if(es.operators.top() == 0 || es.operators.top() == 1){
                                        es.checkStacks();
                                }
                        }
                }
        }
        }
#line 1396 "parser.tab.cc"
    break;

  case 140:
#line 668 "parser.yy"
               {if(paramsFlag){pes.top().insertOptr(0);}else{ if(expressionFlag){es.insertOptr(0);}}}
#line 1402 "parser.tab.cc"
    break;

  case 142:
#line 669 "parser.yy"
               {if(paramsFlag){pes.top().insertOptr(1);}else{ if(expressionFlag){es.insertOptr(1);}}}
#line 1408 "parser.tab.cc"
    break;

  case 145:
#line 673 "parser.yy"
              {
        if(paramsFlag){
                if(pes.top().operators.size() > 0){
                        if(pes.top().operators.top() == 2 || pes.top().operators.top() == 3 || pes.top().operators.top() == 4){
                                pes.top().checkStacks();
                        }
                }
        }else{
                if(expressionFlag){
                        if(es.operators.size() > 0){
                                if(es.operators.top() == 2 || es.operators.top() == 3 || es.operators.top() == 4){
                                        es.checkStacks();
                                }
                        }
                }
        }
        }
#line 1430 "parser.tab.cc"
    break;

  case 147:
#line 690 "parser.yy"
                {if(paramsFlag){pes.top().insertOptr(2);}else{if(expressionFlag){es.insertOptr(2);}}}
#line 1436 "parser.tab.cc"
    break;

  case 149:
#line 691 "parser.yy"
                {if(paramsFlag){pes.top().insertOptr(3);}else{if(expressionFlag){es.insertOptr(3);}}}
#line 1442 "parser.tab.cc"
    break;

  case 151:
#line 692 "parser.yy"
                {if(paramsFlag){pes.top().insertOptr(4);}else{if(expressionFlag){es.insertOptr(4);}}}
#line 1448 "parser.tab.cc"
    break;

  case 162:
#line 706 "parser.yy"
              {if(paramsFlag){pes.top().insertOprnd((int)yystack_[0].value.as < float > ());}else{ if(expressionFlag){es.insertOprnd((int)yystack_[0].value.as < float > ());}}}
#line 1454 "parser.tab.cc"
    break;

  case 163:
#line 707 "parser.yy"
                {if(paramsFlag){pes.top().insertOprnd((float)yystack_[0].value.as < float > ());}else{ if(expressionFlag){es.insertOprnd((float)yystack_[0].value.as < float > ());}}}
#line 1460 "parser.tab.cc"
    break;

  case 164:
#line 708 "parser.yy"
                {if(paramsFlag){pes.top().insertOprnd((char)yystack_[0].value.as < char > ());}else{ if(expressionFlag){es.insertOprnd((char)yystack_[0].value.as < char > ());}}}
#line 1466 "parser.tab.cc"
    break;

  case 165:
#line 711 "parser.yy"
                            {paramsFlag = 0; es = ExpressionSolver(); expressionFlag = 1;}
#line 1472 "parser.tab.cc"
    break;

  case 166:
#line 711 "parser.yy"
                                                                                                           {
        setJDir(quads.getQuadLastDir());
        quads.importSolver(es); 
        expressionFlag = 0;
        int single = es.singleVar();
        setJDir(quads.getQuadLastDir());
        if(single){
                quads.insertQuad(201,single,-1,-1);
        }else{
                quads.insertQuad(201,quads.getLastQuad().result,-1,-1);
        }
}
#line 1489 "parser.tab.cc"
    break;

  case 167:
#line 722 "parser.yy"
                          {
        int dir = getJDir();
        int exp = getJDir();
        quads.insertQuad(200,-1,-1,exp);
        quads.updateQuadResult(dir,quads.getQuadLastDir());
}
#line 1500 "parser.tab.cc"
    break;

  case 168:
#line 730 "parser.yy"
                                      {
        es = ExpressionSolver(); 
        paramsFlag = 0;
        expressionFlag = 1;
        setforID(var->name);
        es.insertOprnd(var->name);
        es.insertOptr(5);
}
#line 1513 "parser.tab.cc"
    break;

  case 169:
#line 737 "parser.yy"
      {
        es.assign();
        quads.importSolver(es); 
        expressionFlag = 0;

        string assign = var->name;
        es = ExpressionSolver(); 
        expressionFlag = 1;
        es.insertOprnd(assign);
}
#line 1528 "parser.tab.cc"
    break;

  case 170:
#line 746 "parser.yy"
     { es.insertOptr(11);}
#line 1534 "parser.tab.cc"
    break;

  case 171:
#line 746 "parser.yy"
                               {
        es.checkStacks();
        quads.importSolver(es); 
        expressionFlag = 0; 
        int lastDir = quads.getQuadLastDir();
        setJDir(lastDir);
        quads.insertQuad(201,quads.getLastQuad().result,-1,-1);
}
#line 1547 "parser.tab.cc"
    break;

  case 172:
#line 753 "parser.yy"
                          {
        string fid = getforID();
        es = ExpressionSolver(); 
        expressionFlag = 1;
        es.insertOprnd(fid);
        es.insertOptr(5);
        es.insertOprnd(fid);
        es.insertOptr(0);
        es.insertOprnd(1);
        es.checkStacks();
        es.assign();
        quads.importSolver(es); 
        expressionFlag = 0;

        int dir = getJDir();
        quads.insertQuad(200,-1,-1,dir-1);
        quads.updateQuadResult(dir,quads.getQuadLastDir());
}
#line 1570 "parser.tab.cc"
    break;


#line 1574 "parser.tab.cc"

            default:
              break;
            }
        }
#if YY_EXCEPTIONS
      catch (const syntax_error& yyexc)
        {
          YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
          error (yyexc);
          YYERROR;
        }
#endif // YY_EXCEPTIONS
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;
      YY_STACK_PRINT ();

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, YY_MOVE (yylhs));
    }
    goto yynewstate;


  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        error (yyla.location, yysyntax_error_ (yystack_[0].state, yyla));
      }


    yyerror_range[1].location = yyla.location;
    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.type_get () == yyeof_)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:
    /* Pacify compilers when the user code never invokes YYERROR and
       the label yyerrorlab therefore never appears in user code.  */
    if (false)
      YYERROR;

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    goto yyerrlab1;


  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    {
      stack_symbol_type error_token;
      for (;;)
        {
          yyn = yypact_[+yystack_[0].state];
          if (!yy_pact_value_is_default_ (yyn))
            {
              yyn += yy_error_token_;
              if (0 <= yyn && yyn <= yylast_ && yycheck_[yyn] == yy_error_token_)
                {
                  yyn = yytable_[yyn];
                  if (0 < yyn)
                    break;
                }
            }

          // Pop the current state because it cannot handle the error token.
          if (yystack_.size () == 1)
            YYABORT;

          yyerror_range[1].location = yystack_[0].location;
          yy_destroy_ ("Error: popping", yystack_[0]);
          yypop_ ();
          YY_STACK_PRINT ();
        }

      yyerror_range[2].location = yyla.location;
      YYLLOC_DEFAULT (error_token.location, yyerror_range, 2);

      // Shift the error token.
      error_token.state = state_type (yyn);
      yypush_ ("Shifting", YY_MOVE (error_token));
    }
    goto yynewstate;


  /*-------------------------------------.
  | yyacceptlab -- YYACCEPT comes here.  |
  `-------------------------------------*/
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;


  /*-----------------------------------.
  | yyabortlab -- YYABORT comes here.  |
  `-----------------------------------*/
  yyabortlab:
    yyresult = 1;
    goto yyreturn;


  /*-----------------------------------------------------.
  | yyreturn -- parsing is finished, return the result.  |
  `-----------------------------------------------------*/
  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
#if YY_EXCEPTIONS
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack\n";
        // Do not try to display the values of the reclaimed symbols,
        // as their printers might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
#endif // YY_EXCEPTIONS
  }

  void
  parser::error (const syntax_error& yyexc)
  {
    error (yyexc.location, yyexc.what ());
  }

  // Generate an error message.
  std::string
  parser::yysyntax_error_ (state_type yystate, const symbol_type& yyla) const
  {
    // Number of reported tokens (one for the "unexpected", one per
    // "expected").
    std::ptrdiff_t yycount = 0;
    // Its maximum.
    enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
    // Arguments of yyformat.
    char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];

    /* There are many possibilities here to consider:
       - If this state is a consistent state with a default action, then
         the only way this function was invoked is if the default action
         is an error action.  In that case, don't check for expected
         tokens because there are none.
       - The only way there can be no lookahead present (in yyla) is
         if this state is a consistent state with a default action.
         Thus, detecting the absence of a lookahead is sufficient to
         determine that there is no unexpected or expected token to
         report.  In that case, just report a simple "syntax error".
       - Don't assume there isn't a lookahead just because this state is
         a consistent state with a default action.  There might have
         been a previous inconsistent state, consistent state with a
         non-default action, or user semantic action that manipulated
         yyla.  (However, yyla is currently not documented for users.)
       - Of course, the expected token list depends on states to have
         correct lookahead information, and it depends on the parser not
         to perform extra reductions after fetching a lookahead from the
         scanner and before detecting a syntax error.  Thus, state merging
         (from LALR or IELR) and default reductions corrupt the expected
         token list.  However, the list is correct for canonical LR with
         one exception: it will still contain any token that will not be
         accepted due to an error action in a later state.
    */
    if (!yyla.empty ())
      {
        symbol_number_type yytoken = yyla.type_get ();
        yyarg[yycount++] = yytname_[yytoken];

        int yyn = yypact_[+yystate];
        if (!yy_pact_value_is_default_ (yyn))
          {
            /* Start YYX at -YYN if negative to avoid negative indexes in
               YYCHECK.  In other words, skip the first -YYN actions for
               this state because they are default actions.  */
            int yyxbegin = yyn < 0 ? -yyn : 0;
            // Stay within bounds of both yycheck and yytname.
            int yychecklim = yylast_ - yyn + 1;
            int yyxend = yychecklim < yyntokens_ ? yychecklim : yyntokens_;
            for (int yyx = yyxbegin; yyx < yyxend; ++yyx)
              if (yycheck_[yyx + yyn] == yyx && yyx != yy_error_token_
                  && !yy_table_value_is_error_ (yytable_[yyx + yyn]))
                {
                  if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                    {
                      yycount = 1;
                      break;
                    }
                  else
                    yyarg[yycount++] = yytname_[yyx];
                }
          }
      }

    char const* yyformat = YY_NULLPTR;
    switch (yycount)
      {
#define YYCASE_(N, S)                         \
        case N:                               \
          yyformat = S;                       \
        break
      default: // Avoid compiler warnings.
        YYCASE_ (0, YY_("syntax error"));
        YYCASE_ (1, YY_("syntax error, unexpected %s"));
        YYCASE_ (2, YY_("syntax error, unexpected %s, expecting %s"));
        YYCASE_ (3, YY_("syntax error, unexpected %s, expecting %s or %s"));
        YYCASE_ (4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
        YYCASE_ (5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
      }

    std::string yyres;
    // Argument number.
    std::ptrdiff_t yyi = 0;
    for (char const* yyp = yyformat; *yyp; ++yyp)
      if (yyp[0] == '%' && yyp[1] == 's' && yyi < yycount)
        {
          yyres += yytnamerr_ (yyarg[yyi++]);
          ++yyp;
        }
      else
        yyres += *yyp;
    return yyres;
  }


  const short parser::yypact_ninf_ = -232;

  const signed char parser::yytable_ninf_ = -118;

  const short
  parser::yypact_[] =
  {
      15,    -3,    53,  -232,  -232,  -232,    61,    30,    20,  -232,
    -232,  -232,    41,    40,    28,  -232,    78,    31,  -232,    57,
    -232,    69,  -232,  -232,  -232,  -232,  -232,  -232,    49,  -232,
      62,  -232,    71,    42,  -232,  -232,  -232,    64,    28,  -232,
      83,    79,   -12,    43,  -232,  -232,  -232,    13,    28,   109,
    -232,   125,  -232,    78,  -232,   122,  -232,  -232,  -232,  -232,
    -232,    82,    46,  -232,  -232,  -232,  -232,   120,   123,    28,
    -232,   129,    42,   132,   127,  -232,   130,    89,  -232,  -232,
    -232,    30,  -232,    87,  -232,   131,    13,   133,    39,  -232,
    -232,   128,  -232,  -232,  -232,  -232,  -232,  -232,   134,   135,
     136,   138,    94,   139,  -232,   137,   143,    39,    39,    39,
      39,    39,    39,    39,  -232,  -232,   144,    41,    12,    94,
    -232,  -232,  -232,  -232,   140,    32,   141,  -232,  -232,  -232,
    -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,   149,
     150,  -232,  -232,  -232,  -232,  -232,   156,    76,  -232,  -232,
      59,   152,     4,    12,    12,  -232,    94,  -232,   142,  -232,
    -232,   157,    12,    12,   -12,    39,    12,  -232,  -232,  -232,
    -232,  -232,  -232,  -232,    12,     0,   100,   158,  -232,  -232,
    -232,  -232,  -232,  -232,  -232,   163,   165,   159,   169,   161,
     162,    12,  -232,    94,  -232,  -232,    12,  -232,   171,  -232,
    -232,  -232,   168,   166,  -232,  -232,  -232,  -232,  -232,  -232,
    -232,  -232,  -232,  -232,    24,  -232,   174,   175,  -232,  -232,
    -232,  -232,  -232,  -232,  -232,   177,   180,   181,  -232,    35,
      12,    12,    12,    12,    12,   145,  -232,  -232,     4,  -232,
       4,   147,   146,   151,   183,  -232,  -232,   178,    89,  -232,
    -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,
    -232,  -232,  -232,   182,  -232,  -232,   184,   185,  -232,  -232,
    -232,   186,    12,  -232,  -232,    78,    12,    12,   145,  -232,
    -232,    39,    39,    12,    12,  -232,  -232,  -232,  -232,  -232,
    -232,   179,   188,  -232,  -232,   160,  -232,   153,   183,  -232,
    -232,  -232,   192,  -232,   194,    39,    39,   196,   199,  -232,
    -232
  };

  const unsigned char
  parser::yydefact_[] =
  {
       0,     0,     0,     2,     4,     1,     0,     3,     0,    41,
       5,    39,     3,     3,     0,    53,     3,     0,    51,     0,
       7,     0,    52,    69,    63,    64,    65,    45,     0,    68,
       0,    50,     3,     0,    54,    46,     6,     0,     0,    59,
       3,     0,     0,     0,     8,    11,    12,     0,     3,     0,
      42,     0,    58,     3,    49,     0,     9,    67,    66,    13,
      20,     0,     0,    14,    57,    56,    55,     0,     0,     3,
      48,     0,     0,     3,    16,    15,     0,     3,    62,    61,
      60,     3,    10,     0,    23,     0,     0,     0,     3,    77,
      80,     0,    40,    22,    21,    17,    19,    98,     0,     0,
       0,     0,     0,    70,    92,     0,     0,     3,     3,     3,
       3,     3,     3,     3,   115,   116,     3,     3,     3,     0,
     101,   109,   165,    70,     0,     3,     0,    93,    47,    85,
      86,    87,    88,    89,    90,    91,    24,    84,    83,     0,
       0,    30,   156,   157,   158,   154,     0,   126,   138,   145,
       0,     0,     3,     3,     3,   168,     0,    74,     3,    71,
      32,     0,     3,     3,     0,     3,     3,    99,   127,   129,
     130,   131,   132,   128,     3,     3,     3,    70,   164,   162,
     163,   161,   160,   155,   159,     0,   103,     0,   106,     0,
       0,     3,    72,     0,    76,    73,     3,    97,     0,    95,
      25,    78,     0,     0,   124,   140,   142,   144,   139,   147,
     149,   151,   153,   146,     0,   100,     0,     0,   107,   110,
     166,   169,    75,    33,    94,     3,     3,     0,    31,     3,
       3,     3,     3,     3,     3,     0,   120,   118,     3,   102,
       3,     0,     0,     0,     3,    27,    29,     0,     3,    82,
      79,    43,   133,   135,   137,   125,   141,   143,   148,   150,
     152,   117,   119,     3,   105,   108,     0,     0,   170,    35,
      38,     0,     3,    26,    81,     3,     3,     3,     0,   123,
     121,     3,     3,     3,     3,    34,    28,    44,   134,   136,
     122,     0,     0,   171,    36,     3,   167,     0,     3,   112,
     114,   111,     0,    37,     0,     3,     3,     0,     0,   172,
     113
  };

  const short
  parser::yypgoto_[] =
  {
    -232,  -232,    -7,  -232,  -232,  -232,   -30,  -232,   121,  -232,
    -232,   105,   119,  -232,  -232,  -232,  -232,  -232,    86,  -232,
    -232,  -232,  -232,  -232,  -232,    -2,  -232,  -232,   -84,  -232,
    -232,   148,  -232,   -52,  -232,  -232,  -232,  -232,  -232,  -232,
      96,   167,  -232,  -232,  -232,   155,  -232,   -40,    52,  -232,
     -85,  -232,  -232,  -232,   -31,  -232,  -232,  -232,  -232,   -97,
    -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,
    -182,  -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,  -231,
    -232,  -232,  -232,  -232,  -111,  -232,  -232,  -232,  -232,  -232,
    -171,  -232,  -232,  -232,  -232,  -104,  -232,  -232,  -232,  -232,
    -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,
    -232,  -232,  -232
  };

  const short
  parser::yydefgoto_[] =
  {
      -1,     2,   144,     3,     6,    12,    21,    33,    44,    72,
      45,    46,    63,    86,    87,    47,    73,    85,   138,   163,
     225,   247,   272,   145,   166,   161,   196,   244,   271,   284,
     298,    10,    13,    28,    68,   275,    36,    49,    55,    19,
      16,    22,    48,    66,    40,    52,    80,    29,    59,    30,
     105,   125,   159,   195,    91,   116,   226,   250,   139,   106,
     107,   162,   198,   108,   126,   109,   118,   110,   111,   152,
     187,   216,   240,   112,   153,   241,   301,   304,   113,   182,
     214,   237,   263,   280,   188,   229,   174,   255,   276,   277,
     147,   175,   208,   230,   231,   148,   176,   213,   232,   233,
     234,   149,   150,   183,   184,   114,   154,   242,   115,   191,
     243,   283,   297
  };

  const short
  parser::yytable_[] =
  {
       9,    70,    58,   204,   262,    15,    18,   146,    51,    27,
     129,   130,   131,   132,   133,   134,   135,   124,   141,    61,
     221,    62,    75,   205,   206,    39,   141,   142,   143,   235,
      24,    25,    26,    54,   151,   142,   143,   156,   160,    51,
      57,    64,   189,   190,   136,     1,    27,   290,    41,     4,
      42,   199,   200,     5,    43,   203,   264,   186,   265,   256,
     257,     8,    78,   252,   253,   181,    84,    32,   202,     7,
      90,   192,    11,    14,     9,    17,    34,    97,    98,    99,
      20,   104,    35,    31,   100,   223,   101,   102,    24,    25,
      26,   103,   168,   169,   170,   171,   172,   173,    60,    37,
     104,   104,   104,   104,   104,   104,   104,    38,   222,   137,
      15,   177,   293,   178,   179,   180,    50,    53,   157,    23,
      24,    25,    26,    67,    58,   209,   210,   211,   258,   259,
     260,    56,    69,    71,    74,    76,    81,    77,    83,   -18,
      88,    89,    93,   117,    94,    43,   123,   193,   119,   120,
     121,   194,   122,   -96,   128,   160,   136,   164,   104,   127,
     165,   286,   155,   167,   197,   288,   289,   185,   207,   212,
     215,  -104,  -117,   294,   217,   218,   219,   220,   224,   227,
     238,   228,   239,   245,   291,   292,   248,   278,   251,   269,
     295,   273,    96,    82,   281,   282,   267,   261,   266,   296,
     268,   285,   305,   302,   306,    95,   299,   309,   307,   308,
     310,   158,   236,   140,   303,    65,   201,   274,   246,   249,
       0,     0,   254,   287,    79,     0,     0,     0,     0,    92,
       0,     0,     0,     0,     0,     0,     0,   270,     0,     0,
       0,    90,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   279,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    27,     0,
       0,     0,     0,     0,   104,   104,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   300,     0,
       0,   270,     0,     0,     0,     0,     0,     0,   104,   104
  };

  const short
  parser::yycheck_[] =
  {
       7,    53,    42,   174,   235,    12,    13,   118,    38,    16,
     107,   108,   109,   110,   111,   112,   113,   102,    14,     6,
     191,     8,    62,    23,    24,    32,    14,    23,    24,     5,
      42,    43,    44,    40,   119,    23,    24,     5,    14,    69,
      52,    48,   153,   154,    12,    30,    53,   278,     6,    52,
       8,   162,   163,     0,    12,   166,   238,    53,   240,   230,
     231,    31,    69,    28,    29,   150,    73,    10,   165,     8,
      77,   156,    52,    32,    81,    35,     7,    38,    39,    40,
      52,    88,    33,    52,    45,   196,    47,    48,    42,    43,
      44,    52,    16,    17,    18,    19,    20,    21,    55,    37,
     107,   108,   109,   110,   111,   112,   113,    36,   193,   116,
     117,    52,   283,    54,    55,    56,    52,    34,   125,    41,
      42,    43,    44,    14,   164,    25,    26,    27,   232,   233,
     234,    52,     7,    11,    52,    15,     7,    14,     6,    12,
      10,    52,    55,    15,    13,    12,    52,     5,    14,    14,
      14,   158,    14,    14,    11,    14,    12,     8,   165,    22,
      10,   272,    22,     7,     7,   276,   277,    15,   175,   176,
       7,     6,    14,   284,    15,     6,    15,    15,     7,    11,
       6,    15,     7,     6,   281,   282,     6,     5,     7,     6,
      11,    13,    87,    72,    10,    10,    50,    52,    51,    11,
      49,    15,    10,    50,    10,    86,    46,    11,   305,   306,
      11,   125,   214,   117,   298,    48,   164,   248,   225,   226,
      -1,    -1,   229,   275,    69,    -1,    -1,    -1,    -1,    81,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   244,    -1,    -1,
      -1,   248,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   263,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   275,    -1,
      -1,    -1,    -1,    -1,   281,   282,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   295,    -1,
      -1,   298,    -1,    -1,    -1,    -1,    -1,    -1,   305,   306
  };

  const unsigned char
  parser::yystos_[] =
  {
       0,    30,    58,    60,    52,     0,    61,     8,    31,    59,
      88,    52,    62,    89,    32,    59,    97,    35,    59,    96,
      52,    63,    98,    41,    42,    43,    44,    59,    90,   104,
     106,    52,    10,    64,     7,    33,    93,    37,    36,    59,
     101,     6,     8,    12,    65,    67,    68,    72,    99,    94,
      52,    63,   102,    34,    59,    95,    52,    52,   104,   105,
      55,     6,     8,    69,    59,    98,   100,    14,    91,     7,
      90,    11,    66,    73,    52,   104,    15,    14,    59,   102,
     103,     7,    65,     6,    59,    74,    70,    71,    10,    52,
      59,   111,    88,    55,    13,    69,    68,    38,    39,    40,
      45,    47,    48,    52,    59,   107,   116,   117,   120,   122,
     124,   125,   130,   135,   162,   165,   112,    15,   123,    14,
      14,    14,    14,    52,   107,   108,   121,    22,    11,   116,
     116,   116,   116,   116,   116,   116,    12,    59,    75,   115,
      97,    14,    23,    24,    59,    80,   141,   147,   152,   158,
     159,   107,   126,   131,   163,    22,     5,    59,    75,   109,
      14,    82,   118,    76,     8,    10,    81,     7,    16,    17,
      18,    19,    20,    21,   143,   148,   153,    52,    54,    55,
      56,   107,   136,   160,   161,    15,    53,   127,   141,   141,
     141,   166,   107,     5,    59,   110,    83,     7,   119,   141,
     141,   105,   116,   141,   147,    23,    24,    59,   149,    25,
      26,    27,    59,   154,   137,     7,   128,    15,     6,    15,
      15,   147,   107,   141,     7,    77,   113,    11,    15,   142,
     150,   151,   155,   156,   157,     5,    82,   138,     6,     7,
     129,   132,   164,   167,    84,     6,    59,    78,     6,    59,
     114,     7,    28,    29,    59,   144,   147,   147,   152,   152,
     152,    52,   136,   139,   127,   127,    51,    50,    49,     6,
      59,    85,    79,    13,   111,    92,   145,   146,     5,    59,
     140,    10,    10,   168,    86,    15,   141,    90,   141,   141,
     136,   116,   116,   147,   141,    11,    11,   169,    87,    46,
      59,   133,    50,    85,   134,    10,    10,   116,   116,    11,
      11
  };

  const unsigned char
  parser::yyr1_[] =
  {
       0,    57,    58,    59,    61,    62,    60,    64,    63,    66,
      65,    65,    67,    67,    68,    69,    70,    69,    71,    69,
      73,    72,    74,    74,    76,    77,    75,    79,    78,    78,
      81,    80,    83,    84,    82,    86,    87,    85,    85,    89,
      88,    88,    91,    92,    90,    90,    94,    93,    95,    95,
      96,    96,    97,    97,    99,    98,   100,   100,   101,   101,
     102,   103,   103,   104,   104,   104,   105,   105,   106,   106,
     108,   107,   109,   109,   109,   110,   110,   112,   113,   111,
     111,   114,   114,   115,   115,   116,   116,   116,   116,   116,
     116,   116,   116,   118,   117,   119,   121,   120,   123,   122,
     124,   126,   125,   127,   128,   127,   127,   129,   127,   131,
     132,   130,   134,   133,   133,   135,   135,   137,   136,   138,
     139,   138,   140,   140,   142,   141,   141,   143,   143,   143,
     143,   143,   143,   145,   144,   146,   144,   144,   148,   147,
     150,   149,   151,   149,   149,   153,   152,   155,   154,   156,
     154,   157,   154,   154,   158,   158,   159,   159,   159,   160,
     160,   160,   161,   161,   161,   163,   164,   162,   166,   167,
     168,   169,   165
  };

  const signed char
  parser::yyr2_[] =
  {
       0,     2,     1,     0,     0,     0,     9,     0,     3,     0,
       4,     1,     1,     2,     2,     2,     0,     4,     0,     4,
       0,     5,     2,     1,     0,     0,     6,     0,     3,     1,
       0,     4,     0,     0,     6,     0,     0,     5,     1,     0,
      10,     1,     0,     0,    14,     1,     0,     7,     2,     1,
       2,     1,     2,     1,     0,     4,     1,     1,     2,     1,
       3,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       0,     3,     2,     2,     1,     2,     1,     0,     0,     7,
       1,     2,     1,     1,     1,     2,     2,     2,     2,     2,
       2,     2,     1,     0,     5,     1,     0,     4,     0,     4,
       5,     0,     6,     1,     0,     4,     1,     0,     4,     0,
       0,    11,     0,     5,     1,     1,     1,     0,     3,     2,
       0,     3,     2,     1,     0,     5,     1,     1,     1,     1,
       1,     1,     1,     0,     3,     0,     3,     1,     0,     3,
       0,     3,     0,     3,     1,     0,     3,     0,     3,     0,
       3,     0,     3,     1,     1,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     0,     0,    10,     0,     0,
       0,     0,    14
  };



  // YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
  // First, the terminals, then, starting at \a yyntokens_, nonterminals.
  const char*
  const parser::yytname_[] =
  {
  "\"eof\"", "error", "$undefined", "COMENTARIO", "SIMBOLO", "PUNTO",
  "COMA", "SCOL", "COL", "GBAJO", "LCUR", "RCUR", "LBRA", "RBRA", "LPAR",
  "RPAR", "EQ", "GE", "LE", "GT", "LT", "NE", "ASSIGN", "SUM", "RES",
  "MUL", "DIV", "MOD", "AND", "OR", "PROGRAMA", "CLASE", "VARIABLES",
  "MAIN", "METODOS", "HEREDA", "ATRIBUTOS", "FUNCION", "RETORNAR", "LEER",
  "ESCRIBIR", "VOID", "INT_T", "FLOAT_T", "CHAR_T", "SI", "SINO",
  "MIENTRAS", "PARA", "EN", "HACER", "ENTONCES", "ID", "STRING", "CHAR",
  "INT", "FLOAT", "$accept", "script", "empty", "program", "$@1", "$@2",
  "declare_var", "$@3", "declare_bridge1", "$@4", "declare_bridge2",
  "declare_bridge3", "declare_bridge4", "$@5", "$@6", "dimensionsdecl",
  "$@7", "matrixdecl", "dimensions", "$@8", "$@9", "matrix", "$@10",
  "single_express", "$@11", "mult_express", "$@12", "$@13",
  "expression_loop", "$@14", "$@15", "classes", "$@16", "functions",
  "$@17", "$@18", "main", "$@19", "methods", "inheritance", "variables",
  "var_bridge1", "$@20", "var_bridge2", "attributes", "attr_bridge1",
  "attr_bridge2", "primitive_type", "var_type", "return_type", "call_var",
  "$@21", "call_options", "call_cont", "parameters", "$@22", "$@23",
  "par_cont", "par_array", "statutes", "assignment", "$@24",
  "assignment_opt", "call_void", "$@25", "function_return", "$@26", "read",
  "write", "$@27", "write_expression_opt", "$@28", "$@29",
  "decision_statement", "$@30", "$@31", "dec_else", "$@32",
  "repetition_statement", "call_function", "$@33", "func_options", "$@34",
  "func_cont", "expression", "$@35", "relop", "express_loop", "$@36",
  "$@37", "exp", "$@38", "exp_loop", "$@39", "$@40", "term", "$@41",
  "term_loop", "$@42", "$@43", "$@44", "factor", "sign", "call", "var_cte",
  "conditional", "$@45", "$@46", "nonconditional", "$@47", "$@48", "$@49",
  "$@50", YY_NULLPTR
  };

#if YYDEBUG
  const short
  parser::yyrline_[] =
  {
       0,   143,   143,   146,   149,   149,   149,   153,   153,   154,
     154,   155,   156,   157,   158,   159,   160,   160,   161,   161,
     166,   166,   167,   168,   171,   191,   171,   242,   242,   273,
     278,   278,   297,   301,   297,   317,   321,   317,   337,   342,
     342,   343,   346,   357,   346,   361,   364,   364,   372,   373,
     376,   377,   382,   383,   386,   385,   401,   402,   409,   410,
     411,   412,   413,   418,   419,   420,   423,   423,   426,   426,
     429,   429,   442,   443,   444,   445,   446,   450,   451,   450,
     456,   458,   459,   461,   462,   466,   467,   468,   469,   470,
     471,   472,   473,   477,   476,   494,   497,   497,   510,   510,
     533,   536,   536,   537,   546,   546,   552,   565,   565,   579,
     579,   579,   591,   591,   600,   606,   606,   609,   609,   615,
     616,   616,   634,   635,   638,   638,   639,   640,   641,   642,
     643,   644,   645,   646,   646,   647,   647,   648,   651,   651,
     668,   668,   669,   669,   670,   673,   673,   690,   690,   691,
     691,   692,   692,   693,   696,   697,   698,   699,   700,   701,
     702,   703,   706,   707,   708,   711,   711,   711,   730,   737,
     746,   746,   730
  };

  // Print the state stack on the debug stream.
  void
  parser::yystack_print_ ()
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << int (i->state);
    *yycdebug_ << '\n';
  }

  // Report on the debug stream that the rule \a yyrule is going to be reduced.
  void
  parser::yy_reduce_print_ (int yyrule)
  {
    int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):\n";
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG


#line 6 "parser.yy"
} // yy
#line 2202 "parser.tab.cc"

#line 773 "parser.yy"

void yy::parser::error(const location_type& lugar, const std::string& lexema)
{
  std::cout << "SYNTAX ERROR !!! " << lexema << std::endl;
  throw CompilerError("SYNTAX ERROR !!! " + lexema);
}
