#include <string>
#include <vector>
#include <stack>
using namespace std;

//FLAGS VARS FUNCTIONS
int xreadFlag = 0;
int globalFlag = 0;
int expressionFlag = 0;
int paramsFlag = 0;

struct varDims{
    string id;
    int dim1 = 0;
    int dim2 = 0;
};

vector<struct varDims> currentIds;
int currentType = -1;
string currentFunction = "";

string currentId = "";

stack<int> jDir;

stack<string> forID;

void setforID(string dir){
    forID.push(dir);
}

string getforID(){
    string top = forID.top();
    forID.pop();
    return top;
}

void setJDir(int dir){
    jDir.push(dir);
}

int getJDir(){
    int top = jDir.top();
    jDir.pop();
    return top;
}

void setCurrentId(string id){
    currentId = id;
}

string getCurrentId(string id){
    return currentId;
}

void resetFlags(){
  xreadFlag = 0;
};
  

void resetID(){
    currentIds.clear();
    currentType = -1;
};

void setID(std::string id,int dim1, int dim2){
    struct varDims vari = varDims();
    vari.id = id;
    vari.dim1 = 0;
    vari.dim2 = 0;
    currentIds.push_back(vari);
};

void setCurrentType(int type){
    currentType = type;
}

void resetCurrentType(){
    currentType = -1;
}

void setCurrentFunction(string id){
    currentFunction = id;
}

void resetCurrentFunction(){
    currentFunction = "";
}
