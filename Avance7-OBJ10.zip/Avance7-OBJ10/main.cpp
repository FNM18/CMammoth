#include <stdio.h>
#include "driver.h"
#include <stack>
#include <vector>
#include "VMachine.cpp"
using namespace std;


int main(){
  //Analizador sintactico
  parser_driver driver;
  if(!driver.parse("test.txt"))  
   printf("\nInput Accepted\n\n");
  
  VMachine vm = VMachine();
  cout << "Runtime" << endl << endl;
  vm.executeFunctions(0);
  
}
