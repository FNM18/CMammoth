#!/bin/bash

bison -d parser.yy
flex lexer.l
c++ main.cpp Scanner.cpp driver.cpp parser.tab.cc semantic.cpp
./a.out