#include "driver.h"
#include "semantic.cpp"
#include <stack>
#include <vector>
#include <cstdlib>
#include <iostream>
using namespace std;

class VMachine;

static vector<FunctionTable::symbolRow *> funcs;

class Function{
    public:

        int functionId = -1;
        int * localInts;
        float * localFloats;
        char * localChars;
        int params = 0;
        int quadDir = -1;
        
        Function(int quadDr,int id, int paramCount, int intsV, int floatsV, int charsV){
            functionId = id;
            quadDir = quadDr;
            params = paramCount;
            localInts = new int[intsV];
            localFloats = new float[floatsV];
            localChars = new char[charsV];
        }

        void deleteMemory(){
            delete localInts;
            delete localFloats;
            delete localChars;
        }

        int getIntVar(int dir){
            return localInts[dir - 10001];
        }

        float getFloatVar(int dir){
            return localFloats[dir - 16001];
        }

        char getCharVar(int dir){
            return localChars[dir - 19001];
        }

        void setIntVar(int dir, int value){
            localInts[dir - 10001] = value;
        }

        void setFloatVar(int dir, float value){
            localFloats[dir - 16001] = value;
        }

        void setCharVar(int dir, char value){
            localChars[dir - 19001] = value;
        }

        void insertParam(int dir, int value){
            setIntVar(dir,value);
        }

        void insertParam(int dir, float value){
            setFloatVar(dir,value);
        }

        void insertParam(int dir, char value){
            setCharVar(dir,value);
        }
};

class VMachine{
    public:

        int quadSize = 0;
        //int quadCount = 0;
        int global = 1;
        vector<Quad::quadruple> quadList;
        unordered_map<int,int> globalInts;
        unordered_map<int,float> globalFloats;
        unordered_map<int,char> globalChars;
        unordered_map<int,int> pointers;

        unordered_map<int,int> constantInts;
        unordered_map<int,float> constantFloats;
        unordered_map<int,char> constantChars;
        unordered_map<int,string> constantStrings;

        stack<Function> functions;
        stack<Function> tempfunctions;

        VMachine(){
            quadList = quads.quadList;
            quadSize = quadList.size();
            importConstants();
            importGlobalVars();
            funcs = scope.functions;
        }

        void importConstants(){
            unordered_map<int, int>::iterator it = scope.cte_ints.begin();
            
            while(it != scope.cte_ints.end())
            {
                //cout << it->first << " :: "<< it->second << endl;
                constantInts[it->second] = it->first;
                it++;
            }

            unordered_map<float, int>::iterator it2 = scope.cte_floats.begin();
            
            while(it2 != scope.cte_floats.end())
            {
                //cout << it2->first << " :: "<< it2->second << endl;
                constantFloats[it2->second] = it2->first;
                it2++;
            }

            unordered_map<char, int>::iterator it3 = scope.cte_chars.begin();
            
            while(it3 != scope.cte_chars.end())
            {
                //cout << it3->first << " :: "<< it3->second << endl;
                constantChars[it3->second] = it3->first;
                it3++;
            }

            unordered_map<string, int>::iterator it4 = scope.cte_strings.begin();
            
            while(it4 != scope.cte_strings.end())
            {
                //cout << it4->first << " :: "<< it4->second << endl;
                constantStrings[it4->second] = it4->first;
                it4++;
            }
        }

        void importGlobalVars(){
            unordered_map<int,VarTable::symbolRow*> list = scope.getGlobalVariableList();

            unordered_map<int,VarTable::symbolRow*>::iterator it = list.begin();
            
            while(it != list.end())
            {
                cout << it->first << " :: "<< it->second->type << endl;
                if(it->first>=40000){
                    pointers[it->first] = 0;
                }else{
                    if(it->second->type == 0){
                        globalInts[it->first] = 0;
                    }else if(it->second->type == 1){
                        globalFloats[it->first] = 0.0;
                    }else if(it->second->type == 2){
                        globalChars[it->first] = '\0';
                    }
                }
                it++;
            }

        }

        int getType(int dir){
            if(dir<6001){
                return 0; // Global int 
            }else if(dir<9001){
                return 1; // Global float
            }else if(dir<10001){
                return 2; // Global char
            }else if(dir<16001){
                return 3; // Local int
            }else if(dir<19001){
                return 4; // Local float
            }else if(dir<20001){
                return 5; // Local char
            }else if(dir<26001){
                return 6; // Constant int
            }else if(dir<29001){
                return 7; // Constant float
            }else if(dir<30001){
                return 8; // Constant char
            }else if(dir<31001){
                return 9; // Constant strings
            }else if(dir>=40000){
                return 10;
            }
            return -1;
        }

        int getPointer(int dir){
            return pointers[dir];
        }

        int getIntVar(int dir){
            if(!global && dir>10000 && dir<20001)
                return functions.top().getIntVar(dir);

            if(dir>20000 && dir < 40000)
                return constantInts[dir];
            return globalInts[dir];
        }

        float getFloatVar(int dir){
            if(!global && dir>10000 && dir<20001)
                return functions.top().getFloatVar(dir);

            if(dir>20000 && dir < 40000)
                return constantFloats[dir];
            return globalFloats[dir];
        }

        char getCharVar(int dir){
            if(!global && dir>10000 && dir<20001)
                return functions.top().getCharVar(dir);

            if(dir>20000 && dir < 40000)
                return constantChars[dir];
            return globalChars[dir];
        }

        string getStringVar(int dir){
            if(dir>30000)
                return constantStrings[dir];
            return constantStrings[dir];
        }

        void setPointer(int dir, int value){
            pointers[dir] = value;
        }

        void setIntVar(int dir, int value){
            if(!global && dir>10000 && dir<20001)
                functions.top().setIntVar(dir,value);
            else
                globalInts[dir] = value;
        }

        void setFloatVar(int dir, float value){
            if(!global && dir>10000 && dir<20001)
                functions.top().setFloatVar(dir,value);
            else
                globalFloats[dir] = value;
        }

        void setCharVar(int dir, char value){
            if(!global && dir>10000 && dir<20001)
                functions.top().setCharVar(dir,value);
            else
                globalChars[dir] = value;
        }

        int arithmeticIntOperator(int a, int b, int op){
            switch(op){
                case 0:
                    return a + b;
                case 1:
                    return a - b;
                case 2:
                    return a * b;
                case 3:
                    return a / b;
                case 4:
                    return a % b;
                default:
                    throw runtime_error("Arithmetic Operator Error.");
            } 
        }

        float arithmeticFloatOperator(float a, float b, int op){
            switch(op){
                case 0:
                    return a + b;
                case 1:
                    return a - b;
                case 2:
                    return a * b;
                case 3:
                    return a / b;
                default:
                    throw runtime_error("Arithmetic Operator Error.");
            } 
        }

        void arithmeticFunction(const Quad::quadruple quad){
            int typeRes = getType(quad.result);
            int typeLeft = getType(quad.operandLeft);
            int typeRight = getType(quad.operandRight);
            int assigniLeft;
            int assigniRight;
            float assignfLeft;
            float assignfRight;
            Quad::quadruple quadMod = quad;
            if(typeLeft == 10){
                quadMod.operandLeft = getPointer(quad.operandLeft);
                typeLeft = getType(quadMod.operandLeft);
            }
            if(typeRight == 10){
                quadMod.operandRight = getPointer(quad.operandRight);
                typeRight = getType(quadMod.operandRight);
            }
            if(typeRes == 10){
                quadMod.result = getPointer(quad.result);
                typeRes = getType(quadMod.result);
            }
            if(typeLeft == 0 || typeLeft == 6 || typeLeft == 3){
                assigniLeft = getIntVar(quadMod.operandLeft);
                assignfLeft = assigniLeft;
            } else if(typeLeft == 1 || typeLeft == 7 || typeLeft == 4){
                assignfLeft = getFloatVar(quadMod.operandLeft);
            }
            if(typeRight == 0 || typeRight == 6 || typeRight == 3){
                assigniRight = getIntVar(quadMod.operandRight);
                assignfRight = assigniRight;
            } else if(typeRight == 1 || typeRight == 7 || typeRight == 4){
                assignfRight = getFloatVar(quadMod.operandRight);
            } 

            if(typeRes==3){
                setIntVar(quad.result,arithmeticIntOperator(assigniLeft,assigniRight,quad.op));
            } else if(typeRes==4){
                setFloatVar(quad.result,arithmeticFloatOperator(assignfLeft,assignfRight,quad.op));
            } 
        }

        

        void compareFunction(const Quad::quadruple quad){
            int typeRes = getType(quad.result);
            int typeLeft = getType(quad.operandLeft);
            int typeRight = getType(quad.operandRight);
            int assigniLeft;
            int assigniRight;
            float assignfLeft;
            float assignfRight;
            Quad::quadruple quadMod = quad;
            if(typeLeft == 10){
                quadMod.operandLeft = getPointer(quad.operandLeft);
                typeLeft = getType(quadMod.operandLeft);
            }
            if(typeRight == 10){
                quadMod.operandRight = getPointer(quad.operandRight);
                typeRight = getType(quadMod.operandRight);
            }
            if(typeRes == 10){
                quadMod.result = getPointer(quad.result);
                typeRes = getType(quadMod.result);
            }

            if(typeLeft == 0 || typeLeft == 6 || typeLeft == 3){
                assigniLeft = getIntVar(quadMod.operandLeft);
                assignfLeft = assigniLeft;
            } else if(typeLeft == 1 || typeLeft == 7 || typeLeft == 4){
                assignfLeft = getFloatVar(quadMod.operandLeft);
            }
            if(typeRight == 0 || typeRight == 6 || typeRight == 3){
                assigniRight = getIntVar(quadMod.operandRight);
                assignfRight = assigniRight;
            } else if(typeRight == 1 || typeRight == 7 || typeRight == 4){
                assignfRight = getFloatVar(quadMod.operandRight);
            }
            switch(quadMod.op){
                case 6:
                    //cout << assignfLeft << " == " << assignfRight << endl;
                    setIntVar(quadMod.result,assignfLeft == assignfRight);
                break;
                case 7:
                    //cout << assignfLeft << " != " << assignfRight << endl;
                    setIntVar(quadMod.result,assignfLeft != assignfRight);
                break;
                case 8:
                    //cout << assignfLeft << " > " << assignfRight << endl;
                    setIntVar(quadMod.result,assignfLeft > assignfRight);
                break;
                case 9:
                    //cout << assignfLeft << " < " << assignfRight << endl;
                    setIntVar(quadMod.result,assignfLeft < assignfRight);
                break;
                case 10:
                    //cout << assignfLeft << " >= " << assignfRight << endl;
                    setIntVar(quadMod.result,assignfLeft >= assignfRight);
                break;
                case 11:
                    //cout << assignfLeft << " <= " << assignfRight << endl;
                    setIntVar(quadMod.result,assignfLeft <= assignfRight);
                break;
                case 12:
                    //cout << assigniLeft << " && " << assigniRight << endl;
                    setIntVar(quadMod.result,assigniLeft && assigniRight);
                break;
                case 13:
                    //cout << assigniLeft << " || " << assigniRight << endl;
                    setIntVar(quadMod.result,assigniLeft || assigniRight);
                break;
                default:
                break;
            } 
        }

        void assignFunction(const Quad::quadruple quad){
            int typeRes = getType(quad.result);
            int typeLeft = getType(quad.operandLeft);
            int assigni;
            float assignf;
            char assignc;
            Quad::quadruple quadMod = quad;
            if(typeLeft == 10){
                quadMod.operandLeft = getPointer(quad.operandLeft);
                typeLeft = getType(quadMod.operandLeft);
            }
            if(typeRes == 10){
                quadMod.result = getPointer(quad.result);
                typeRes = getType(quadMod.result);
            }
            if(typeLeft == 0 || typeLeft == 6 || typeLeft == 3){
                assigni = getIntVar(quadMod.operandLeft);
            } else if(typeLeft == 1 || typeLeft == 7 || typeLeft == 4){
                assignf = getFloatVar(quadMod.operandLeft);
            } else if(typeLeft == 2 || typeLeft == 8 || typeLeft == 5){
                assignc = getCharVar(quadMod.operandLeft);
            }

            if(typeRes==0 || typeRes==3 || typeRes==6){
                setIntVar(quadMod.result,assigni);
            } else if(typeRes==1 || typeRes==4 || typeRes==7){
                setFloatVar(quadMod.result,assignf);
            } else if(typeRes==2 || typeRes==5 || typeRes==8){
                setCharVar(quadMod.result,assignc);
            }
        }

        void readFunction(const Quad::quadruple quad){
            int typeRes = getType(quad.result);
            Quad::quadruple quadMod = quad;
            if(typeRes == 10){
                quadMod.result = getPointer(quad.result);
                typeRes = getType(quadMod.result);
            }
            if(typeRes == 0){
                int read;
                cin >> read;
                setIntVar(quadMod.result,read);
            }else if(typeRes == 1){
                float read;
                cin >> read;
                setFloatVar(quadMod.result,read);
            }else if(typeRes == 2){
                char read;
                cin >> read;
                setCharVar(quadMod.result,read);
            }
        }

        void writeFunction(const Quad::quadruple quad){
            int typeLeft = getType(quad.operandLeft);
            Quad::quadruple quadMod = quad;
            if(typeLeft == 10){
                quadMod.operandLeft = getPointer(quad.operandLeft);
                typeLeft = getType(quadMod.operandLeft);
            }
            if(typeLeft == 0 || typeLeft == 6 || typeLeft == 3){
                cout << getIntVar(quadMod.operandLeft)<< " ";
            } else if(typeLeft == 1 || typeLeft == 7 || typeLeft == 4){
                cout << getFloatVar(quadMod.operandLeft)<< " ";
            } else if(typeLeft == 2 || typeLeft == 8 || typeLeft == 5){
                cout << getCharVar(quadMod.operandLeft)<< " ";
            }else if(typeLeft == 9){
                string text =  getStringVar(quadMod.operandLeft);
                cout << (text == "\n" ? text: text + " ");
            }
        }

        int gotoFunction(const Quad::quadruple quad){
            return quad.result;
        }

        int gotoFalseFunction(const Quad::quadruple quad, int currentQuad){
            return getIntVar(quad.operandLeft) ? currentQuad : quad.result;
        }

        void era(const Quad::quadruple quad){
            int id = quad.operandLeft;
            Function f = Function(funcs[id]->quadDir,
                    id,funcs[id]->parameters.size(),
                    funcs[id]->ints,
                    funcs[id]->floats,
                    funcs[id]->chars);
            tempfunctions.push(f);
        }

        void param(const Quad::quadruple quad){
            Function f = tempfunctions.top();
            int dir = funcs[f.functionId]->parameters[quad.result-1].dir;
            int type = funcs[f.functionId]->parameters[quad.result-1].type;
            if(type == 0){
                int val = getIntVar(quad.operandLeft);     
                f.insertParam(dir,val);
            }else if(type == 1){
                float val = getFloatVar(quad.operandLeft);    
                f.insertParam(dir,val);
            }else if(type == 2){
                char val = getCharVar(quad.operandLeft);    
                f.insertParam(dir,val);
            }
        }

        void goSub(const Quad::quadruple quad){
            functions.push(tempfunctions.top());
            tempfunctions.pop();
            global = 0;
            executeFunctions(functions.top().quadDir);
            functions.top().deleteMemory();
            functions.pop();
            if(functions.size() < 1){
                global = 1;
            }
        }

        void ver(const Quad::quadruple quad){
            int typeLeft = getType(quad.operandLeft);
            int assigni;
            float assignf;
            char assignc;
            Quad::quadruple quadMod = quad;
            if(typeLeft == 10){
                quadMod.operandLeft = getPointer(quad.operandLeft);
                typeLeft = getType(quadMod.operandLeft);
            }
            if(typeLeft == 0 || typeLeft == 6 || typeLeft == 3){
                assigni = getIntVar(quadMod.operandLeft);
                if(assigni >= quadMod.result)
                    throw runtime_error("Error: Index out of bounds.");
            } else if(typeLeft == 1 || typeLeft == 7 || typeLeft == 4){
                assignf = getFloatVar(quadMod.operandLeft);
                if(assignf >= quadMod.result)
                    throw runtime_error("Error: Index out of bounds.");
            } else if(typeLeft == 2 || typeLeft == 8 || typeLeft == 5){
                assignc = getCharVar(quadMod.operandLeft);
                if(assignc >= quadMod.result)
                    throw runtime_error("Error: Index out of bounds.");
            }
        }
        
        void multPointer(const Quad::quadruple quad){
            int typeRes = getType(quad.result);
            int typeLeft = getType(quad.operandLeft);
            int assigni;
            float assignf;
            char assignc;
            Quad::quadruple quadMod = quad;
            if(typeLeft == 10){
                quadMod.operandLeft = getPointer(quad.operandLeft);
                typeLeft = getType(quadMod.operandLeft);
            }
            if(typeLeft == 0 || typeLeft == 6 || typeLeft == 3){
                assigni = getIntVar(quadMod.operandLeft);
                assigni *= quadMod.operandRight;
            } else {
                throw runtime_error("Error: parameter must be an integer.");
            }

            if(typeRes==0 || typeRes==3 || typeRes==6){
                //cout << "Valor de param 1: " << assigni << endl;
                setIntVar(quadMod.result,assigni);
            } else{
                throw runtime_error("Error: parameter must be an integer.");
            }
        }

        void sumPointer(const Quad::quadruple quad){
            int typeRes = getType(quad.result);
            int typeLeft = getType(quad.operandLeft);
            int assigni;
            float assignf;
            char assignc;
            Quad::quadruple quadMod = quad;
            if(typeLeft == 10){
                quadMod.operandLeft = getPointer(quad.operandLeft);
                typeLeft = getType(quadMod.operandLeft);
            }
            if(typeLeft == 0 || typeLeft == 6 || typeLeft == 3){
                assigni = getIntVar(quadMod.operandLeft);
                assigni += getIntVar(quadMod.operandRight);
            } else{
                throw runtime_error("Se rompe.");
            }

            if(typeRes==10){
                //cout << "Valor de param 2: " << assigni << endl;
                setPointer(quadMod.result,assigni);
            } 
        }

        void returnState(const Quad::quadruple quad){
            assignFunction(quad);
        }

        int executeFunctions(int startCount){
            int quadCount = startCount;
            //cout<<"StartCount"<<endl;
            while (quadCount < quadSize)
            {
                //cout<<"PROC "<< functions.size()<< "-" <<quadCount << " - Estat: " << quadList[quadCount].op<< endl;
                switch (quadList[quadCount].op)
                {
                case 0 ... 4:
                    arithmeticFunction(quadList[quadCount]);
                    break;
                case 5:
                    assignFunction(quadList[quadCount]);
                    break;
                case 6 ... 13:
                    compareFunction(quadList[quadCount]);
                    break;
                case 102:
                    writeFunction(quadList[quadCount]);
                    break;
                case 103:
                    readFunction(quadList[quadCount]);
                    break;
                case 200:
                    quadCount = gotoFunction(quadList[quadCount])-1;
                    break;
                case 201:
                    quadCount = gotoFalseFunction(quadList[quadCount],quadCount+1)-1;
                    break;
                case 202:
                    era(quadList[quadCount]);
                    break;
                case 203:
                    param(quadList[quadCount]);
                    break;
                case 204:
                    goSub(quadList[quadCount]);
                    break;
                case 205:
                    ver(quadList[quadCount]);
                    break;
                case 206:
                    multPointer(quadList[quadCount]);
                    break;
                case 207:
                    sumPointer(quadList[quadCount]);
                    break;
                case 298:
                    returnState(quadList[quadCount]);
                    return 0;
                    break;
                case 299:
                    return 0;
                    break;
                case 999:
                    return 0;
                    break;
                default:
                    //cout<<"Estatuto "<<quadList[quadCount].op << " - en proceso..." << endl;
                    break;
                }
                quadCount++;
            }
            return 0;
            
        }
};