// A Bison parser, made by GNU Bison 3.5.1.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2020 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// Undocumented macros, especially those whose name start with YY_,
// are private implementation details.  Do not rely on them.





#include "parser.tab.hh"


// Unqualified %code blocks.
#line 22 "parser.yy"

#include "driver.h"
#include "flags.h"
#include "semantic.cpp"
#include <iostream>
#include <vector>

Scope scope = Scope();
int tempCount = 0;
ExpressionSolver es;
Quad quads = Quad();
VarTable::symbolRow * var = NULL;

#line 59 "parser.tab.cc"


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

// Whether we are compiled with exception support.
#ifndef YY_EXCEPTIONS
# if defined __GNUC__ && !defined __EXCEPTIONS
#  define YY_EXCEPTIONS 0
# else
#  define YY_EXCEPTIONS 1
# endif
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K].location)
/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

# ifndef YYLLOC_DEFAULT
#  define YYLLOC_DEFAULT(Current, Rhs, N)                               \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).begin  = YYRHSLOC (Rhs, 1).begin;                   \
          (Current).end    = YYRHSLOC (Rhs, N).end;                     \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).begin = (Current).end = YYRHSLOC (Rhs, 0).end;      \
        }                                                               \
    while (false)
# endif


// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << '\n';                       \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yystack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YYUSE (Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void> (0)
# define YY_STACK_PRINT()                static_cast<void> (0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)

#line 6 "parser.yy"
namespace yy {
#line 151 "parser.tab.cc"


  /* Return YYSTR after stripping away unnecessary quotes and
     backslashes, so that it's suitable for yyerror.  The heuristic is
     that double-quoting is unnecessary unless the string contains an
     apostrophe, a comma, or backslash (other than backslash-backslash).
     YYSTR is taken from yytname.  */
  std::string
  parser::yytnamerr_ (const char *yystr)
  {
    if (*yystr == '"')
      {
        std::string yyr;
        char const *yyp = yystr;

        for (;;)
          switch (*++yyp)
            {
            case '\'':
            case ',':
              goto do_not_strip_quotes;

            case '\\':
              if (*++yyp != '\\')
                goto do_not_strip_quotes;
              else
                goto append;

            append:
            default:
              yyr += *yyp;
              break;

            case '"':
              return yyr;
            }
      do_not_strip_quotes: ;
      }

    return yystr;
  }


  /// Build a parser object.
  parser::parser (parser_driver& driver_yyarg)
#if YYDEBUG
    : yydebug_ (false),
      yycdebug_ (&std::cerr),
#else
    :
#endif
      driver (driver_yyarg)
  {}

  parser::~parser ()
  {}

  parser::syntax_error::~syntax_error () YY_NOEXCEPT YY_NOTHROW
  {}

  /*---------------.
  | Symbol types.  |
  `---------------*/



  // by_state.
  parser::by_state::by_state () YY_NOEXCEPT
    : state (empty_state)
  {}

  parser::by_state::by_state (const by_state& that) YY_NOEXCEPT
    : state (that.state)
  {}

  void
  parser::by_state::clear () YY_NOEXCEPT
  {
    state = empty_state;
  }

  void
  parser::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  parser::by_state::by_state (state_type s) YY_NOEXCEPT
    : state (s)
  {}

  parser::symbol_number_type
  parser::by_state::type_get () const YY_NOEXCEPT
  {
    if (state == empty_state)
      return empty_symbol;
    else
      return yystos_[+state];
  }

  parser::stack_symbol_type::stack_symbol_type ()
  {}

  parser::stack_symbol_type::stack_symbol_type (YY_RVREF (stack_symbol_type) that)
    : super_type (YY_MOVE (that.state), YY_MOVE (that.location))
  {
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.YY_MOVE_OR_COPY< char > (YY_MOVE (that.value));
        break;

      case 55: // INT
      case 56: // FLOAT
        value.YY_MOVE_OR_COPY< float > (YY_MOVE (that.value));
        break;

      case 52: // ID
      case 53: // STRING
        value.YY_MOVE_OR_COPY< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

#if 201103L <= YY_CPLUSPLUS
    // that is emptied.
    that.state = empty_state;
#endif
  }

  parser::stack_symbol_type::stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) that)
    : super_type (s, YY_MOVE (that.location))
  {
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.move< char > (YY_MOVE (that.value));
        break;

      case 55: // INT
      case 56: // FLOAT
        value.move< float > (YY_MOVE (that.value));
        break;

      case 52: // ID
      case 53: // STRING
        value.move< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

    // that is emptied.
    that.type = empty_symbol;
  }

#if YY_CPLUSPLUS < 201103L
  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.copy< char > (that.value);
        break;

      case 55: // INT
      case 56: // FLOAT
        value.copy< float > (that.value);
        break;

      case 52: // ID
      case 53: // STRING
        value.copy< std::string > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    return *this;
  }

  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (stack_symbol_type& that)
  {
    state = that.state;
    switch (that.type_get ())
    {
      case 54: // CHAR
        value.move< char > (that.value);
        break;

      case 55: // INT
      case 56: // FLOAT
        value.move< float > (that.value);
        break;

      case 52: // ID
      case 53: // STRING
        value.move< std::string > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    // that is emptied.
    that.state = empty_state;
    return *this;
  }
#endif

  template <typename Base>
  void
  parser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);
  }

#if YYDEBUG
  template <typename Base>
  void
  parser::yy_print_ (std::ostream& yyo,
                                     const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YYUSE (yyoutput);
    symbol_number_type yytype = yysym.type_get ();
#if defined __GNUC__ && ! defined __clang__ && ! defined __ICC && __GNUC__ * 100 + __GNUC_MINOR__ <= 408
    // Avoid a (spurious) G++ 4.8 warning about "array subscript is
    // below array bounds".
    if (yysym.empty ())
      std::abort ();
#endif
    yyo << (yytype < yyntokens_ ? "token" : "nterm")
        << ' ' << yytname_[yytype] << " ("
        << yysym.location << ": ";
    switch (yytype)
    {
      case 52: // ID
#line 131 "parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 403 "parser.tab.cc"
        break;

      case 53: // STRING
#line 131 "parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 409 "parser.tab.cc"
        break;

      case 54: // CHAR
#line 131 "parser.yy"
                 { yyoutput << yysym.value.template as < char > (); }
#line 415 "parser.tab.cc"
        break;

      case 55: // INT
#line 131 "parser.yy"
                 { yyoutput << yysym.value.template as < float > (); }
#line 421 "parser.tab.cc"
        break;

      case 56: // FLOAT
#line 131 "parser.yy"
                 { yyoutput << yysym.value.template as < float > (); }
#line 427 "parser.tab.cc"
        break;

      default:
        break;
    }
    yyo << ')';
  }
#endif

  void
  parser::yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym)
  {
    if (m)
      YY_SYMBOL_PRINT (m, sym);
    yystack_.push (YY_MOVE (sym));
  }

  void
  parser::yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym)
  {
#if 201103L <= YY_CPLUSPLUS
    yypush_ (m, stack_symbol_type (s, std::move (sym)));
#else
    stack_symbol_type ss (s, sym);
    yypush_ (m, ss);
#endif
  }

  void
  parser::yypop_ (int n)
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  parser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  parser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  parser::debug_level_type
  parser::debug_level () const
  {
    return yydebug_;
  }

  void
  parser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  parser::state_type
  parser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - yyntokens_] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - yyntokens_];
  }

  bool
  parser::yy_pact_value_is_default_ (int yyvalue)
  {
    return yyvalue == yypact_ninf_;
  }

  bool
  parser::yy_table_value_is_error_ (int yyvalue)
  {
    return yyvalue == yytable_ninf_;
  }

  int
  parser::operator() ()
  {
    return parse ();
  }

  int
  parser::parse ()
  {
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The locations where the error started and ended.
    stack_symbol_type yyerror_range[3];

    /// The return value of parse ().
    int yyresult;

#if YY_EXCEPTIONS
    try
#endif // YY_EXCEPTIONS
      {
    YYCDEBUG << "Starting parse\n";


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, YY_MOVE (yyla));

  /*-----------------------------------------------.
  | yynewstate -- push a new symbol on the stack.  |
  `-----------------------------------------------*/
  yynewstate:
    YYCDEBUG << "Entering state " << int (yystack_[0].state) << '\n';

    // Accept?
    if (yystack_[0].state == yyfinal_)
      YYACCEPT;

    goto yybackup;


  /*-----------.
  | yybackup.  |
  `-----------*/
  yybackup:
    // Try to take a decision without lookahead.
    yyn = yypact_[+yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token: ";
#if YY_EXCEPTIONS
        try
#endif // YY_EXCEPTIONS
          {
            symbol_type yylookahead (yylex (driver));
            yyla.move (yylookahead);
          }
#if YY_EXCEPTIONS
        catch (const syntax_error& yyexc)
          {
            YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
            error (yyexc);
            goto yyerrlab1;
          }
#endif // YY_EXCEPTIONS
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.type_get ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.type_get ())
      {
        goto yydefault;
      }

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", state_type (yyn), YY_MOVE (yyla));
    goto yynewstate;


  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[+yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;


  /*-----------------------------.
  | yyreduce -- do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_ (yystack_[yylen].state, yyr1_[yyn]);
      /* Variants are always initialized to an empty instance of the
         correct type. The default '$$ = $1' action is NOT applied
         when using variants.  */
      switch (yyr1_[yyn])
    {
      case 54: // CHAR
        yylhs.value.emplace< char > ();
        break;

      case 55: // INT
      case 56: // FLOAT
        yylhs.value.emplace< float > ();
        break;

      case 52: // ID
      case 53: // STRING
        yylhs.value.emplace< std::string > ();
        break;

      default:
        break;
    }


      // Default location.
      {
        stack_type::slice range (yystack_, yylen);
        YYLLOC_DEFAULT (yylhs.location, range, yylen);
        yyerror_range[1].location = yylhs.location;
      }

      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
#if YY_EXCEPTIONS
      try
#endif // YY_EXCEPTIONS
        {
          switch (yyn)
            {
  case 4:
#line 142 "parser.yy"
                      {quads.prepareMainQuad();}
#line 682 "parser.tab.cc"
    break;

  case 5:
#line 142 "parser.yy"
                                                             {globalFlag = 1;}
#line 688 "parser.tab.cc"
    break;

  case 7:
#line 146 "parser.yy"
                 {setID(yystack_[0].value.as < std::string > ());}
#line 694 "parser.tab.cc"
    break;

  case 9:
#line 147 "parser.yy"
                          {setID(yystack_[0].value.as < std::string > ());}
#line 700 "parser.tab.cc"
    break;

  case 16:
#line 153 "parser.yy"
                          {setID(yystack_[0].value.as < std::string > ());}
#line 706 "parser.tab.cc"
    break;

  case 18:
#line 154 "parser.yy"
                          {setID(yystack_[0].value.as < std::string > ());}
#line 712 "parser.tab.cc"
    break;

  case 23:
#line 166 "parser.yy"
                     {if(expressionFlag){es.installPar();}}
#line 718 "parser.tab.cc"
    break;

  case 24:
#line 166 "parser.yy"
                                                                            {if(expressionFlag){es.closePar();}}
#line 724 "parser.tab.cc"
    break;

  case 28:
#line 176 "parser.yy"
                   {cout << "Clase id : " << yystack_[0].value.as < std::string > () << endl;}
#line 730 "parser.tab.cc"
    break;

  case 31:
#line 180 "parser.yy"
                                   {
        setCurrentFunction(yystack_[0].value.as < std::string > ());
        scope.globalInsertFunction(yystack_[0].value.as < std::string > (),currentType,"function",quads.getQuadLastDir());
        scope.setFunctionScope(yystack_[0].value.as < std::string > ());
        scope.installFunctionVars(yystack_[0].value.as < std::string > ());
        resetCurrentType();
        globalFlag = 0;
}
#line 743 "parser.tab.cc"
    break;

  case 32:
#line 187 "parser.yy"
                                                         {
        resetCurrentFunction();
        quads.insertQuad(299,-1,-1,-1);
}
#line 752 "parser.tab.cc"
    break;

  case 35:
#line 194 "parser.yy"
            {
        quads.setMainQuad();
        scope.setFunctionScope("global");
}
#line 761 "parser.tab.cc"
    break;

  case 36:
#line 197 "parser.yy"
                               {quads.insertQuad(999,-1,-1,-1);quads.printQuadList();}
#line 767 "parser.tab.cc"
    break;

  case 39:
#line 205 "parser.yy"
                        {cout << "Herencia id : " << yystack_[0].value.as < std::string > () << endl;}
#line 773 "parser.tab.cc"
    break;

  case 43:
#line 215 "parser.yy"
{       
        if(globalFlag){
                for(auto var : currentIds){
                        scope.insertGlobalVariable(var,currentType);
                }
        }else{
                for(auto var : currentIds){
                        scope.insertVarOnScope(var,currentType);
                } 
        }
        resetID();
        resetCurrentType();
}
#line 791 "parser.tab.cc"
    break;

  case 52:
#line 247 "parser.yy"
                       {setCurrentType(0);}
#line 797 "parser.tab.cc"
    break;

  case 53:
#line 248 "parser.yy"
                          {setCurrentType(1);}
#line 803 "parser.tab.cc"
    break;

  case 54:
#line 249 "parser.yy"
                         {setCurrentType(2);}
#line 809 "parser.tab.cc"
    break;

  case 56:
#line 252 "parser.yy"
                               {setCurrentType(10);}
#line 815 "parser.tab.cc"
    break;

  case 58:
#line 255 "parser.yy"
                                    {setCurrentType(20);}
#line 821 "parser.tab.cc"
    break;

  case 59:
#line 259 "parser.yy"
{       if(expressionFlag){
                es.insertOprnd(yystack_[0].value.as < std::string > ());
        }else{
                var = scope.getVarOnScope(yystack_[0].value.as < std::string > ());
                if(var == NULL)
                        var = scope.getGlobalVariable(yystack_[0].value.as < std::string > ());
        }
}
#line 834 "parser.tab.cc"
    break;

  case 66:
#line 275 "parser.yy"
                {setID(yystack_[0].value.as < std::string > ());}
#line 840 "parser.tab.cc"
    break;

  case 67:
#line 276 "parser.yy"
{
        //scope.insertVarOnScope($1,currentType);
        scope.insertParameterOnScope(yystack_[4].value.as < std::string > (),currentType);
        resetCurrentType();
        resetID();
}
#line 851 "parser.tab.cc"
    break;

  case 81:
#line 300 "parser.yy"
{
        es = ExpressionSolver();
        expressionFlag = 1;
        es.insertOprnd(var->name);
        es.insertOptr(5);
}
#line 862 "parser.tab.cc"
    break;

  case 82:
#line 307 "parser.yy"
{
        es.assign();
        quads.importSolver(es); 
        expressionFlag = 0;
        //int id = var->dir;
        //quads.insertQuad(101,quads.getLastQuad().result,-1,id);
}
#line 874 "parser.tab.cc"
    break;

  case 86:
#line 325 "parser.yy"
                                    { quads.insertQuad(103,-1,-1,var->dir);}
#line 880 "parser.tab.cc"
    break;

  case 87:
#line 328 "parser.yy"
                      { es = ExpressionSolver(); expressionFlag = 1;}
#line 886 "parser.tab.cc"
    break;

  case 89:
#line 329 "parser.yy"
                              {cout << "Constante string : " << yystack_[0].value.as < std::string > () << endl;}
#line 892 "parser.tab.cc"
    break;

  case 90:
#line 330 "parser.yy"
                             {
                        quads.importSolver(es); 
                        expressionFlag = 0;
                        int single = es.singleVar();
                        if(single){
                                quads.insertQuad(102,single,-1,-1);
                        }else{
                                quads.insertQuad(102,quads.getLastQuad().result,-1,-1);
                        }
                }
#line 907 "parser.tab.cc"
    break;

  case 91:
#line 340 "parser.yy"
                                  {
                        quads.importSolver(es); 
                        expressionFlag = 0;
                        int single = es.singleVar();
                        if(single){
                                quads.insertQuad(102,single,-1,-1);
                        }else{
                                quads.insertQuad(102,quads.getLastQuad().result,-1,-1);
                        }
                        es = ExpressionSolver(); 
                        expressionFlag = 1;
                }
#line 924 "parser.tab.cc"
    break;

  case 93:
#line 352 "parser.yy"
                         {cout << "Constante string : " << yystack_[0].value.as < std::string > () << endl;}
#line 930 "parser.tab.cc"
    break;

  case 95:
#line 355 "parser.yy"
                             {es = ExpressionSolver(); expressionFlag = 1;}
#line 936 "parser.tab.cc"
    break;

  case 96:
#line 355 "parser.yy"
                                                                                            {
        quads.importSolver(es); 
        expressionFlag = 0;
        int single = es.singleVar();
        setJDir(quads.getQuadLastDir());
        if(single){
                quads.insertQuad(201,single,-1,-1);
        }else{
                quads.insertQuad(201,quads.getLastQuad().result,-1,-1);
        }
}
#line 952 "parser.tab.cc"
    break;

  case 98:
#line 367 "parser.yy"
                { 
                int dir = getJDir();
                quads.updateQuadResult(dir,quads.getQuadLastDir()); 
        }
#line 961 "parser.tab.cc"
    break;

  case 100:
#line 371 "parser.yy"
                {
                int dir = getJDir();
                quads.updateQuadResult(dir,quads.getQuadLastDir()); 
        }
#line 970 "parser.tab.cc"
    break;

  case 110:
#line 389 "parser.yy"
           {if(expressionFlag){es.insertOptr(6);}}
#line 976 "parser.tab.cc"
    break;

  case 111:
#line 390 "parser.yy"
           {if(expressionFlag){es.insertOptr(7);}}
#line 982 "parser.tab.cc"
    break;

  case 112:
#line 391 "parser.yy"
           {if(expressionFlag){es.insertOptr(10);}}
#line 988 "parser.tab.cc"
    break;

  case 113:
#line 392 "parser.yy"
           {if(expressionFlag){es.insertOptr(11);}}
#line 994 "parser.tab.cc"
    break;

  case 114:
#line 393 "parser.yy"
           {if(expressionFlag){es.insertOptr(8);}}
#line 1000 "parser.tab.cc"
    break;

  case 115:
#line 394 "parser.yy"
           {if(expressionFlag){es.insertOptr(9);}}
#line 1006 "parser.tab.cc"
    break;

  case 116:
#line 395 "parser.yy"
                   {if(expressionFlag){es.insertOptr(12);}}
#line 1012 "parser.tab.cc"
    break;

  case 118:
#line 396 "parser.yy"
                  {if(expressionFlag){es.insertOptr(13);}}
#line 1018 "parser.tab.cc"
    break;

  case 121:
#line 400 "parser.yy"
           {if(expressionFlag){es.checkStacks();}}
#line 1024 "parser.tab.cc"
    break;

  case 123:
#line 401 "parser.yy"
               {if(expressionFlag){es.insertOptr(0);}}
#line 1030 "parser.tab.cc"
    break;

  case 125:
#line 402 "parser.yy"
               {if(expressionFlag){es.insertOptr(1);}}
#line 1036 "parser.tab.cc"
    break;

  case 128:
#line 406 "parser.yy"
              {if(expressionFlag){es.checkStacks();}}
#line 1042 "parser.tab.cc"
    break;

  case 130:
#line 407 "parser.yy"
                {if(expressionFlag){es.insertOptr(2);}}
#line 1048 "parser.tab.cc"
    break;

  case 132:
#line 408 "parser.yy"
                {if(expressionFlag){es.insertOptr(3);}}
#line 1054 "parser.tab.cc"
    break;

  case 134:
#line 409 "parser.yy"
                {if(expressionFlag){es.insertOptr(4);}}
#line 1060 "parser.tab.cc"
    break;

  case 145:
#line 423 "parser.yy"
              {if(expressionFlag){es.insertOprnd((int)yystack_[0].value.as < float > ());}}
#line 1066 "parser.tab.cc"
    break;

  case 146:
#line 424 "parser.yy"
                {if(expressionFlag){es.insertOprnd((float)yystack_[0].value.as < float > ());}}
#line 1072 "parser.tab.cc"
    break;

  case 147:
#line 425 "parser.yy"
               {if(expressionFlag){es.insertOprnd((char)yystack_[0].value.as < char > ());}}
#line 1078 "parser.tab.cc"
    break;

  case 148:
#line 428 "parser.yy"
                            {es = ExpressionSolver(); expressionFlag = 1;}
#line 1084 "parser.tab.cc"
    break;

  case 149:
#line 428 "parser.yy"
                                                                                           {
        quads.importSolver(es); 
        expressionFlag = 0;
        int single = es.singleVar();
        setJDir(quads.getQuadLastDir());
        if(single){
                quads.insertQuad(201,single,-1,-1);
        }else{
                quads.insertQuad(201,quads.getLastQuad().result,-1,-1);
        }
}
#line 1100 "parser.tab.cc"
    break;

  case 150:
#line 438 "parser.yy"
                          {
        int dir = getJDir();
        quads.insertQuad(200,-1,-1,dir-1);
        quads.updateQuadResult(dir,quads.getQuadLastDir());
}
#line 1110 "parser.tab.cc"
    break;

  case 151:
#line 445 "parser.yy"
                                      {
        es = ExpressionSolver(); 
        expressionFlag = 1;
        setforID(var->name);
        es.insertOprnd(var->name);
        es.insertOptr(5);
}
#line 1122 "parser.tab.cc"
    break;

  case 152:
#line 451 "parser.yy"
      {
        es.assign();
        quads.importSolver(es); 
        expressionFlag = 0;

        string assign = var->name;
        es = ExpressionSolver(); 
        expressionFlag = 1;
        es.insertOprnd(assign);
}
#line 1137 "parser.tab.cc"
    break;

  case 153:
#line 460 "parser.yy"
     { es.insertOptr(9);}
#line 1143 "parser.tab.cc"
    break;

  case 154:
#line 460 "parser.yy"
                              {
        quads.importSolver(es); 
        expressionFlag = 0; 
        int lastDir = quads.getQuadLastDir();
        setJDir(lastDir);
        quads.insertQuad(201,quads.getLastQuad().result,-1,-1);
}
#line 1155 "parser.tab.cc"
    break;

  case 155:
#line 466 "parser.yy"
                          {
        string fid = getforID();
        es = ExpressionSolver(); 
        expressionFlag = 1;
        es.insertOprnd(fid);
        es.insertOptr(5);
        es.insertOprnd(fid);
        es.insertOptr(0);
        es.insertOprnd(1);
        es.assign();
        quads.importSolver(es); 
        expressionFlag = 0;

        int dir = getJDir();
        quads.insertQuad(200,-1,-1,dir-1);
        quads.updateQuadResult(dir,quads.getQuadLastDir());
}
#line 1177 "parser.tab.cc"
    break;


#line 1181 "parser.tab.cc"

            default:
              break;
            }
        }
#if YY_EXCEPTIONS
      catch (const syntax_error& yyexc)
        {
          YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
          error (yyexc);
          YYERROR;
        }
#endif // YY_EXCEPTIONS
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;
      YY_STACK_PRINT ();

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, YY_MOVE (yylhs));
    }
    goto yynewstate;


  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        error (yyla.location, yysyntax_error_ (yystack_[0].state, yyla));
      }


    yyerror_range[1].location = yyla.location;
    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.type_get () == yyeof_)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:
    /* Pacify compilers when the user code never invokes YYERROR and
       the label yyerrorlab therefore never appears in user code.  */
    if (false)
      YYERROR;

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    goto yyerrlab1;


  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    {
      stack_symbol_type error_token;
      for (;;)
        {
          yyn = yypact_[+yystack_[0].state];
          if (!yy_pact_value_is_default_ (yyn))
            {
              yyn += yy_error_token_;
              if (0 <= yyn && yyn <= yylast_ && yycheck_[yyn] == yy_error_token_)
                {
                  yyn = yytable_[yyn];
                  if (0 < yyn)
                    break;
                }
            }

          // Pop the current state because it cannot handle the error token.
          if (yystack_.size () == 1)
            YYABORT;

          yyerror_range[1].location = yystack_[0].location;
          yy_destroy_ ("Error: popping", yystack_[0]);
          yypop_ ();
          YY_STACK_PRINT ();
        }

      yyerror_range[2].location = yyla.location;
      YYLLOC_DEFAULT (error_token.location, yyerror_range, 2);

      // Shift the error token.
      error_token.state = state_type (yyn);
      yypush_ ("Shifting", YY_MOVE (error_token));
    }
    goto yynewstate;


  /*-------------------------------------.
  | yyacceptlab -- YYACCEPT comes here.  |
  `-------------------------------------*/
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;


  /*-----------------------------------.
  | yyabortlab -- YYABORT comes here.  |
  `-----------------------------------*/
  yyabortlab:
    yyresult = 1;
    goto yyreturn;


  /*-----------------------------------------------------.
  | yyreturn -- parsing is finished, return the result.  |
  `-----------------------------------------------------*/
  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
#if YY_EXCEPTIONS
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack\n";
        // Do not try to display the values of the reclaimed symbols,
        // as their printers might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
#endif // YY_EXCEPTIONS
  }

  void
  parser::error (const syntax_error& yyexc)
  {
    error (yyexc.location, yyexc.what ());
  }

  // Generate an error message.
  std::string
  parser::yysyntax_error_ (state_type yystate, const symbol_type& yyla) const
  {
    // Number of reported tokens (one for the "unexpected", one per
    // "expected").
    std::ptrdiff_t yycount = 0;
    // Its maximum.
    enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
    // Arguments of yyformat.
    char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];

    /* There are many possibilities here to consider:
       - If this state is a consistent state with a default action, then
         the only way this function was invoked is if the default action
         is an error action.  In that case, don't check for expected
         tokens because there are none.
       - The only way there can be no lookahead present (in yyla) is
         if this state is a consistent state with a default action.
         Thus, detecting the absence of a lookahead is sufficient to
         determine that there is no unexpected or expected token to
         report.  In that case, just report a simple "syntax error".
       - Don't assume there isn't a lookahead just because this state is
         a consistent state with a default action.  There might have
         been a previous inconsistent state, consistent state with a
         non-default action, or user semantic action that manipulated
         yyla.  (However, yyla is currently not documented for users.)
       - Of course, the expected token list depends on states to have
         correct lookahead information, and it depends on the parser not
         to perform extra reductions after fetching a lookahead from the
         scanner and before detecting a syntax error.  Thus, state merging
         (from LALR or IELR) and default reductions corrupt the expected
         token list.  However, the list is correct for canonical LR with
         one exception: it will still contain any token that will not be
         accepted due to an error action in a later state.
    */
    if (!yyla.empty ())
      {
        symbol_number_type yytoken = yyla.type_get ();
        yyarg[yycount++] = yytname_[yytoken];

        int yyn = yypact_[+yystate];
        if (!yy_pact_value_is_default_ (yyn))
          {
            /* Start YYX at -YYN if negative to avoid negative indexes in
               YYCHECK.  In other words, skip the first -YYN actions for
               this state because they are default actions.  */
            int yyxbegin = yyn < 0 ? -yyn : 0;
            // Stay within bounds of both yycheck and yytname.
            int yychecklim = yylast_ - yyn + 1;
            int yyxend = yychecklim < yyntokens_ ? yychecklim : yyntokens_;
            for (int yyx = yyxbegin; yyx < yyxend; ++yyx)
              if (yycheck_[yyx + yyn] == yyx && yyx != yy_error_token_
                  && !yy_table_value_is_error_ (yytable_[yyx + yyn]))
                {
                  if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                    {
                      yycount = 1;
                      break;
                    }
                  else
                    yyarg[yycount++] = yytname_[yyx];
                }
          }
      }

    char const* yyformat = YY_NULLPTR;
    switch (yycount)
      {
#define YYCASE_(N, S)                         \
        case N:                               \
          yyformat = S;                       \
        break
      default: // Avoid compiler warnings.
        YYCASE_ (0, YY_("syntax error"));
        YYCASE_ (1, YY_("syntax error, unexpected %s"));
        YYCASE_ (2, YY_("syntax error, unexpected %s, expecting %s"));
        YYCASE_ (3, YY_("syntax error, unexpected %s, expecting %s or %s"));
        YYCASE_ (4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
        YYCASE_ (5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
      }

    std::string yyres;
    // Argument number.
    std::ptrdiff_t yyi = 0;
    for (char const* yyp = yyformat; *yyp; ++yyp)
      if (yyp[0] == '%' && yyp[1] == 's' && yyi < yycount)
        {
          yyres += yytnamerr_ (yyarg[yyi++]);
          ++yyp;
        }
      else
        yyres += *yyp;
    return yyres;
  }


  const short parser::yypact_ninf_ = -154;

  const signed char parser::yytable_ninf_ = -94;

  const short
  parser::yypact_[] =
  {
      -2,   -12,    57,  -154,  -154,  -154,    37,    63,    50,  -154,
    -154,  -154,    68,    69,    51,  -154,    42,    53,  -154,    97,
    -154,   101,  -154,  -154,  -154,  -154,  -154,  -154,    76,  -154,
      73,  -154,    75,    47,  -154,  -154,  -154,    64,    51,  -154,
      80,    70,    -5,    28,  -154,  -154,  -154,    48,    51,   106,
    -154,   108,  -154,    42,  -154,   112,  -154,  -154,  -154,  -154,
    -154,  -154,  -154,  -154,  -154,   118,  -154,  -154,    17,    74,
      33,  -154,  -154,  -154,  -154,   113,   115,    51,  -154,   120,
      47,    28,    28,  -154,   117,    44,    62,    21,  -154,  -154,
    -154,  -154,  -154,  -154,  -154,   119,  -154,   122,    83,  -154,
    -154,  -154,    63,  -154,   123,    45,  -154,  -154,  -154,  -154,
    -154,  -154,  -154,  -154,  -154,  -154,  -154,    85,    28,   134,
      22,  -154,    48,   128,   -16,  -154,   126,  -154,  -154,  -154,
    -154,  -154,  -154,  -154,  -154,    28,    28,    28,    28,    28,
      28,    21,  -154,   137,    85,  -154,  -154,    92,  -154,   142,
    -154,  -154,  -154,   136,   140,   141,   149,   150,    92,   154,
    -154,   129,   158,   -16,   -16,   -16,   -16,   -16,   -16,   -16,
    -154,  -154,   128,    68,    52,  -154,  -154,  -154,  -154,  -154,
      28,  -154,   133,  -154,  -154,  -154,    92,  -154,  -154,   163,
      92,  -154,  -154,  -154,   151,   164,  -154,  -154,  -154,  -154,
    -154,  -154,  -154,  -154,  -154,  -154,  -154,   166,   162,  -154,
    -154,  -154,  -154,   137,  -154,  -154,  -154,   160,    -4,    28,
      28,  -154,  -154,    28,    -5,   -16,    28,    28,  -154,   169,
     171,   165,   172,   167,   168,    28,   174,  -154,  -154,   175,
    -154,  -154,  -154,   173,   178,  -154,  -154,  -154,  -154,  -154,
     181,   182,    -4,  -154,    -4,   139,   138,   143,    83,  -154,
    -154,  -154,  -154,  -154,   183,   184,  -154,  -154,    42,   -16,
     -16,    28,  -154,   180,   186,  -154,   152,  -154,   145,  -154,
    -154,  -154,   189,   190,   -16,   -16,   191,   192,  -154,  -154
  };

  const unsigned char
  parser::yydefact_[] =
  {
       0,     0,     0,     2,     4,     1,     0,     3,     0,    30,
       5,    28,     3,     3,     0,    42,     3,     0,    40,     0,
       7,     0,    41,    58,    52,    53,    54,    34,     0,    57,
       0,    39,     3,     0,    43,    35,     6,     0,     0,    48,
       3,     0,     0,     3,     8,    11,    12,     0,     3,     0,
      31,     0,    47,     3,    38,     0,     9,    56,    55,    13,
      23,   139,   140,   141,   137,     3,   121,   128,     0,     0,
       0,    14,    46,    45,    44,     0,     0,     3,    37,     0,
       0,     3,     3,    22,     0,     3,     3,    59,   147,   145,
     146,   144,   143,   138,   142,    16,    15,     0,     0,    51,
      50,    49,     3,    10,     0,   109,    21,    20,   123,   125,
     127,   122,   130,   132,   134,   136,   129,     0,     3,     3,
       3,   103,     0,     0,     3,    66,     0,    29,    24,   110,
     112,   113,   114,   115,   111,     3,     3,     3,     3,     3,
       3,     0,   104,     3,     0,   107,   105,     0,    63,     3,
      60,    17,    19,     0,     0,     0,     0,     0,     0,    59,
      80,     0,     0,     3,     3,     3,     3,     3,     3,     3,
     101,   102,     3,     3,     3,   124,   126,   131,   133,   135,
       3,    27,     0,   106,    59,    61,     0,    65,    62,     0,
       0,    87,    95,   148,     0,     0,    81,    36,    73,    74,
      75,    76,    77,    78,    79,    72,    71,     0,     0,   116,
     118,   120,   108,     3,    25,    64,    85,     0,     3,     3,
       3,   151,    84,     3,     0,     3,     3,     3,    26,     0,
      89,     0,    90,     0,     0,     3,     0,    83,    67,     0,
     117,   119,    86,     0,     0,    91,    96,   149,   152,    82,
       3,     0,     3,    88,     3,     0,     0,     0,     0,    70,
      68,    32,    94,    92,     0,     0,   153,    69,     3,     3,
       3,     3,    33,     0,     0,   154,     3,   150,     0,    98,
     100,    97,     0,     0,     3,     3,     0,     0,   155,    99
  };

  const short
  parser::yypgoto_[] =
  {
    -154,  -154,    -7,  -154,  -154,  -154,   -27,  -154,   121,  -154,
    -154,    81,    86,  -154,  -154,  -112,  -154,    54,  -154,    46,
      -3,   107,  -154,   -52,  -154,  -154,  -154,  -154,  -154,  -154,
      38,   176,  -154,  -154,  -154,   135,  -154,   -40,   -11,  -154,
     -65,  -154,  -154,  -154,   -44,  -154,  -154,  -154,  -154,  -151,
    -154,  -154,  -154,  -154,  -154,  -154,  -154,  -154,  -153,  -154,
    -154,  -154,  -154,  -154,  -154,  -154,  -154,   -96,  -154,  -154,
     -74,  -154,  -154,  -154,  -154,   -39,  -154,  -154,  -154,  -154,
     -48,  -154,  -154,  -154,  -154,  -154,  -154,  -154,  -154,  -154,
    -154,  -154,  -154,  -154,  -154,  -154,  -154,  -154
  };

  const short
  parser::yydefgoto_[] =
  {
      -1,     2,    63,     3,     6,    12,    21,    33,    44,    80,
      45,    46,    71,   122,   123,    47,    84,    64,    81,   119,
     182,    10,    13,    28,    76,   268,    36,    49,    55,    19,
      16,    22,    48,    74,    40,    52,   101,    29,    59,    30,
     161,   120,   150,   188,   126,   172,   250,   260,   207,   162,
     163,   223,   236,   164,   165,   166,   167,   218,   231,   254,
     243,   168,   219,   255,   281,   283,   169,    92,   121,   146,
     232,   135,   212,   226,   227,   105,    85,   111,   136,   137,
      66,    86,   116,   138,   139,   140,    67,    68,    93,    94,
     170,   220,   256,   171,   235,   257,   271,   278
  };

  const short
  parser::yytable_[] =
  {
       9,    78,    58,    91,    65,    15,    18,   104,   149,    27,
      60,    51,   198,   199,   200,   201,   202,   203,   204,    61,
      62,   142,   153,   154,   155,    39,   117,   147,     1,   156,
      96,   157,   158,    54,    43,   118,   159,    24,    25,    26,
       4,    72,    60,   106,   143,     7,    27,    57,   183,   230,
      51,    61,    62,    41,    69,    42,    70,     5,    83,    43,
     206,   129,   130,   131,   132,   133,   134,   108,   109,    87,
      99,    88,    89,    90,   239,    24,    25,    26,   110,   115,
     209,   210,   185,    23,    24,    25,    26,   112,   113,   114,
     177,   178,   179,   194,     8,     9,   174,   175,   176,   262,
      14,   263,    11,    20,    17,    31,   213,    32,    34,    35,
      37,    38,   145,   148,    53,    77,    50,   160,   273,   274,
      75,   215,    56,    79,    82,   217,    95,   102,    97,    98,
     107,   -18,   124,   286,   287,   125,   181,   141,   128,   144,
      43,   173,   187,   180,   184,   233,   234,   186,   214,   237,
      60,   196,   240,   241,   190,   191,   160,   160,   160,   160,
     160,   160,   160,   192,   193,   205,    15,   211,   118,   197,
     216,   222,   225,   221,   224,   229,   242,   -93,   245,   252,
     244,   249,   246,   247,    58,   253,   251,   258,   265,   261,
     264,   276,   266,   269,   270,   282,   248,   277,   279,   284,
     285,   103,   288,   289,   152,   195,   181,   189,   151,   127,
     228,   208,   100,   238,   267,     0,   272,     0,   160,     0,
       0,     0,     0,     0,    73,     0,     0,     0,     0,     0,
       0,     0,   275,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   259,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    27,   160,   160,     0,     0,     0,     0,     0,   280,
       0,     0,     0,     0,     0,     0,     0,   160,   160
  };

  const short
  parser::yycheck_[] =
  {
       7,    53,    42,    68,    43,    12,    13,    81,   120,    16,
      14,    38,   163,   164,   165,   166,   167,   168,   169,    23,
      24,   117,    38,    39,    40,    32,     5,     5,    30,    45,
      70,    47,    48,    40,    12,    14,    52,    42,    43,    44,
      52,    48,    14,    82,   118,     8,    53,    52,   144,    53,
      77,    23,    24,     6,     6,     8,     8,     0,    65,    12,
     172,    16,    17,    18,    19,    20,    21,    23,    24,    52,
      77,    54,    55,    56,   225,    42,    43,    44,    85,    86,
      28,    29,   147,    41,    42,    43,    44,    25,    26,    27,
     138,   139,   140,   158,    31,   102,   135,   136,   137,   252,
      32,   254,    52,    52,    35,    52,   180,    10,     7,    33,
      37,    36,   119,   120,    34,     7,    52,   124,   269,   270,
      14,   186,    52,    11,     6,   190,    52,     7,    15,    14,
      13,    12,    10,   284,   285,    52,   143,    52,    15,     5,
      12,    15,   149,     6,    52,   219,   220,     5,    15,   223,
      14,    22,   226,   227,    14,    14,   163,   164,   165,   166,
     167,   168,   169,    14,    14,   172,   173,   174,    14,    11,
       7,     7,    10,    22,     8,    15,     7,     6,     6,     6,
      15,     7,    15,    15,   224,     7,    11,     6,    50,     7,
      51,    11,    49,    10,    10,    50,   235,    11,    46,    10,
      10,    80,    11,    11,   123,   159,   213,   153,   122,   102,
     213,   173,    77,   224,   258,    -1,   268,    -1,   225,    -1,
      -1,    -1,    -1,    -1,    48,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   271,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   250,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   268,   269,   270,    -1,    -1,    -1,    -1,    -1,   276,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   284,   285
  };

  const unsigned char
  parser::yystos_[] =
  {
       0,    30,    58,    60,    52,     0,    61,     8,    31,    59,
      78,    52,    62,    79,    32,    59,    87,    35,    59,    86,
      52,    63,    88,    41,    42,    43,    44,    59,    80,    94,
      96,    52,    10,    64,     7,    33,    83,    37,    36,    59,
      91,     6,     8,    12,    65,    67,    68,    72,    89,    84,
      52,    63,    92,    34,    59,    85,    52,    52,    94,    95,
      14,    23,    24,    59,    74,   132,   137,   143,   144,     6,
       8,    69,    59,    88,    90,    14,    81,     7,    80,    11,
      66,    75,     6,    59,    73,   133,   138,    52,    54,    55,
      56,    97,   124,   145,   146,    52,    94,    15,    14,    59,
      92,    93,     7,    65,   127,   132,   132,    13,    23,    24,
      59,   134,    25,    26,    27,    59,   139,     5,    14,    76,
      98,   125,    70,    71,    10,    52,   101,    78,    15,    16,
      17,    18,    19,    20,    21,   128,   135,   136,   140,   141,
     142,    52,   124,   127,     5,    59,   126,     5,    59,    72,
      99,    69,    68,    38,    39,    40,    45,    47,    48,    52,
      59,    97,   106,   107,   110,   111,   112,   113,   118,   123,
     147,   150,   102,    15,   132,   132,   132,   137,   137,   137,
       6,    59,    77,   124,    52,    97,     5,    59,   100,    74,
      14,    14,    14,    14,    97,    76,    22,    11,   106,   106,
     106,   106,   106,   106,   106,    59,    72,   105,    87,    28,
      29,    59,   129,   127,    15,    97,     7,    97,   114,   119,
     148,    22,     7,   108,     8,    10,   130,   131,    77,    15,
      53,   115,   127,   127,   127,   151,   109,   127,    95,   106,
     127,   127,     7,   117,    15,     6,    15,    15,   132,     7,
     103,    11,     6,     7,   116,   120,   149,   152,     6,    59,
     104,     7,   115,   115,    51,    50,    49,   101,    82,    10,
      10,   153,    80,   106,   106,   132,    11,    11,   154,    46,
      59,   121,    50,   122,    10,    10,   106,   106,    11,    11
  };

  const unsigned char
  parser::yyr1_[] =
  {
       0,    57,    58,    59,    61,    62,    60,    64,    63,    66,
      65,    65,    67,    67,    68,    69,    70,    69,    71,    69,
      72,    73,    73,    75,    74,    76,    77,    77,    79,    78,
      78,    81,    82,    80,    80,    84,    83,    85,    85,    86,
      86,    87,    87,    89,    88,    90,    90,    91,    91,    92,
      93,    93,    94,    94,    94,    95,    95,    96,    96,    98,
      97,    99,    99,    99,   100,   100,   102,   103,   101,   104,
     104,   105,   105,   106,   106,   106,   106,   106,   106,   106,
     106,   108,   107,   109,   110,   111,   112,   114,   113,   115,
     115,   116,   115,   117,   115,   119,   120,   118,   122,   121,
     121,   123,   123,   124,   125,   125,   126,   126,   127,   127,
     128,   128,   128,   128,   128,   128,   130,   129,   131,   129,
     129,   133,   132,   135,   134,   136,   134,   134,   138,   137,
     140,   139,   141,   139,   142,   139,   139,   143,   143,   144,
     144,   144,   145,   145,   145,   146,   146,   146,   148,   149,
     147,   151,   152,   153,   154,   150
  };

  const signed char
  parser::yyr2_[] =
  {
       0,     2,     1,     0,     0,     0,     9,     0,     3,     0,
       4,     1,     1,     2,     2,     2,     0,     4,     0,     4,
       4,     2,     1,     0,     4,     4,     3,     1,     0,    10,
       1,     0,     0,    14,     1,     0,     7,     2,     1,     2,
       1,     2,     1,     0,     4,     1,     1,     2,     1,     3,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     0,
       3,     2,     2,     1,     2,     1,     0,     0,     7,     2,
       1,     1,     1,     2,     2,     2,     2,     2,     2,     2,
       1,     0,     5,     1,     3,     3,     5,     0,     6,     1,
       1,     0,     4,     0,     4,     0,     0,    11,     0,     5,
       1,     1,     1,     2,     2,     2,     2,     1,     4,     1,
       1,     1,     1,     1,     1,     1,     0,     3,     0,     3,
       1,     0,     3,     0,     3,     0,     3,     1,     0,     3,
       0,     3,     0,     3,     0,     3,     1,     1,     2,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     0,     0,
      10,     0,     0,     0,     0,    14
  };



  // YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
  // First, the terminals, then, starting at \a yyntokens_, nonterminals.
  const char*
  const parser::yytname_[] =
  {
  "\"eof\"", "error", "$undefined", "COMENTARIO", "SIMBOLO", "PUNTO",
  "COMA", "SCOL", "COL", "GBAJO", "LCUR", "RCUR", "LBRA", "RBRA", "LPAR",
  "RPAR", "EQ", "GE", "LE", "GT", "LT", "NE", "ASSIGN", "SUM", "RES",
  "MUL", "DIV", "MOD", "AND", "OR", "PROGRAMA", "CLASE", "VARIABLES",
  "MAIN", "METODOS", "HEREDA", "ATRIBUTOS", "FUNCION", "RETORNAR", "LEER",
  "ESCRIBIR", "VOID", "INT_T", "FLOAT_T", "CHAR_T", "SI", "SINO",
  "MIENTRAS", "PARA", "EN", "HACER", "ENTONCES", "ID", "STRING", "CHAR",
  "INT", "FLOAT", "$accept", "script", "empty", "program", "$@1", "$@2",
  "declare_var", "$@3", "declare_bridge1", "$@4", "declare_bridge2",
  "declare_bridge3", "declare_bridge4", "$@5", "$@6", "dimensions",
  "matrix", "single_express", "$@7", "mult_express", "expression_loop",
  "classes", "$@8", "functions", "$@9", "$@10", "main", "$@11", "methods",
  "inheritance", "variables", "var_bridge1", "$@12", "var_bridge2",
  "attributes", "attr_bridge1", "attr_bridge2", "primitive_type",
  "var_type", "return_type", "call_var", "$@13", "call_options",
  "call_cont", "parameters", "$@14", "$@15", "par_cont", "par_array",
  "statutes", "assignment", "$@16", "assignment_opt", "call_void",
  "function_return", "read", "write", "$@17", "write_expression_opt",
  "$@18", "$@19", "decision_statement", "$@20", "$@21", "dec_else", "$@22",
  "repetition_statement", "call_function", "func_options", "func_cont",
  "expression", "relop", "express_loop", "$@23", "$@24", "exp", "$@25",
  "exp_loop", "$@26", "$@27", "term", "$@28", "term_loop", "$@29", "$@30",
  "$@31", "factor", "sign", "call", "var_cte", "conditional", "$@32",
  "$@33", "nonconditional", "$@34", "$@35", "$@36", "$@37", YY_NULLPTR
  };

#if YYDEBUG
  const short
  parser::yyrline_[] =
  {
       0,   136,   136,   139,   142,   142,   142,   146,   146,   147,
     147,   148,   149,   150,   151,   152,   153,   153,   154,   154,
     159,   160,   161,   166,   166,   169,   170,   171,   176,   176,
     177,   180,   187,   180,   191,   194,   194,   201,   202,   205,
     206,   211,   212,   215,   214,   230,   231,   238,   239,   240,
     241,   242,   247,   248,   249,   252,   252,   255,   255,   259,
     258,   267,   268,   269,   270,   271,   275,   276,   275,   282,
     283,   284,   285,   289,   290,   291,   292,   293,   294,   295,
     296,   300,   299,   316,   319,   322,   325,   328,   328,   329,
     330,   340,   340,   352,   352,   355,   355,   355,   367,   367,
     371,   377,   377,   380,   381,   382,   383,   384,   387,   388,
     389,   390,   391,   392,   393,   394,   395,   395,   396,   396,
     397,   400,   400,   401,   401,   402,   402,   403,   406,   406,
     407,   407,   408,   408,   409,   409,   410,   413,   414,   415,
     416,   417,   418,   419,   420,   423,   424,   425,   428,   428,
     428,   445,   451,   460,   460,   445
  };

  // Print the state stack on the debug stream.
  void
  parser::yystack_print_ ()
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << int (i->state);
    *yycdebug_ << '\n';
  }

  // Report on the debug stream that the rule \a yyrule is going to be reduced.
  void
  parser::yy_reduce_print_ (int yyrule)
  {
    int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):\n";
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG


#line 6 "parser.yy"
} // yy
#line 1783 "parser.tab.cc"

#line 485 "parser.yy"

void yy::parser::error(const location_type& lugar, const std::string& lexema)
{
  std::cout << "SYNTAX ERROR !!! " << lexema << std::endl;
}
