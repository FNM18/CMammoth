#include <stdio.h>
#include "driver.h"
#include "semantic.cpp"
#include <stack>
#include <vector>
using namespace std;

//static Scope scope = Scope();

int main(){
  SemanticConsideration sc = SemanticConsideration();
  sc.testCube(0,0,5);
  //es.count = 0;
  
  //Pruebas de scope
//   scope.insertGlobalVariable("Diego",0,"1");
//   scope.insertGlobalVariable("Fabian",0,"2");
//   scope.insertGlobalVariable("Daniel",1,"1.54");
//   scope.insertGlobalVariable("Gabriel",2,"f");


//   scope.globalInsertFunction("func1","void","local");
//   scope.installFunctionVars("func1");
//   scope.globalInsertFunction("func2","int","local");
//   scope.installFunctionVars("func2");
//   scope.globalInsertFunction("func3","float","local");
//   scope.installFunctionVars("func3");
//   scope.globalInsertFunction("func4","char","local");
//   scope.installFunctionVars("func4");

//   scope.setFunctionScope("func1");
//   scope.insertVarOnScope("Diegof1",0,"11");
//   scope.setFunctionScope("func2");
//   scope.insertVarOnScope("Fabianf2",0,"22");
//   scope.setFunctionScope("func3");
//   scope.insertVarOnScope("Danielf3",1,"11.5454");
//   scope.setFunctionScope("func4");
//   scope.insertVarOnScope("Gabrielf4",2,"g");

//   scope.updateGlobalVariable("Diego",0,"40");
//   scope.updateGlobalVariable("Fabian",0,"456");
  
//   scope.setFunctionScope("func1");
//   scope.updateVarOnScope("Diegof1",0,"41111");
//   scope.setFunctionScope("func2");
//   scope.updateVarOnScope("Fabianf2",0,"221122");
//   scope.setFunctionScope("func3");
//   scope.updateVarOnScope("Danielf3",1,"54.11");
//   scope.setFunctionScope("func4");
//   scope.updateVarOnScope("Gabrielf4",2,"p");

//   printVar(scope.getGlobalVariable("Diego"));
//   printVar(scope.getGlobalVariable("Fabian"));
//   printVar(scope.getGlobalVariable("Daniel"));
//   printVar(scope.getGlobalVariable("Gabriel"));
//   scope.setFunctionScope("func1");
//   printVar(scope.getVarOnScope("Diegof1"));
//   scope.setFunctionScope("func2");
//   printVar(scope.getVarOnScope("Fabianf2"));
//   scope.setFunctionScope("func3");
//   printVar(scope.getVarOnScope("Danielf3"));
//   scope.setFunctionScope("func4");
//   printVar(scope.getVarOnScope("Gabrielf4"));

// 
  //Pruebas del expresion solver
// scope = Scope();
// ExpressionSolver esp = ExpressionSolver();

// esp.installPar();
// cout<<"Paso"<<endl;
// esp.insertOprnd("Diego");
// cout<<"Paso"<<endl;
// esp.insertOptr(0);
// cout<<"Paso"<<endl;
// esp.insertOprnd(99.77f);
// cout<<"Paso"<<endl;
// esp.insertOptr(2);
// cout<<"Paso"<<endl;
// esp.installPar();
// cout<<"Paso"<<endl;
// esp.insertOprnd("Fabian");
// cout<<"Paso"<<endl;
// esp.insertOptr(0);
// cout<<"Paso"<<endl;
// esp.insertOprnd("Fabian");
// cout<<"Paso"<<endl;
// esp.closePar();
// cout<<"Paso"<<endl;
// esp.closePar();
//   /*
//   int len1 = es.operands.size();
//   int len2 = es.operators.size();
  
//   for(int i = 0; i < len1; i++)
//   {
//     cout << es.operands.top() << endl;
//     es.operands.pop();
//   }
//   cout<< "\n";
//   for(int i = 0; i < len2; i++)
//   {
//     cout << es.operators.top() << endl;
//     es.operators.pop();
//   }
// */
// cout << "Line" << endl;;
//   for(auto var : es.result){
//     cout << "Line2" << endl;
//     cout << "Operador: " << var.op << endl;
//     cout << "Operand Left: " << var.operandLeft << endl;
//     cout << "Operand Right: " << var.operandRight << endl;
//     cout << "Result: " << var.result << endl;
//     cout << "Line3" << endl;
//   }
  
  


  // ExpressionSolver::varAndType vt1 = es.solveQuadruple(0,"Diego","Fabian");
  // ExpressionSolver::varAndType vt2 = es.solveQuadruple(2,"Daniel","Fabian");
  // ExpressionSolver::varAndType vt3 = es.solveQuadruple(2,"Daniel","Gabriel");
  // printVarType(&vt1);
  // printVarType(&vt2);
  // printVarType(&vt3);


  //SemanticConsideration sc = SemanticConsideration();
  //sc.testCube(sc.varType::Float,sc.varType::Int,sc.opType::Sum);

  //Analizador sintactico
  parser_driver driver;
  if(!driver.parse("test.txt"))  
   printf("\nInput Accepted\n\n");
  
}
