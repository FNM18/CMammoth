#!/bin/bash

c++ main.cpp Scanner.cpp driver.cpp parser.tab.cc semantic.cpp
./a.out