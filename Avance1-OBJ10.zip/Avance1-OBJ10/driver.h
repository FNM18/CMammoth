#include <string>
#include "parser.tab.hh"
using namespace std;
using namespace yy;
#ifndef DRIVER
#define DRIVER
#define YY_DECL \
parser::symbol_type yylex (parser_driver& driver)
YY_DECL;


class parser_driver{
  public:
    void scannerInit();
    void scannerEnd();
    int parse(const string &archivo);
    string file;
};
#endif