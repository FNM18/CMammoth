// A Bison parser, made by GNU Bison 3.5.1.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2020 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// Undocumented macros, especially those whose name start with YY_,
// are private implementation details.  Do not rely on them.





#include "parser.tab.hh"


// Unqualified %code blocks.
#line 22 "parser.yy"

#include "driver.h"
#include <iostream>

#line 50 "parser.tab.cc"


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

// Whether we are compiled with exception support.
#ifndef YY_EXCEPTIONS
# if defined __GNUC__ && !defined __EXCEPTIONS
#  define YY_EXCEPTIONS 0
# else
#  define YY_EXCEPTIONS 1
# endif
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K].location)
/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

# ifndef YYLLOC_DEFAULT
#  define YYLLOC_DEFAULT(Current, Rhs, N)                               \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).begin  = YYRHSLOC (Rhs, 1).begin;                   \
          (Current).end    = YYRHSLOC (Rhs, N).end;                     \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).begin = (Current).end = YYRHSLOC (Rhs, 0).end;      \
        }                                                               \
    while (false)
# endif


// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << '\n';                       \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yystack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YYUSE (Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void> (0)
# define YY_STACK_PRINT()                static_cast<void> (0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)

#line 6 "parser.yy"
namespace yy {
#line 142 "parser.tab.cc"


  /* Return YYSTR after stripping away unnecessary quotes and
     backslashes, so that it's suitable for yyerror.  The heuristic is
     that double-quoting is unnecessary unless the string contains an
     apostrophe, a comma, or backslash (other than backslash-backslash).
     YYSTR is taken from yytname.  */
  std::string
  parser::yytnamerr_ (const char *yystr)
  {
    if (*yystr == '"')
      {
        std::string yyr;
        char const *yyp = yystr;

        for (;;)
          switch (*++yyp)
            {
            case '\'':
            case ',':
              goto do_not_strip_quotes;

            case '\\':
              if (*++yyp != '\\')
                goto do_not_strip_quotes;
              else
                goto append;

            append:
            default:
              yyr += *yyp;
              break;

            case '"':
              return yyr;
            }
      do_not_strip_quotes: ;
      }

    return yystr;
  }


  /// Build a parser object.
  parser::parser (parser_driver& driver_yyarg)
#if YYDEBUG
    : yydebug_ (false),
      yycdebug_ (&std::cerr),
#else
    :
#endif
      driver (driver_yyarg)
  {}

  parser::~parser ()
  {}

  parser::syntax_error::~syntax_error () YY_NOEXCEPT YY_NOTHROW
  {}

  /*---------------.
  | Symbol types.  |
  `---------------*/



  // by_state.
  parser::by_state::by_state () YY_NOEXCEPT
    : state (empty_state)
  {}

  parser::by_state::by_state (const by_state& that) YY_NOEXCEPT
    : state (that.state)
  {}

  void
  parser::by_state::clear () YY_NOEXCEPT
  {
    state = empty_state;
  }

  void
  parser::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  parser::by_state::by_state (state_type s) YY_NOEXCEPT
    : state (s)
  {}

  parser::symbol_number_type
  parser::by_state::type_get () const YY_NOEXCEPT
  {
    if (state == empty_state)
      return empty_symbol;
    else
      return yystos_[+state];
  }

  parser::stack_symbol_type::stack_symbol_type ()
  {}

  parser::stack_symbol_type::stack_symbol_type (YY_RVREF (stack_symbol_type) that)
    : super_type (YY_MOVE (that.state), YY_MOVE (that.location))
  {
    switch (that.type_get ())
    {
      case 55: // INT
      case 56: // FLOAT
        value.YY_MOVE_OR_COPY< float > (YY_MOVE (that.value));
        break;

      case 52: // ID
      case 53: // STRING
      case 54: // CHAR
        value.YY_MOVE_OR_COPY< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

#if 201103L <= YY_CPLUSPLUS
    // that is emptied.
    that.state = empty_state;
#endif
  }

  parser::stack_symbol_type::stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) that)
    : super_type (s, YY_MOVE (that.location))
  {
    switch (that.type_get ())
    {
      case 55: // INT
      case 56: // FLOAT
        value.move< float > (YY_MOVE (that.value));
        break;

      case 52: // ID
      case 53: // STRING
      case 54: // CHAR
        value.move< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

    // that is emptied.
    that.type = empty_symbol;
  }

#if YY_CPLUSPLUS < 201103L
  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
    switch (that.type_get ())
    {
      case 55: // INT
      case 56: // FLOAT
        value.copy< float > (that.value);
        break;

      case 52: // ID
      case 53: // STRING
      case 54: // CHAR
        value.copy< std::string > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    return *this;
  }

  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (stack_symbol_type& that)
  {
    state = that.state;
    switch (that.type_get ())
    {
      case 55: // INT
      case 56: // FLOAT
        value.move< float > (that.value);
        break;

      case 52: // ID
      case 53: // STRING
      case 54: // CHAR
        value.move< std::string > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    // that is emptied.
    that.state = empty_state;
    return *this;
  }
#endif

  template <typename Base>
  void
  parser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);
  }

#if YYDEBUG
  template <typename Base>
  void
  parser::yy_print_ (std::ostream& yyo,
                                     const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YYUSE (yyoutput);
    symbol_number_type yytype = yysym.type_get ();
#if defined __GNUC__ && ! defined __clang__ && ! defined __ICC && __GNUC__ * 100 + __GNUC_MINOR__ <= 408
    // Avoid a (spurious) G++ 4.8 warning about "array subscript is
    // below array bounds".
    if (yysym.empty ())
      std::abort ();
#endif
    yyo << (yytype < yyntokens_ ? "token" : "nterm")
        << ' ' << yytname_[yytype] << " ("
        << yysym.location << ": ";
    switch (yytype)
    {
      case 52: // ID
#line 121 "parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 382 "parser.tab.cc"
        break;

      case 53: // STRING
#line 121 "parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 388 "parser.tab.cc"
        break;

      case 54: // CHAR
#line 121 "parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 394 "parser.tab.cc"
        break;

      case 55: // INT
#line 121 "parser.yy"
                 { yyoutput << yysym.value.template as < float > (); }
#line 400 "parser.tab.cc"
        break;

      case 56: // FLOAT
#line 121 "parser.yy"
                 { yyoutput << yysym.value.template as < float > (); }
#line 406 "parser.tab.cc"
        break;

      default:
        break;
    }
    yyo << ')';
  }
#endif

  void
  parser::yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym)
  {
    if (m)
      YY_SYMBOL_PRINT (m, sym);
    yystack_.push (YY_MOVE (sym));
  }

  void
  parser::yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym)
  {
#if 201103L <= YY_CPLUSPLUS
    yypush_ (m, stack_symbol_type (s, std::move (sym)));
#else
    stack_symbol_type ss (s, sym);
    yypush_ (m, ss);
#endif
  }

  void
  parser::yypop_ (int n)
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  parser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  parser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  parser::debug_level_type
  parser::debug_level () const
  {
    return yydebug_;
  }

  void
  parser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  parser::state_type
  parser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - yyntokens_] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - yyntokens_];
  }

  bool
  parser::yy_pact_value_is_default_ (int yyvalue)
  {
    return yyvalue == yypact_ninf_;
  }

  bool
  parser::yy_table_value_is_error_ (int yyvalue)
  {
    return yyvalue == yytable_ninf_;
  }

  int
  parser::operator() ()
  {
    return parse ();
  }

  int
  parser::parse ()
  {
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The locations where the error started and ended.
    stack_symbol_type yyerror_range[3];

    /// The return value of parse ().
    int yyresult;

#if YY_EXCEPTIONS
    try
#endif // YY_EXCEPTIONS
      {
    YYCDEBUG << "Starting parse\n";


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, YY_MOVE (yyla));

  /*-----------------------------------------------.
  | yynewstate -- push a new symbol on the stack.  |
  `-----------------------------------------------*/
  yynewstate:
    YYCDEBUG << "Entering state " << int (yystack_[0].state) << '\n';

    // Accept?
    if (yystack_[0].state == yyfinal_)
      YYACCEPT;

    goto yybackup;


  /*-----------.
  | yybackup.  |
  `-----------*/
  yybackup:
    // Try to take a decision without lookahead.
    yyn = yypact_[+yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token: ";
#if YY_EXCEPTIONS
        try
#endif // YY_EXCEPTIONS
          {
            symbol_type yylookahead (yylex (driver));
            yyla.move (yylookahead);
          }
#if YY_EXCEPTIONS
        catch (const syntax_error& yyexc)
          {
            YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
            error (yyexc);
            goto yyerrlab1;
          }
#endif // YY_EXCEPTIONS
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.type_get ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.type_get ())
      {
        goto yydefault;
      }

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", state_type (yyn), YY_MOVE (yyla));
    goto yynewstate;


  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[+yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;


  /*-----------------------------.
  | yyreduce -- do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_ (yystack_[yylen].state, yyr1_[yyn]);
      /* Variants are always initialized to an empty instance of the
         correct type. The default '$$ = $1' action is NOT applied
         when using variants.  */
      switch (yyr1_[yyn])
    {
      case 55: // INT
      case 56: // FLOAT
        yylhs.value.emplace< float > ();
        break;

      case 52: // ID
      case 53: // STRING
      case 54: // CHAR
        yylhs.value.emplace< std::string > ();
        break;

      default:
        break;
    }


      // Default location.
      {
        stack_type::slice range (yystack_, yylen);
        YYLLOC_DEFAULT (yylhs.location, range, yylen);
        yyerror_range[1].location = yylhs.location;
      }

      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
#if YY_EXCEPTIONS
      try
#endif // YY_EXCEPTIONS
        {
          switch (yyn)
            {
  case 69:
#line 228 "parser.yy"
                            {std::cout << std::endl <<"Expression\n" << std::endl;}
#line 658 "parser.tab.cc"
    break;


#line 662 "parser.tab.cc"

            default:
              break;
            }
        }
#if YY_EXCEPTIONS
      catch (const syntax_error& yyexc)
        {
          YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
          error (yyexc);
          YYERROR;
        }
#endif // YY_EXCEPTIONS
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;
      YY_STACK_PRINT ();

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, YY_MOVE (yylhs));
    }
    goto yynewstate;


  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        error (yyla.location, yysyntax_error_ (yystack_[0].state, yyla));
      }


    yyerror_range[1].location = yyla.location;
    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.type_get () == yyeof_)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:
    /* Pacify compilers when the user code never invokes YYERROR and
       the label yyerrorlab therefore never appears in user code.  */
    if (false)
      YYERROR;

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    goto yyerrlab1;


  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    {
      stack_symbol_type error_token;
      for (;;)
        {
          yyn = yypact_[+yystack_[0].state];
          if (!yy_pact_value_is_default_ (yyn))
            {
              yyn += yy_error_token_;
              if (0 <= yyn && yyn <= yylast_ && yycheck_[yyn] == yy_error_token_)
                {
                  yyn = yytable_[yyn];
                  if (0 < yyn)
                    break;
                }
            }

          // Pop the current state because it cannot handle the error token.
          if (yystack_.size () == 1)
            YYABORT;

          yyerror_range[1].location = yystack_[0].location;
          yy_destroy_ ("Error: popping", yystack_[0]);
          yypop_ ();
          YY_STACK_PRINT ();
        }

      yyerror_range[2].location = yyla.location;
      YYLLOC_DEFAULT (error_token.location, yyerror_range, 2);

      // Shift the error token.
      error_token.state = state_type (yyn);
      yypush_ ("Shifting", YY_MOVE (error_token));
    }
    goto yynewstate;


  /*-------------------------------------.
  | yyacceptlab -- YYACCEPT comes here.  |
  `-------------------------------------*/
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;


  /*-----------------------------------.
  | yyabortlab -- YYABORT comes here.  |
  `-----------------------------------*/
  yyabortlab:
    yyresult = 1;
    goto yyreturn;


  /*-----------------------------------------------------.
  | yyreturn -- parsing is finished, return the result.  |
  `-----------------------------------------------------*/
  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
#if YY_EXCEPTIONS
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack\n";
        // Do not try to display the values of the reclaimed symbols,
        // as their printers might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
#endif // YY_EXCEPTIONS
  }

  void
  parser::error (const syntax_error& yyexc)
  {
    error (yyexc.location, yyexc.what ());
  }

  // Generate an error message.
  std::string
  parser::yysyntax_error_ (state_type yystate, const symbol_type& yyla) const
  {
    // Number of reported tokens (one for the "unexpected", one per
    // "expected").
    std::ptrdiff_t yycount = 0;
    // Its maximum.
    enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
    // Arguments of yyformat.
    char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];

    /* There are many possibilities here to consider:
       - If this state is a consistent state with a default action, then
         the only way this function was invoked is if the default action
         is an error action.  In that case, don't check for expected
         tokens because there are none.
       - The only way there can be no lookahead present (in yyla) is
         if this state is a consistent state with a default action.
         Thus, detecting the absence of a lookahead is sufficient to
         determine that there is no unexpected or expected token to
         report.  In that case, just report a simple "syntax error".
       - Don't assume there isn't a lookahead just because this state is
         a consistent state with a default action.  There might have
         been a previous inconsistent state, consistent state with a
         non-default action, or user semantic action that manipulated
         yyla.  (However, yyla is currently not documented for users.)
       - Of course, the expected token list depends on states to have
         correct lookahead information, and it depends on the parser not
         to perform extra reductions after fetching a lookahead from the
         scanner and before detecting a syntax error.  Thus, state merging
         (from LALR or IELR) and default reductions corrupt the expected
         token list.  However, the list is correct for canonical LR with
         one exception: it will still contain any token that will not be
         accepted due to an error action in a later state.
    */
    if (!yyla.empty ())
      {
        symbol_number_type yytoken = yyla.type_get ();
        yyarg[yycount++] = yytname_[yytoken];

        int yyn = yypact_[+yystate];
        if (!yy_pact_value_is_default_ (yyn))
          {
            /* Start YYX at -YYN if negative to avoid negative indexes in
               YYCHECK.  In other words, skip the first -YYN actions for
               this state because they are default actions.  */
            int yyxbegin = yyn < 0 ? -yyn : 0;
            // Stay within bounds of both yycheck and yytname.
            int yychecklim = yylast_ - yyn + 1;
            int yyxend = yychecklim < yyntokens_ ? yychecklim : yyntokens_;
            for (int yyx = yyxbegin; yyx < yyxend; ++yyx)
              if (yycheck_[yyx + yyn] == yyx && yyx != yy_error_token_
                  && !yy_table_value_is_error_ (yytable_[yyx + yyn]))
                {
                  if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                    {
                      yycount = 1;
                      break;
                    }
                  else
                    yyarg[yycount++] = yytname_[yyx];
                }
          }
      }

    char const* yyformat = YY_NULLPTR;
    switch (yycount)
      {
#define YYCASE_(N, S)                         \
        case N:                               \
          yyformat = S;                       \
        break
      default: // Avoid compiler warnings.
        YYCASE_ (0, YY_("syntax error"));
        YYCASE_ (1, YY_("syntax error, unexpected %s"));
        YYCASE_ (2, YY_("syntax error, unexpected %s, expecting %s"));
        YYCASE_ (3, YY_("syntax error, unexpected %s, expecting %s or %s"));
        YYCASE_ (4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
        YYCASE_ (5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
      }

    std::string yyres;
    // Argument number.
    std::ptrdiff_t yyi = 0;
    for (char const* yyp = yyformat; *yyp; ++yyp)
      if (yyp[0] == '%' && yyp[1] == 's' && yyi < yycount)
        {
          yyres += yytnamerr_ (yyarg[yyi++]);
          ++yyp;
        }
      else
        yyres += *yyp;
    return yyres;
  }


  const short parser::yypact_ninf_ = -237;

  const signed char parser::yytable_ninf_ = -1;

  const short
  parser::yypact_[] =
  {
     -28,   -44,    23,  -237,    18,  -237,     3,    -7,  -237,    14,
      27,     1,  -237,    85,    11,  -237,    57,    60,  -237,    65,
    -237,  -237,  -237,  -237,  -237,    58,    80,  -237,    66,    63,
    -237,   128,   -14,   127,  -237,    90,    93,  -237,   109,   140,
       1,  -237,  -237,  -237,  -237,  -237,  -237,   142,   135,   137,
     141,  -237,   144,    85,  -237,   145,   100,  -237,   146,  -237,
       1,   147,   106,    25,  -237,   154,   -14,  -237,   155,  -237,
    -237,  -237,  -237,  -237,    41,   149,   148,    25,  -237,  -237,
    -237,   158,   -11,    88,    68,    93,  -237,  -237,   159,     3,
     151,   156,   157,   160,   161,   116,    38,  -237,   150,   162,
      41,    41,    41,    41,    41,    41,    41,  -237,  -237,    25,
    -237,   168,    14,   163,    91,    25,  -237,   166,    25,    25,
    -237,  -237,    25,    25,    25,  -237,  -237,    46,  -237,  -237,
    -237,  -237,  -237,  -237,  -237,  -237,    93,  -237,    25,    25,
      13,    25,    25,    30,   164,   116,    25,    25,  -237,  -237,
    -237,    25,  -237,  -237,  -237,  -237,  -237,  -237,  -237,  -237,
     176,   -14,   174,  -237,  -237,  -237,  -237,  -237,  -237,  -237,
      25,  -237,  -237,  -237,  -237,  -237,  -237,  -237,   117,    25,
      17,  -237,  -237,  -237,  -237,  -237,  -237,   170,   172,   182,
     177,   183,   178,   180,    25,  -237,   185,   189,   191,   198,
    -237,    25,  -237,   193,   201,    41,    28,    46,  -237,   202,
     203,   195,   205,   206,   207,    13,   208,    13,   165,   167,
     171,    25,  -237,   199,   212,    25,  -237,  -237,  -237,   106,
    -237,  -237,   210,    25,    25,  -237,  -237,    25,  -237,   211,
      17,   220,    17,  -237,  -237,  -237,  -237,  -237,   216,   217,
      25,  -237,   223,  -237,  -237,  -237,   222,  -237,  -237,  -237,
     220,  -237,   181,  -237,  -237,  -237,    41,    41,   184,  -237,
      85,  -237,    73,   225,   227,   230,  -237,    25,   196,  -237,
      41,   235,   233,  -237,  -237,   234,    25,  -237,    41,  -237,
    -237,   236,  -237
  };

  const unsigned char
  parser::yydefact_[] =
  {
       0,     0,     0,     2,     0,     1,     3,     0,     6,     3,
       3,     0,    15,     3,     0,    13,     0,     3,    14,     0,
      45,    42,    43,    44,     8,     0,     0,    12,     3,     0,
      19,     3,     0,     0,     4,     0,     0,    27,     3,     3,
       0,    23,    17,    38,    39,    40,    41,     0,     0,     0,
       3,    26,     0,     3,    11,     0,     0,    21,     0,    22,
       3,     0,     0,     3,    31,     3,     0,    10,     0,    20,
      18,    25,    24,    16,     3,     3,     0,     3,   119,   120,
     121,     3,     3,     3,     0,     0,    35,    29,     0,     3,
       0,     0,     0,     0,     0,     0,     3,    67,     0,     0,
       3,     3,     3,     3,     3,     3,     3,    83,    84,     3,
      57,     0,     3,     0,    98,     3,    33,     0,     3,     3,
     111,   108,     3,     3,     3,   116,   112,     3,   128,   126,
     127,   124,   123,   118,   122,    34,     3,     5,     3,     3,
       3,     3,     3,     3,     0,     0,     3,     3,    50,    46,
      47,     3,     9,    60,    61,    62,    63,    64,    65,    66,
       3,     0,     0,   117,    99,   101,   102,   103,   104,   100,
       3,    32,    30,   109,   110,   113,   114,   115,     0,     3,
       3,    50,    85,    86,    37,    36,    28,     0,     0,    76,
       0,    77,     0,     0,     3,    49,     3,     0,    71,     0,
      69,     3,    59,     0,     3,     3,     3,     3,    89,     3,
      93,     0,    94,     0,     0,     3,     0,     3,     0,     0,
       0,     3,    52,     0,     0,     3,    68,    58,    56,     0,
      55,    53,     0,     3,     3,   107,    97,     3,    52,     0,
       3,     3,     3,    73,    74,    79,    75,    78,     0,     0,
       3,    51,     3,    70,    72,    54,     0,   105,   106,    51,
       3,    96,     0,    90,    88,    95,     3,     3,     0,    48,
       3,    87,     3,     0,     0,     0,     7,     3,     3,   129,
       3,     3,     0,    82,    80,     0,     3,    92,     3,   130,
      91,     0,    81
  };

  const short
  parser::yypgoto_[] =
  {
    -237,  -237,    -6,  -237,   169,   -52,  -237,  -237,  -237,   132,
     188,   209,  -237,  -237,  -237,  -237,  -237,   114,   186,  -237,
    -237,  -237,  -237,   -60,  -237,   -74,  -237,    -1,  -237,    24,
    -237,  -237,  -237,   -86,  -237,  -237,  -237,    31,  -237,  -237,
    -237,  -133,  -237,  -237,  -237,   173,  -237,  -236,  -237,  -137,
      -3,  -237,  -237,   -54,  -237,     9,  -237,  -237,  -237,  -237,
    -237,  -237,  -237
  };

  const short
  parser::yydefgoto_[] =
  {
      -1,     2,    80,     3,     9,    25,    34,    55,    16,    13,
      18,    19,    31,    58,    42,    73,    38,    51,    52,    65,
     117,    87,   186,    47,    26,    98,   149,   150,   223,    76,
     231,   111,   203,    99,   100,   199,   101,   197,   102,   103,
     104,   190,   105,   284,   106,   208,   182,   183,   239,   211,
     191,   170,   236,   114,   121,    82,   126,    83,    84,   133,
     134,   107,   108
  };

  const short
  parser::yytable_[] =
  {
       8,    67,     1,    12,    15,   264,    88,    24,     4,    81,
     131,    30,   118,   119,   153,   154,   155,   156,   157,   158,
     159,   144,    37,     5,   271,    41,     6,    77,    43,    44,
      45,    77,    54,    57,     7,   145,    78,    79,    46,    77,
      78,    79,   146,   145,    64,    10,    11,    24,    78,    79,
     146,   178,   147,    17,    71,   160,   233,   234,   179,    86,
     180,   171,    14,    27,   173,   174,   189,    28,    97,   110,
     210,   195,    29,    32,   113,   116,   120,   125,   262,    90,
      91,    92,   245,     8,   247,   277,    93,   180,    94,    95,
     148,    33,   196,    96,    97,    97,    97,    97,    97,    97,
      97,   204,    36,   261,   195,   265,    12,   164,   165,   166,
     167,   168,   169,   122,   123,   124,   206,    35,    39,   232,
     127,   181,   128,   129,   130,   209,    20,    21,    22,    23,
     184,   175,   176,   177,    40,   187,   188,   148,   192,   193,
     220,    48,    49,    53,   198,    50,    56,   227,   200,    60,
      61,    62,    66,    63,   202,    69,    68,    74,    75,    70,
      85,   109,    89,   112,   115,   138,   136,   251,   143,   207,
     139,   140,   151,   152,   141,   142,   161,   212,   163,   172,
     273,   274,   201,   259,   205,   213,   194,   214,   215,   217,
     222,   221,   216,   218,   285,   219,   268,   225,   230,    97,
     235,   181,   291,   238,   224,   226,   228,   229,   237,   240,
     241,   242,   252,   243,   244,   246,   248,   249,   276,   253,
     250,   256,   198,   281,   260,   262,   266,   267,   145,   270,
     257,   258,   290,   272,   275,   263,   278,   212,   279,   212,
     280,   286,   282,   288,   162,   289,   148,   292,    72,    59,
     185,   269,     0,   255,   263,     0,   254,   132,   137,     0,
      97,    97,     0,     0,    24,     0,   263,     0,     0,     0,
       0,   135,   283,     0,    97,   287,     0,     0,     0,     0,
       0,     0,    97
  };

  const short
  parser::yycheck_[] =
  {
       6,    53,    30,     9,    10,   241,    66,    13,    52,    63,
      84,    17,    23,    24,   100,   101,   102,   103,   104,   105,
     106,    95,    28,     0,   260,    31,     8,    14,    42,    43,
      44,    14,    38,    39,    31,     5,    23,    24,    52,    14,
      23,    24,    12,     5,    50,    52,    32,    53,    23,    24,
      12,     5,    14,    52,    60,   109,    28,    29,    12,    65,
      14,   115,    35,    52,   118,   119,    53,    10,    74,    75,
      53,   145,    12,     8,    77,    81,    82,    83,     5,    38,
      39,    40,   215,    89,   217,    12,    45,    14,    47,    48,
      96,    33,   146,    52,   100,   101,   102,   103,   104,   105,
     106,   161,    36,   240,   178,   242,   112,    16,    17,    18,
      19,    20,    21,    25,    26,    27,   170,    37,    55,   205,
      52,   127,    54,    55,    56,   179,    41,    42,    43,    44,
     136,   122,   123,   124,     6,   138,   139,   143,   141,   142,
     194,    14,    52,    34,   147,    52,     6,   201,   151,     7,
      15,    14,     8,    12,   160,    55,    11,    10,    52,    13,
       6,    12,     7,    15,     6,    14,     7,   221,    52,    52,
      14,    14,    22,    11,    14,    14,     8,   180,    15,    13,
     266,   267,     6,   237,    10,    15,    22,    15,     6,     6,
     196,     6,    15,    15,   280,    15,   250,     6,   204,   205,
     206,   207,   288,   209,    15,     7,    13,     6,     6,     6,
      15,     6,    13,     7,     7,     7,    51,    50,   270,     7,
      49,    11,   225,   277,    13,     5,    10,    10,     5,     7,
     233,   234,   286,    52,    50,   241,    11,   240,    11,   242,
      10,     6,    46,    10,   112,    11,   252,    11,    60,    40,
     136,   252,    -1,   229,   260,    -1,   225,    84,    89,    -1,
     266,   267,    -1,    -1,   270,    -1,   272,    -1,    -1,    -1,
      -1,    85,   278,    -1,   280,   281,    -1,    -1,    -1,    -1,
      -1,    -1,   288
  };

  const signed char
  parser::yystos_[] =
  {
       0,    30,    58,    60,    52,     0,     8,    31,    59,    61,
      52,    32,    59,    66,    35,    59,    65,    52,    67,    68,
      41,    42,    43,    44,    59,    62,    81,    52,    10,    12,
      59,    69,     8,    33,    63,    37,    36,    59,    73,    55,
       6,    59,    71,    42,    43,    44,    52,    80,    14,    52,
      52,    74,    75,    34,    59,    64,     6,    59,    70,    68,
       7,    15,    14,    12,    59,    76,     8,    62,    11,    55,
      13,    59,    67,    72,    10,    52,    86,    14,    23,    24,
      59,   110,   112,   114,   115,     6,    59,    78,    80,     7,
      38,    39,    40,    45,    47,    48,    52,    59,    82,    90,
      91,    93,    95,    96,    97,    99,   101,   118,   119,    12,
      59,    88,    15,   107,   110,     6,    59,    77,    23,    24,
      59,   111,    25,    26,    27,    59,   113,    52,    54,    55,
      56,    82,   102,   116,   117,    75,     7,    61,    14,    14,
      14,    14,    14,    52,    82,     5,    12,    14,    59,    83,
      84,    22,    11,    90,    90,    90,    90,    90,    90,    90,
     110,     8,    66,    15,    16,    17,    18,    19,    20,    21,
     108,   110,    13,   110,   110,   112,   112,   112,     5,    12,
      14,    59,   103,   104,    59,    74,    79,   107,   107,    53,
      98,   107,   107,   107,    22,    82,   110,    94,   107,    92,
     107,     6,    59,    89,    80,    10,   110,    52,   102,   110,
      53,   106,   107,    15,    15,     6,    15,     6,    15,    15,
     110,     6,    59,    85,    15,     6,     7,   110,    13,     6,
      59,    87,    90,    28,    29,    59,   109,     6,    59,   105,
       6,    15,     6,     7,     7,    98,     7,    98,    51,    50,
      49,   110,    13,     7,    94,    86,    11,   107,   107,   110,
      13,   106,     5,    59,   104,   106,    10,    10,   110,    84,
       7,   104,    52,    90,    90,    50,    62,    12,    11,    11,
      10,   110,    46,    59,   100,    90,     6,    59,    10,    11,
     110,    90,    11
  };

  const signed char
  parser::yyr1_[] =
  {
       0,    57,    58,    59,    60,    61,    61,    62,    62,    63,
      64,    64,    65,    65,    66,    66,    67,    68,    69,    69,
      70,    70,    71,    71,    72,    72,    73,    73,    74,    75,
      76,    76,    77,    77,    78,    78,    79,    79,    80,    80,
      80,    80,    81,    81,    81,    81,    82,    83,    83,    84,
      84,    85,    85,    86,    87,    87,    88,    88,    89,    89,
      90,    90,    90,    90,    90,    90,    90,    90,    91,    92,
      93,    94,    94,    95,    96,    97,    98,    98,    98,    98,
      99,   100,   100,   101,   101,   102,   103,   103,   103,   104,
     104,   105,   105,   106,   106,   106,   106,   107,   107,   108,
     108,   108,   108,   108,   108,   109,   109,   109,   110,   111,
     111,   111,   112,   113,   113,   113,   113,   114,   114,   115,
     115,   115,   116,   116,   116,   117,   117,   117,   117,   118,
     119
  };

  const signed char
  parser::yyr2_[] =
  {
       0,     2,     1,     0,     7,     9,     1,    12,     1,     6,
       2,     1,     2,     1,     2,     1,     5,     3,     4,     1,
       2,     1,     2,     1,     1,     1,     2,     1,     5,     3,
       4,     1,     2,     1,     2,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     2,     1,     5,     2,
       1,     2,     1,     5,     2,     1,     4,     1,     2,     1,
       2,     2,     2,     2,     2,     2,     2,     1,     4,     1,
       5,     1,     3,     5,     5,     5,     1,     1,     3,     3,
       9,     4,     1,     1,     1,     2,     1,     5,     4,     2,
       1,     2,     1,     1,     1,     3,     3,     4,     1,     1,
       1,     1,     1,     1,     1,     2,     2,     1,     2,     2,
       2,     1,     2,     2,     2,     2,     1,     3,     2,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     8,
      10
  };



  // YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
  // First, the terminals, then, starting at \a yyntokens_, nonterminals.
  const char*
  const parser::yytname_[] =
  {
  "\"eof\"", "error", "$undefined", "COMENTARIO", "SIMBOLO", "PUNTO",
  "COMA", "SCOL", "COL", "GBAJO", "LCUR", "RCUR", "LBRA", "RBRA", "LPAR",
  "RPAR", "EQ", "GE", "LE", "GT", "LT", "NE", "ASSIGN", "SUM", "RES",
  "MUL", "DIV", "MOD", "AND", "OR", "PROGRAMA", "CLASE", "VARIABLES",
  "MAIN", "METODOS", "HEREDA", "ATRIBUTOS", "FUNCION", "RETORNAR", "LEER",
  "ESCRIBIR", "VOID", "INT_T", "FLOAT_T", "CHAR_T", "SI", "SINO",
  "MIENTRAS", "PARA", "EN", "HACER", "ENTONCES", "ID", "STRING", "CHAR",
  "INT", "FLOAT", "$accept", "script", "empty", "program", "classes",
  "functions", "main", "methods", "inheritance", "variables",
  "var_options", "var_bridge1", "var_bridge2", "var_matrix", "var_cont",
  "var_options_loop", "attributes", "attr_options", "attr_bridge1",
  "attr_bridge2", "attr_matrix", "attr_cont", "attr_options_loop",
  "var_type", "return_type", "call_var", "call_options", "call_cont",
  "call_matrix", "parameters", "par_cont", "par_array", "par_matrix",
  "statutes", "assignment", "assignment_opt", "call_void",
  "void_expression_opt", "function_return", "read", "write",
  "write_expression_opt", "decision_statement", "dec_else",
  "repetition_statement", "call_function", "func_options", "func_cont",
  "func_matrix", "func_expression_opt", "expression", "relop",
  "express_loop", "exp", "exp_loop", "term", "term_loop", "factor", "sign",
  "call", "var_cte", "conditional", "nonconditional", YY_NULLPTR
  };

#if YYDEBUG
  const short
  parser::yyrline_[] =
  {
       0,   126,   126,   130,   133,   136,   137,   140,   141,   144,
     148,   149,   152,   153,   158,   159,   160,   161,   162,   163,
     164,   165,   166,   167,   168,   169,   176,   177,   178,   179,
     180,   181,   182,   183,   184,   185,   186,   187,   191,   191,
     191,   191,   194,   194,   194,   194,   197,   198,   199,   200,
     201,   202,   203,   207,   208,   209,   210,   211,   212,   213,
     217,   218,   219,   220,   221,   222,   223,   224,   227,   228,
     231,   232,   233,   236,   239,   242,   243,   244,   245,   246,
     249,   250,   251,   255,   255,   258,   259,   260,   261,   262,
     263,   264,   265,   266,   267,   268,   269,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   285,   286,
     287,   288,   291,   292,   293,   294,   295,   298,   299,   300,
     301,   302,   303,   304,   305,   308,   309,   310,   311,   314,
     317
  };

  // Print the state stack on the debug stream.
  void
  parser::yystack_print_ ()
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << int (i->state);
    *yycdebug_ << '\n';
  }

  // Report on the debug stream that the rule \a yyrule is going to be reduced.
  void
  parser::yy_reduce_print_ (int yyrule)
  {
    int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):\n";
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG


#line 6 "parser.yy"
} // yy
#line 1254 "parser.tab.cc"

#line 322 "parser.yy"

void yy::parser::error(const location_type& lugar, const std::string& lexema)
{
  std::cout << "SYNTAX ERROR !!! " << lexema << std::endl;
}
