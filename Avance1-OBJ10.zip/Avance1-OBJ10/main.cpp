#include <stdio.h>
#include "driver.h"

int main(){
  parser_driver driver;
  if(!driver.parse("test.txt"))  
    printf("\n\nInput Accepted\n\n");
}